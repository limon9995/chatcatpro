/**
 * CTASection — Advanced Redesign
 * Brand: #4d1c95 → #000000 | primary #3ccf73
 * Dramatic full-width CTA with orbit rings, particle field, animated headline
 */
import { motion, useReducedMotion, useInView } from "framer-motion";
import { ArrowRight, Zap, Check, Phone } from "lucide-react";
import { useMemo, useEffect, useState, useRef } from "react";
import { useLocation } from "wouter";
import { useTranslation } from "react-i18next";

/* ─── Floating particle ───────────────────────── */
const Particle = ({ index, reducedMotion }: { index: number; reducedMotion: boolean }) => {
  const [w, setW] = useState(1200);
  useEffect(() => { setW(window.innerWidth); }, []);

  const v = useMemo(() => ({
    x:    Math.random() * w,
    y:    200 + Math.random() * 300,
    dur:  4 + Math.random() * 4,
    del:  Math.random() * 5,
    size: 1.5 + Math.random() * 2.5,
    color: Math.random() > 0.5 ? "rgba(60,207,115,0.5)" : "rgba(77,28,149,0.6)",
  }), [w]);

  if (reducedMotion) return (
    <div className="absolute rounded-full" data-testid={`cta-particle-${index}`}
      style={{ left: v.x, top: v.y, width: v.size, height: v.size, background: v.color }} />
  );

  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{ width: v.size * 2, height: v.size * 2, background: v.color,
        boxShadow: `0 0 ${v.size * 3}px ${v.color}`, filter: "blur(0.5px)" }}
      initial={{ x: v.x, y: v.y, opacity: 0 }}
      animate={{ y: [v.y, v.y - 500], opacity: [0, 0.8, 0] }}
      transition={{ duration: v.dur, repeat: Infinity, delay: v.del, ease: "linear" }}
      data-testid={`cta-particle-${index}`}
    />
  );
};

/* ─── Sound wave decoration ───────────────────── */
const SoundWave = ({ playing = true }: { playing?: boolean }) => (
  <div className="flex items-end gap-[3px] h-6">
    {[5, 9, 13, 10, 16, 11, 8, 14, 9, 6].map((h, i) => (
      <motion.div key={i} className="w-[2.5px] rounded-full"
        style={{ background: i < 5 ? "linear-gradient(to top, #4d1c95, #3ccf73)" : "linear-gradient(to top, #2a7a45, #3ccf73)" }}
        animate={playing ? { height: [h * 0.4, h, h * 0.5, h * 0.85, h * 0.4] } : { height: h * 0.4 }}
        transition={{ duration: 0.9 + i * 0.08, repeat: Infinity, ease: "easeInOut", delay: i * 0.05 }} />
    ))}
  </div>
);

/* ─────────────────────────────────────────────
   MAIN
───────────────────────────────────────────── */
export function CTASection() {
  const [, setLocation] = useLocation();
  const shouldReduceMotion = useReducedMotion();
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  const containerV = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.12, delayChildren: 0.1 } },
  };
  const itemV = {
    hidden: { opacity: 0, y: 28 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.65, ease: [0.22, 1, 0.36, 1] } },
  };

  return (
    <section
      ref={ref}
      className="relative overflow-hidden py-20 sm:py-28 md:py-36"
      style={{ background: "linear-gradient(155deg, #180428 0%, #0c0118 40%, #000000 100%)" }}
      data-testid="cta-section"
    >
      {/* ── Background layers ── */}
      <div className="absolute inset-0 pointer-events-none" data-testid="cta-background">
        {/* Deep purple blob center */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] rounded-full blur-[140px]"
          style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.55) 0%, transparent 65%)" }} />
        {/* Green accent TR */}
        <div className="absolute top-0 right-0 w-[350px] h-[350px] rounded-full blur-[100px]"
          style={{ background: "radial-gradient(circle, rgba(60,207,115,0.08) 0%, transparent 70%)" }} />
        {/* Dark vignette edges */}
        <div className="absolute inset-0"
          style={{ background: "radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.7) 100%)" }} />
      </div>

      {/* ── Orbit rings ── */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {[500, 700, 900].map((d, i) => (
          <motion.div key={d} className="absolute rounded-full"
            style={{ width: d, height: d, border: `1px solid rgba(255,255,255,${0.04 - i * 0.01})` }}
            animate={{ rotate: i % 2 === 0 ? 360 : -360, scale: [1, 1.01, 1] }}
            transition={{ duration: 35 + i * 12, repeat: Infinity, ease: "linear" }} />
        ))}
        {/* Glowing orbit dot */}
        <motion.div className="absolute w-[700px] h-[700px]"
          animate={{ rotate: 360 }}
          transition={{ duration: 22, repeat: Infinity, ease: "linear" }}
          style={{ transformOrigin: "center" }}>
          <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full"
            style={{ background: "#3ccf73", boxShadow: "0 0 16px #3ccf73, 0 0 32px #3ccf7366" }} />
        </motion.div>
      </div>

      {/* ── Particle field ── */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none" data-testid="cta-particle-field">
        {Array.from({ length: 22 }).map((_, i) => (
          <Particle key={i} index={i} reducedMotion={shouldReduceMotion ?? false} />
        ))}
      </div>

      {/* ── Main content ── */}
      <div className="relative z-10 max-w-4xl mx-auto px-5 sm:px-8 text-center">
        <motion.div
          variants={shouldReduceMotion ? {} : containerV}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="flex flex-col items-center gap-7"
        >
          {/* Wave decoration */}
          <motion.div variants={itemV} className="flex justify-center">
            <SoundWave />
          </motion.div>

          {/* Badge */}
          <motion.div variants={itemV}>
            <span
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-semibold tracking-[0.18em] uppercase"
              style={{ background: "rgba(60,207,115,0.07)", border: "1px solid rgba(60,207,115,0.22)", color: "#3ccf73" }}
            >
              <Zap size={10} /> Ready to Launch
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            variants={itemV}
            className="text-4xl sm:text-5xl md:text-6xl lg:text-[68px] font-black leading-[1.05] tracking-[-0.03em]"
            data-testid="cta-headline"
          >
            <span style={{
              background: "linear-gradient(180deg, #ffffff 0%, rgba(255,255,255,0.75) 100%)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
            }}>
              {t("landing.cta.title")}
            </span>
          </motion.h2>

          {/* Sub */}
          <motion.p
            variants={itemV}
            className="text-[15px] md:text-base text-gray-400 max-w-xl leading-relaxed"
            data-testid="cta-subheadline"
          >
            {t("landing.cta.description")}
          </motion.p>

          {/* Trust chips */}
          <motion.div variants={itemV} className="flex flex-wrap justify-center gap-2">
            {["14-day Free Trial", "No Credit Card", "Cancel Anytime"].map(label => (
              <span key={label}
                className="inline-flex items-center gap-1.5 text-[11px] font-semibold px-3 py-1.5 rounded-full"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.09)", color: "rgba(255,255,255,0.5)" }}>
                <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: "#3ccf73" }} />
                {label}
              </span>
            ))}
          </motion.div>

          {/* CTA buttons */}
          <motion.div variants={itemV} className="flex flex-col sm:flex-row items-center gap-4 pt-1">
            {/* Primary */}
            <motion.button
              whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
              onClick={() => setLocation("/login")}
              className="relative inline-flex items-center gap-2 px-9 py-4 rounded-full font-bold text-base text-black overflow-hidden"
              style={{
                background: "linear-gradient(135deg, #3ccf73 0%, #2aaa58 100%)",
                boxShadow: "0 0 50px rgba(60,207,115,0.35), 0 4px 24px rgba(0,0,0,0.5)",
              }}
              data-testid="button-cta-get-started"
            >
              {/* Shimmer */}
              <motion.span className="absolute inset-0 rounded-full"
                style={{ background: "linear-gradient(110deg, transparent 30%, rgba(255,255,255,0.25) 50%, transparent 70%)", backgroundSize: "200% 100%" }}
                animate={{ backgroundPosition: ["200% 0", "-200% 0"] }}
                transition={{ duration: 2.6, repeat: Infinity, ease: "linear" }} />
              <span className="relative font-black">{t("landing.cta.button")}</span>
              <ArrowRight size={16} className="relative" />
            </motion.button>

            {/* Secondary */}
            <motion.button
              whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
              onClick={() => window.dispatchEvent(new CustomEvent("trigger-demo-call"))}
              className="inline-flex items-center gap-2.5 px-7 py-4 rounded-full font-semibold text-sm text-white/75"
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.12)",
                backdropFilter: "blur(10px)",
              }}
            >
              <span className="w-7 h-7 rounded-full flex items-center justify-center"
                style={{ background: "rgba(60,207,115,0.12)" }}>
                <Phone size={13} style={{ color: "#3ccf73" }} />
              </span>
              Try Demo Call
            </motion.button>
          </motion.div>

          {/* Trust message */}
          <motion.p
            variants={itemV}
            className="text-xs text-gray-600 flex items-center justify-center gap-1.5"
            data-testid="cta-trust-message"
          >
            <Check size={11} style={{ color: "#3ccf73" }} />
            {t("landing.cta.trustMessage")}
          </motion.p>
        </motion.div>
      </div>

      {/* ── Bottom fade to black ── */}
      <div className="absolute bottom-0 left-0 right-0 h-24 pointer-events-none"
        style={{ background: "linear-gradient(to bottom, transparent, rgba(0,0,0,0.8))" }} />
    </section>
  );
}

export default CTASection;