/**
 * PowerfulIntegrationsSection — Advanced Redesign
 * Brand: #4d1c95 → #000000 | primary #3ccf73
 * 6 integration cards + bottom CTA with connection diagram
 * All logos built with inline SVG — no external assets needed
 */
import { motion, useInView } from "framer-motion";
import { Check, ArrowRight, Zap, Webhook, MessageSquare } from "lucide-react";
import { Link } from "wouter";
import { useRef } from "react";
import { useTranslation } from "react-i18next";

/* ══════════════════════════════════════════
   INLINE SVG LOGOS
══════════════════════════════════════════ */

const MakeLogo = () => (
  <svg viewBox="0 0 40 40" width="40" height="40" fill="none">
    <rect width="40" height="40" rx="10" fill="#6d00cc"/>
    <path d="M8 28V14l12 7 12-7v14" stroke="white" strokeWidth="2.5" strokeLinejoin="round" fill="none"/>
    <circle cx="20" cy="21" r="3" fill="white"/>
  </svg>
);

const TwilioLogo = () => (
  <svg viewBox="0 0 40 40" width="40" height="40" fill="none">
    <rect width="40" height="40" rx="10" fill="#F22F46"/>
    <circle cx="20" cy="20" r="10" stroke="white" strokeWidth="2.5" fill="none"/>
    <circle cx="14" cy="14" r="2.5" fill="white"/>
    <circle cx="26" cy="14" r="2.5" fill="white"/>
    <circle cx="14" cy="26" r="2.5" fill="white"/>
    <circle cx="26" cy="26" r="2.5" fill="white"/>
  </svg>
);

const WatiLogo = () => (
  <svg viewBox="0 0 40 40" width="40" height="40" fill="none">
    <rect width="40" height="40" rx="10" fill="#00a884"/>
    <path d="M12 26.5C12 26.5 13.5 24 14 22C14.5 20 14 17 16 15C18 13 22 12.5 25 14C28 15.5 29 19 28 22C27 25 24 27.5 20 27.5C18 27.5 16.5 27 15.5 26.5L12 27.5L12 26.5Z"
      stroke="white" strokeWidth="2" fill="none" strokeLinejoin="round"/>
    <path d="M17 19.5C17 19.5 18.5 21.5 20 22.5C21.5 23.5 23.5 23 24 21.5" stroke="white" strokeWidth="1.8" strokeLinecap="round" fill="none"/>
  </svg>
);

const GoogleCalendarLogo = () => (
  <svg viewBox="0 0 40 40" width="40" height="40" fill="none">
    <rect width="40" height="40" rx="10" fill="white"/>
    <rect x="6" y="9" width="28" height="24" rx="2" stroke="#4285F4" strokeWidth="2" fill="white"/>
    <rect x="6" y="9" width="28" height="7" rx="2" fill="#4285F4"/>
    <line x1="14" y1="9" x2="14" y2="4" stroke="#4285F4" strokeWidth="2.5" strokeLinecap="round"/>
    <line x1="26" y1="9" x2="26" y2="4" stroke="#4285F4" strokeWidth="2.5" strokeLinecap="round"/>
    <text x="20" y="27" textAnchor="middle" fill="#4285F4" fontSize="11" fontWeight="800">31</text>
  </svg>
);

const WhatsAppLogo = () => (
  <svg viewBox="0 0 40 40" width="40" height="40" fill="none">
    <rect width="40" height="40" rx="10" fill="#25D366"/>
    <path d="M20 8C13.4 8 8 13.4 8 20C8 22.2 8.6 24.3 9.7 26.1L8 32L14.1 30.3C15.8 31.3 17.8 31.9 20 31.9C26.6 31.9 32 26.5 32 19.9C32 13.4 26.6 8 20 8Z" fill="white" fillOpacity="0.9"/>
    <path d="M25.5 22.8C25.2 23.6 23.9 24.3 23.1 24.4C22.4 24.5 21.5 24.5 19.7 23.8C17.2 22.8 15.6 20.3 15.4 20C15.3 19.8 14.3 18.5 14.3 17.1C14.3 15.7 15 15 15.3 14.7C15.6 14.4 15.9 14.3 16.1 14.3C16.3 14.3 16.5 14.3 16.7 14.4C16.9 14.5 17.2 14.2 17.5 15C17.8 15.8 18.5 17.2 18.6 17.3C18.7 17.5 18.7 17.7 18.6 17.9C18.5 18.1 18.4 18.2 18.2 18.4C18 18.6 17.8 18.8 17.7 18.9C17.5 19.1 17.3 19.3 17.5 19.6C17.7 19.9 18.5 21.1 19.6 22.1C21 23.3 22.2 23.7 22.5 23.8C22.8 23.9 23 23.9 23.2 23.7C23.4 23.5 24.1 22.7 24.3 22.4C24.5 22.1 24.7 22.2 25 22.3C25.3 22.4 26.7 23.1 27 23.3C27.3 23.5 27.5 23.6 27.6 23.7C27.6 23.9 27.8 24 25.5 22.8Z" fill="#25D366"/>
  </svg>
);

const ZapierLogo = () => (
  <svg viewBox="0 0 40 40" width="40" height="40" fill="none">
    <rect width="40" height="40" rx="10" fill="#FF4A00"/>
    <path d="M20 8L22.5 16H31L24.3 21L26.8 29L20 24L13.2 29L15.7 21L9 16H17.5L20 8Z"
      fill="white"/>
  </svg>
);

/* ══════════════════════════════════════════
   INTEGRATION DATA
══════════════════════════════════════════ */
interface Integration {
  id: string;
  name: string;
  logo: React.ReactNode;
  accentColor: string;
  description: React.ReactNode;
}

const INTEGRATIONS: Integration[] = [
  {
    id: "make",
    name: "Make",
    logo: <MakeLogo />,
    accentColor: "#6d00cc",
    description: <>Connect with 1,000+ apps using Make.com to <strong className="text-white">automate voice calls</strong>, contact syncing, and <strong className="text-white">real-time workflows</strong>—no code needed.</>,
  },
  {
    id: "twilio",
    name: "Twilio / Telnyx",
    logo: <TwilioLogo />,
    accentColor: "#F22F46",
    description: <>Fully embedded infrastructure for provisioning <strong className="text-white">branded phone numbers</strong>, handling <strong className="text-white">SMS</strong>, and powering scalable voice communication.</>,
  },
  {
    id: "wati",
    name: "Wati",
    logo: <WatiLogo />,
    accentColor: "#00a884",
    description: <>Enables enhanced automation and conversational flows via <strong className="text-white">WhatsApp Business</strong>, integrated seamlessly into your AI-powered infrastructure.</>,
  },
  {
    id: "gcal",
    name: "Google Calendar",
    logo: <GoogleCalendarLogo />,
    accentColor: "#4285F4",
    description: <>Easily connect with Google Calendar to enable <strong className="text-white">real-time appointment scheduling</strong>, confirmations, and rescheduling during AI calls.</>,
  },
  {
    id: "whatsapp",
    name: "WhatsApp",
    logo: <WhatsAppLogo />,
    accentColor: "#25D366",
    description: <>Send <strong className="text-white">post-call messages</strong>, confirmations, and follow-ups directly through your WhatsApp account in real time, during or after a call.</>,
  },
  {
    id: "zapier",
    name: "Zapier",
    logo: <ZapierLogo />,
    accentColor: "#FF4A00",
    description: <>Automatically <strong className="text-white">trigger AI calls</strong>, update contact records, send follow-ups, and sync data across your stack without writing a single line of code.</>,
  },
];

/* ─── Integration card ────────────────────────── */
const IntegrationCard = ({ integration, delay }: { integration: Integration; delay: number }) => (
  <motion.div
    initial={{ opacity: 0, y: 24, scale: 0.97 }}
    whileInView={{ opacity: 1, y: 0, scale: 1 }}
    viewport={{ once: true, margin: "-40px" }}
    transition={{ duration: 0.52, delay, ease: [0.22, 1, 0.36, 1] }}
    whileHover={{ y: -4, scale: 1.015 }}
    className="relative rounded-2xl overflow-hidden group cursor-default flex flex-col"
    style={{
      background: "linear-gradient(145deg, rgba(16,3,32,0.97) 0%, rgba(5,0,12,0.99) 100%)",
      border: "1px solid rgba(255,255,255,0.07)",
      boxShadow: "0 8px 32px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.04)",
      transition: "box-shadow 0.3s, transform 0.3s",
    }}
    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = `0 16px 48px rgba(0,0,0,0.5), 0 0 0 1px ${integration.accentColor}30`; }}
    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = "0 8px 32px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.04)"; }}
    data-testid={`integration-card-${integration.id}`}
  >
    {/* Top accent line */}
    <div className="absolute top-0 left-6 right-6 h-px"
      style={{ background: `linear-gradient(90deg, transparent, ${integration.accentColor}55, transparent)` }} />
    {/* Corner glow */}
    <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full blur-2xl opacity-25 group-hover:opacity-45 transition-opacity"
      style={{ background: integration.accentColor }} />

    <div className="relative z-10 p-6 flex flex-col gap-4 h-full">
      {/* Logo + name */}
      <div className="flex flex-col items-center gap-3 text-center">
        <div className="relative">
          <div className="absolute inset-0 rounded-xl blur-lg opacity-30"
            style={{ background: integration.accentColor }} />
          <div className="relative">{integration.logo}</div>
        </div>
        <h3 className="font-black text-white text-base tracking-tight">{integration.name}</h3>
      </div>
      {/* Description */}
      <p className="text-sm text-gray-500 leading-relaxed text-center flex-1">
        {integration.description}
      </p>
    </div>
  </motion.div>
);

/* ─── Connection diagram (bottom CTA) ────────────── */
const ConnectionDiagram = ({ isInView }: { isInView: boolean }) => {
  const apps = [
    { label: "Zapier", color: "#FF4A00", icon: <ZapierLogo /> },
    { label: "API & Webhooks", color: "#3ccf73", icon: <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(60,207,115,0.15)", border: "1px solid rgba(60,207,115,0.3)" }}><Webhook size={18} style={{ color: "#3ccf73" }} /></div> },
    { label: "WhatsApp", color: "#25D366", icon: <WhatsAppLogo /> },
  ];

  return (
    <div className="relative flex items-center justify-center gap-8 md:gap-12">
      {/* Center hub */}
      <motion.div
        initial={{ opacity: 0, scale: 0.7 }}
        animate={isInView ? { opacity: 1, scale: 1 } : {}}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="relative flex-shrink-0"
      >
        <div className="absolute inset-0 rounded-2xl blur-xl"
          style={{ background: "rgba(77,28,149,0.6)" }} />
        <div className="relative w-16 h-16 rounded-2xl flex items-center justify-center"
          style={{ background: "linear-gradient(145deg, #1a0535, #0a0018)", border: "2px solid rgba(60,207,115,0.35)", boxShadow: "0 0 30px rgba(77,28,149,0.5)" }}>
          <MessageSquare size={26} style={{ color: "#3ccf73" }} />
        </div>
        <motion.div animate={{ scale: [1, 1.15, 1], opacity: [0.3, 0, 0.3] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeOut" }}
          className="absolute inset-0 rounded-2xl border-2" style={{ borderColor: "#3ccf73" }} />
      </motion.div>

      {/* App pills */}
      <div className="flex flex-col gap-3">
        {apps.map(({ label, color, icon }, i) => (
          <motion.div key={label}
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.45, delay: 0.4 + i * 0.1 }}
            className="flex items-center gap-2.5 px-4 py-2.5 rounded-xl"
            style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${color}30` }}
          >
            <div className="flex-shrink-0 w-8 h-8 rounded-lg overflow-hidden flex items-center justify-center">{icon}</div>
            <span className="text-sm font-bold text-white/80">{label}</span>
          </motion.div>
        ))}
      </div>

      {/* Connecting lines */}
      <svg className="absolute inset-0 pointer-events-none w-full h-full" style={{ zIndex: 0 }}>
        <defs>
          <linearGradient id="line-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#3ccf73" stopOpacity="0.5"/>
            <stop offset="100%" stopColor="#3ccf73" stopOpacity="0"/>
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
};

/* ─────────────────────────────────────────────
   MAIN
───────────────────────────────────────────── */
export function PowerfulIntegrationsSection() {
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const ctaRef = useRef(null);
  const ctaInView = useInView(ctaRef, { once: true });

  return (
    <section
      ref={ref}
      className="relative overflow-hidden py-10 md:py-10"
      style={{ background: "linear-gradient(180deg, #000000 0%, #05000e 55%, #000000 100%)" }}
      data-testid="powerful-integrations-section"
    >
      {/* BG blobs */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[700px] h-[350px] rounded-full blur-[130px]"
          style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.18) 0%, transparent 65%)" }} />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[250px] rounded-full blur-[100px]"
          style={{ background: "radial-gradient(circle, rgba(60,207,115,0.04) 0%, transparent 70%)" }} />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-5 sm:px-8 lg:px-10">
        {/* ── Header ── */}
        {/* <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 md:mb-16"
        >
          <span
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-semibold tracking-[0.18em] uppercase mb-5"
            style={{ background: "rgba(60,207,115,0.07)", border: "1px solid rgba(60,207,115,0.2)", color: "#3ccf73" }}
          >
            <Zap size={10} /> Integrations
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white leading-tight tracking-tight mb-4">
            Powerful Integrations
          </h2>
          <p className="text-base text-gray-400 max-w-xl mx-auto leading-relaxed">
            Configure your account to automate a variety of tasks and actions using 1-click integrations.
          </p>
        </motion.div> */}

        {/* ── 6-card grid ── */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5 mb-10 md:mb-14">
          {INTEGRATIONS.map((intg, i) => (
            <IntegrationCard key={intg.id} integration={intg} delay={i * 0.07} />
          ))}
        </div>

        {/* ── Bottom CTA ── */}
        <motion.div
          ref={ctaRef}
          initial={{ opacity: 0, y: 28 }}
          animate={ctaInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
          className="relative rounded-2xl overflow-hidden"
          style={{
            background: "linear-gradient(145deg, rgba(20,4,42,0.98) 0%, rgba(6,0,16,1) 100%)",
            border: "1px solid rgba(77,28,149,0.3)",
            boxShadow: "0 20px 60px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.04)",
          }}
        >
          {/* Top accent */}
          <div className="absolute top-0 left-8 right-8 h-px"
            style={{ background: "linear-gradient(90deg, transparent, rgba(60,207,115,0.4), transparent)" }} />
          {/* Glow */}
          <div className="absolute -top-10 left-1/4 w-60 h-60 rounded-full blur-3xl opacity-15"
            style={{ background: "#4d1c95" }} />

          <div className="relative z-10 grid md:grid-cols-2 gap-8 items-center p-7 md:p-10">
            {/* Left text */}
            <div className="space-y-4">
              <h3 className="text-2xl sm:text-3xl font-black text-white leading-tight">
                Connect to{" "}
                <span style={{ background: "linear-gradient(135deg, #3ccf73, #b78af5)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>
                  6,000+ apps
                </span>
              </h3>
              <p className="text-sm text-gray-400 leading-relaxed">
                Effortlessly connect with apps like{" "}
                <span className="text-white font-semibold">Mailchimp, GoHighLevel, Google Forms, Calendly, Wix, Webflow</span>{" "}
                and many more using{" "}
                <span className="text-white font-semibold">Zapier, Make, APIs & Webhooks</span>.
              </p>
              <p className="text-sm text-gray-500 leading-relaxed">
                <span className="font-semibold text-gray-300">Optimize Workflows:</span> Leverage the magic of integration to optimize your workflows and attain unparalleled efficiency and manage outreach campaigns tailored to your business.
              </p>

              {/* Trust */}
              <div className="flex flex-wrap gap-3 pt-1">
                {["14-day Free Trial", "Free $10 Credit"].map(label => (
                  <span key={label} className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-gray-500">
                    <Check size={11} style={{ color: "#3ccf73" }} /> {label}
                  </span>
                ))}
              </div>

              {/* CTA */}
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }} className="w-fit">
                <Link href="/login">
                  <button
                    className="relative inline-flex items-center gap-2 px-7 py-3 rounded-full font-bold text-sm text-black overflow-hidden"
                    style={{ background: "linear-gradient(135deg, #3ccf73 0%, #2aaa58 100%)", boxShadow: "0 0 28px rgba(60,207,115,0.28)" }}
                    data-testid="button-integrations-get-started"
                  >
                    <motion.span className="absolute inset-0 rounded-full"
                      style={{ background: "linear-gradient(110deg, transparent 30%, rgba(255,255,255,0.2) 50%, transparent 70%)", backgroundSize: "200% 100%" }}
                      animate={{ backgroundPosition: ["200% 0", "-200% 0"] }}
                      transition={{ duration: 2.6, repeat: Infinity, ease: "linear" }} />
                    <span className="relative">Get Started</span>
                    <ArrowRight size={13} className="relative" />
                  </button>
                </Link>
              </motion.div>
            </div>

            {/* Right: connection diagram */}
            <div className="flex items-center justify-center py-4 md:py-0">
              <ConnectionDiagram isInView={ctaInView} />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export default PowerfulIntegrationsSection;