/**
 * FeatureSection — Advanced Redesign with curve_svg.svg dividers
 * Brand: #4d1c95 → #000000 | primary #3ccf73
 * Images: /images/home/2.png | /images/home/second.png | /images/home/third.png
 */
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { Check, User, Calendar, MessageSquare, Phone, Zap, ArrowRight, Sparkles, BarChart2 } from "lucide-react";
import { Link } from "wouter";
import { useRef } from "react";
import { useTranslation } from "react-i18next";

/* ─── Capability badge ────────────────────── */
const CapabilityBadge = ({ text, delay }: { text: string; delay: number }) => (
  <motion.div
    className="flex items-center gap-2"
    initial={{ opacity: 0, y: 12 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ delay, duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
  >
    <span
      className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0"
      style={{ background: "rgba(60,207,115,0.12)", border: "1px solid rgba(60,207,115,0.35)" }}
    >
      <Check size={9} style={{ color: "#3ccf73" }} />
    </span>
    <span className="text-sm font-medium" style={{ color: "#3ccf73" }}>{text}</span>
  </motion.div>
);

/* ─── Curve SVG divider ───────────────────── */
const CurveDivider = ({ flip = false }: { flip?: boolean }) => (
  <div className="flex justify-center py-4 pointer-events-none" style={{ transform: flip ? "scaleY(-1)" : "none" }}>
    <svg
      width="60"
      height="180"
      viewBox="0 0 60 180"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M30 6 C72 35, -12 70, 30 103 C72 136, -12 148, 30 174"
        stroke="url(#curveGrad)"
        strokeWidth="1.5"
        strokeLinecap="round"
        fill="none"
      />
      <circle cx="30" cy="6" r="2.5" fill="rgba(255,255,255,0.25)" />
      <circle cx="30" cy="174" r="2.5" fill="rgba(255,255,255,0.25)" />
      <defs>
        <linearGradient id="curveGrad" x1="0" y1="0" x2="0" y2="1" gradientUnits="objectBoundingBox">
          <stop offset="0%" stopColor="rgba(255,255,255,0.0)" />
          <stop offset="30%" stopColor="rgba(255,255,255,0.3)" />
          <stop offset="70%" stopColor="rgba(255,255,255,0.3)" />
          <stop offset="100%" stopColor="rgba(255,255,255,0.0)" />
        </linearGradient>
      </defs>
    </svg>
  </div>
);

/* ─── Feature 1 mockup — real image + floating badges ─── */
const VoiceAgentMockup = () => (
  <div className="relative flex justify-center">
    {/* Glow */}
    <div
      className="absolute inset-0 rounded-3xl blur-3xl"
      style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.55) 0%, transparent 68%)" }}
    />
    <div className="relative w-full max-w-[460px]">
      <motion.div
        animate={{ y: [0, -8, 0] }}
        transition={{ duration: 5.5, repeat: Infinity, ease: "easeInOut" }}
        className="relative z-10 rounded-2xl overflow-hidden"
        style={{ filter: "drop-shadow(0 20px 50px rgba(77,28,149,0.6))" }}
      >
        <img
          src="/images/home/2.png"
          alt="Voice Agent UI"
          className="w-full h-auto block"
        />
      </motion.div>

      {/* Floating: Agent Active */}
      <motion.div
        animate={{ y: [0, -5, 0] }}
        transition={{ duration: 3.8, repeat: Infinity, ease: "easeInOut", delay: 0.4 }}
        className="absolute -top-3 -right-3 z-20 flex items-center gap-2 px-3 py-1.5 rounded-full"
        style={{
          background: "rgba(8,6,18,0.9)",
          border: "1px solid rgba(60,207,115,0.3)",
          backdropFilter: "blur(12px)",
        }}
      >
        <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
        <span className="text-xs font-semibold text-white/80">Agent Active</span>
      </motion.div>

      {/* Floating: calls metric */}
      <motion.div
        animate={{ y: [0, 6, 0] }}
        transition={{ duration: 4.2, repeat: Infinity, ease: "easeInOut", delay: 0.9 }}
        className="absolute -bottom-3 -left-3 z-20 px-4 py-2.5 rounded-xl"
        style={{
          background: "rgba(8,6,18,0.9)",
          border: "1px solid rgba(255,255,255,0.08)",
          backdropFilter: "blur(12px)",
        }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: "rgba(60,207,115,0.15)" }}
          >
            <Phone size={13} style={{ color: "#3ccf73" }} />
          </div>
          <div>
            <p className="text-[10px] text-gray-500">Calls handled</p>
            <p className="text-sm font-bold text-white">1,284 today</p>
          </div>
        </div>
      </motion.div>
    </div>
  </div>
);

/* ─── Feature 2 mockup — second.png ──────── */
const CallSchedulerMockup = () => (
  <div className="relative flex justify-center">
    <div
      className="absolute inset-0 rounded-3xl blur-3xl"
      style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.55) 0%, transparent 68%)" }}
    />
    <div className="relative w-full max-w-[460px]">
      <motion.div
        animate={{ y: [0, -8, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        className="relative z-10 rounded-2xl overflow-hidden"
        style={{ filter: "drop-shadow(0 20px 50px rgba(77,28,149,0.6))" }}
      >
        <img
          src="/images/home/second.png"
          alt="Call Scheduler UI"
          className="w-full h-auto block"
        />
      </motion.div>

      {/* Floating: outbound/inbound pills */}
      <motion.div
        animate={{ y: [0, -5, 0] }}
        transition={{ duration: 3.6, repeat: Infinity, ease: "easeInOut", delay: 0.3 }}
        className="absolute -top-3 -left-3 z-20 flex items-center gap-1.5 px-3 py-1.5 rounded-full"
        style={{
          background: "rgba(8,6,18,0.9)",
          border: "1px solid rgba(77,28,149,0.45)",
          backdropFilter: "blur(12px)",
        }}
      >
        <Phone size={11} style={{ color: "#b78af5" }} />
        <span className="text-xs font-semibold" style={{ color: "#b78af5" }}>Outbound Calls</span>
      </motion.div>

      <motion.div
        animate={{ y: [0, 5, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 0.7 }}
        className="absolute -bottom-3 -right-3 z-20 flex items-center gap-1.5 px-3 py-1.5 rounded-full"
        style={{
          background: "rgba(8,6,18,0.9)",
          border: "1px solid rgba(60,207,115,0.3)",
          backdropFilter: "blur(12px)",
        }}
      >
        <Phone size={11} style={{ color: "#3ccf73" }} />
        <span className="text-xs font-semibold" style={{ color: "#3ccf73" }}>Inbound Calls</span>
      </motion.div>
    </div>
  </div>
);

/* ─── Feature 3 mockup — third.png ───────── */
const ConversionMockup = () => (
  <div className="relative flex justify-center">
    <div
      className="absolute inset-0 rounded-3xl blur-3xl"
      style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.55) 0%, transparent 68%)" }}
    />
    <div className="relative w-full max-w-[460px]">
      <motion.div
        animate={{ y: [0, -8, 0] }}
        transition={{ duration: 5.8, repeat: Infinity, ease: "easeInOut" }}
        className="relative z-10 rounded-2xl overflow-hidden"
        style={{ filter: "drop-shadow(0 20px 50px rgba(77,28,149,0.6))" }}
      >
        <img
          src="/images/home/third.png"
          alt="Conversion Pipeline UI"
          className="w-full h-auto block"
        />
      </motion.div>

      {/* Floating: conversion rate */}
      <motion.div
        animate={{ y: [0, -5, 0] }}
        transition={{ duration: 3.9, repeat: Infinity, ease: "easeInOut", delay: 0.2 }}
        className="absolute -top-3 -right-3 z-20 flex items-center gap-2 px-3 py-1.5 rounded-full"
        style={{
          background: "rgba(8,6,18,0.9)",
          border: "1px solid rgba(60,207,115,0.3)",
          backdropFilter: "blur(12px)",
        }}
      >
        <BarChart2 size={11} style={{ color: "#3ccf73" }} />
        <span className="text-xs font-semibold text-white/80">3.2x Conversion</span>
      </motion.div>

      <motion.div
        animate={{ y: [0, 6, 0] }}
        transition={{ duration: 4.3, repeat: Infinity, ease: "easeInOut", delay: 0.8 }}
        className="absolute -bottom-3 -left-3 z-20 px-4 py-2.5 rounded-xl"
        style={{
          background: "rgba(8,6,18,0.9)",
          border: "1px solid rgba(255,255,255,0.08)",
          backdropFilter: "blur(12px)",
        }}
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "rgba(60,207,115,0.15)" }}>
            <Check size={13} style={{ color: "#3ccf73" }} />
          </div>
          <div>
            <p className="text-[10px] text-gray-500">Qualified leads</p>
            <p className="text-sm font-bold text-white">94% connect rate</p>
          </div>
        </div>
      </motion.div>
    </div>
  </div>
);

/* ─── Feature card ────────────────────────── */
interface FeatureCardProps {
  title: string;
  description: string;
  bullets: string[];
  mockup: React.ReactNode;
  imagePosition: "left" | "right";
  index: number;
  bgColor?: string;
}

const FeatureCard = ({
  title,
  description,
  bullets,
  mockup,
  imagePosition,
  index,
  bgColor = "transparent",
}: FeatureCardProps) => {
  const { t } = useTranslation();
  const isImageLeft = imagePosition === "left";
  const cardRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: cardRef,
    offset: ["start end", "center center"],
  });

  const scale   = useTransform(scrollYProgress, [0, 1], [0.85, 1]);
  const opacity = useTransform(scrollYProgress, [0, 0.4], [0, 1]);

  return (
    <div
      ref={cardRef}
      className="py-16 md:py-20 relative overflow-hidden"
      style={{ background: bgColor }}
    >
      {/* Subtle left/right glow per card */}
      <div
        className="absolute pointer-events-none"
        style={{
          [isImageLeft ? "left" : "right"]: 0,
          top: "50%",
          transform: "translateY(-50%)",
          width: 400,
          height: 400,
          borderRadius: "50%",
          filter: "blur(100px)",
          background: "radial-gradient(circle, rgba(77,28,149,0.2) 0%, transparent 70%)",
        }}
      />

      <motion.div
        style={{ scale, opacity }}
        className="relative z-10 max-w-6xl mx-auto px-5 sm:px-8 lg:px-10"
      >
        <div className="grid md:grid-cols-2 gap-10 lg:gap-16 items-center">

          {/* Text block */}
          <div
            className={isImageLeft ? "order-2" : "order-2 md:order-1"}
          >
            {/* Step number tag */}
            <div className="flex items-center gap-2.5 mb-5">
              <span
                className="px-2.5 py-1 rounded-lg text-xs font-black tracking-wider"
                style={{
                  background: "rgba(60,207,115,0.1)",
                  border: "1px solid rgba(60,207,115,0.25)",
                  color: "#3ccf73",
                }}
              >
                {String(index).padStart(2, "0")}
              </span>
              <div className="h-px flex-1 max-w-[60px]" style={{ background: "rgba(60,207,115,0.2)" }} />
            </div>

            <h3 className="text-2xl sm:text-3xl md:text-[2rem] font-black text-white mb-3 leading-[1.15] tracking-tight">
              {title}
            </h3>
            <p className="text-gray-400 mb-6 leading-relaxed text-[15px]">{description}</p>

            <ul className="space-y-2.5 mb-8">
              {bullets.map((bullet, i) => (
                <motion.li
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: 0.25 + i * 0.08 }}
                  className="flex items-start gap-3"
                >
                  <span
                    className="w-5 h-5 rounded-full flex items-center justify-center mt-0.5 flex-shrink-0"
                    style={{ background: "rgba(60,207,115,0.1)", border: "1px solid rgba(60,207,115,0.25)" }}
                  >
                    <Check size={10} style={{ color: "#3ccf73" }} />
                  </span>
                  <span className="text-gray-300 text-sm leading-relaxed">{bullet}</span>
                </motion.li>
              ))}
            </ul>

            {/* CTA row */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <Link href="/login">
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className="relative inline-flex items-center gap-2 px-7 py-2.5 rounded-full font-bold text-sm text-black overflow-hidden"
                  style={{
                    background: "linear-gradient(135deg, #3ccf73 0%, #2aaa58 100%)",
                    boxShadow: "0 0 28px rgba(60,207,115,0.28)",
                  }}
                  data-testid={`button-feature-cta-${index}`}
                >
                  <motion.span
                    className="absolute inset-0 rounded-full"
                    style={{
                      background: "linear-gradient(110deg, transparent 30%, rgba(255,255,255,0.2) 50%, transparent 70%)",
                      backgroundSize: "200% 100%",
                    }}
                    animate={{ backgroundPosition: ["200% 0", "-200% 0"] }}
                    transition={{ duration: 2.6, repeat: Infinity, ease: "linear" }}
                  />
                  <span className="relative">{t("landing.featureSection.getStarted")}</span>
                  <ArrowRight size={13} className="relative" />
                </motion.button>
              </Link>
              <div className="flex items-center gap-4 text-xs text-gray-600">
                <span className="flex items-center gap-1.5">
                  <Check size={11} style={{ color: "#3ccf73" }} />
                  {t("landing.featureSection.freeTrial")}
                </span>
                <span className="flex items-center gap-1.5">
                  <Check size={11} style={{ color: "#3ccf73" }} />
                  {t("landing.featureSection.freeCredit")}
                </span>
              </div>
            </div>
          </div>

          {/* Mockup */}
          <div className={isImageLeft ? "order-1" : "order-1 md:order-2"}>
            {mockup}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

/* ─────────────────────────────────────────────
   FEATURE SECTION
───────────────────────────────────────────── */
export function FeatureSection() {
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  const capabilities = [
    t("landing.featureSection.capabilities.bookMeetings"),
    t("landing.featureSection.capabilities.conductInterviews"),
    t("landing.featureSection.capabilities.coldCallProspects"),
    t("landing.featureSection.capabilities.offerSupport"),
  ];

  return (
    <section
      ref={ref}
      className="relative overflow-hidden"
      data-testid="feature-section"
    >
      {/* ── Section header ── */}
      <div
        className="relative z-10 py-16 text-center"
        style={{ background: "linear-gradient(180deg, #000000 0%, #050010 100%)" }}
      >
        {/* Background glow */}
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] rounded-full blur-[100px] pointer-events-none"
          style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.25) 0%, transparent 70%)" }}
        />

        <div className="relative z-10 max-w-4xl mx-auto px-5 sm:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            {/* Label pill */}
            <span
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-semibold tracking-[0.18em] uppercase mb-5"
              style={{ background: "rgba(60,207,115,0.07)", border: "1px solid rgba(60,207,115,0.2)", color: "#3ccf73" }}
            >
              <Zap size={10} /> Features
            </span>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white mb-6 leading-tight tracking-tight">
              {t("landing.featureSection.title")}
            </h2>

            {/* Capability badges */}
            <div className="flex flex-wrap justify-center gap-x-6 gap-y-2.5">
              {capabilities.map((cap, i) => (
                <CapabilityBadge key={cap} text={cap} delay={i * 0.08} />
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* ── Feature 1 — dark bg ── */}
      <div style={{ background: "#030008" }}>
        <FeatureCard
          title={t("landing.featureSection.feature1.title")}
          description={t("landing.featureSection.feature1.description")}
          bullets={[
            t("landing.featureSection.feature1.bullet1"),
            t("landing.featureSection.feature1.bullet2"),
            t("landing.featureSection.feature1.bullet3"),
          ]}
          mockup={<VoiceAgentMockup />}
          imagePosition="right"
          index={1}
        />
      </div>

      {/* Curve divider between 1→2 */}
      <div style={{ background: "linear-gradient(180deg, #030008 0%, #0e0320 100%)" }}>
        <CurveDivider />
      </div>

      {/* ── Feature 2 — purple-tinted bg ── */}
      <FeatureCard
        title={t("landing.featureSection.feature2.title")}
        description={t("landing.featureSection.feature2.description")}
        bullets={[
          t("landing.featureSection.feature2.bullet1"),
          t("landing.featureSection.feature2.bullet2"),
        ]}
        mockup={<CallSchedulerMockup />}
        imagePosition="left"
        index={2}
        bgColor="linear-gradient(180deg, #0e0320 0%, #07011a 100%)"
      />

      {/* Curve divider between 2→3 */}
      <div style={{ background: "linear-gradient(180deg, #07011a 0%, #030008 100%)" }}>
        <CurveDivider flip />
      </div>

      {/* ── Feature 3 — dark bg ── */}
      <FeatureCard
        title={t("landing.featureSection.feature3.title")}
        description={t("landing.featureSection.feature3.description")}
        bullets={[
          t("landing.featureSection.feature3.bullet1"),
          t("landing.featureSection.feature3.bullet2"),
          t("landing.featureSection.feature3.bullet3"),
          t("landing.featureSection.feature3.bullet4"),
        ]}
        mockup={<ConversionMockup />}
        imagePosition="right"
        index={3}
        bgColor="#030008"
      />

      {/* Bottom fade to black */}
      <div
        className="h-16 w-full pointer-events-none"
        style={{ background: "linear-gradient(to bottom, #030008, #000000)" }}
      />
    </section>
  );
}

export default FeatureSection;