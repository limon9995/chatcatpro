/**
 * ActionCardsSection — Advanced Bento Grid Redesign
 * Brand: #4d1c95 → #000000 | primary #3ccf73
 * Layout: asymmetric bento grid, each card unique size + accent
 */
import { motion, useInView } from "framer-motion";
import {
  MessageSquare,
  PhoneForwarded,
  Webhook,
  Mail,
  MessageCircle,
  Calendar,
  Check,
  ArrowRight,
  Zap,
  Activity,
} from "lucide-react";
import { Link } from "wouter";
import { useRef } from "react";
import { useTranslation } from "react-i18next";

/* ─── Animated connection dot ────────────── */
const PulseDot = ({ color = "#3ccf73" }: { color?: string }) => (
  <span className="relative flex h-2.5 w-2.5">
    <span
      className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-60"
      style={{ background: color }}
    />
    <span className="relative inline-flex rounded-full h-2.5 w-2.5" style={{ background: color }} />
  </span>
);

/* ─── Mini waveform decoration ───────────── */
const MiniWave = ({ color = "#3ccf73" }: { color?: string }) => (
  <div className="flex items-end gap-[2px] h-5">
    {[5, 10, 7, 14, 9, 12, 6, 11, 8].map((h, i) => (
      <motion.div
        key={i}
        className="w-[2px] rounded-full"
        style={{ background: color, height: h }}
        animate={{ height: [h * 0.5, h, h * 0.6, h * 0.9, h * 0.5] }}
        transition={{ duration: 1.2 + i * 0.08, repeat: Infinity, ease: "easeInOut", delay: i * 0.06 }}
      />
    ))}
  </div>
);

/* ─── Card data ───────────────────────────── */
interface ActionDef {
  key: string;
  icon: React.ElementType;
  accentColor: string;
  accentBg: string;
  borderColor: string;
  tag: string;
  // bento size hint
  size: "normal" | "wide" | "tall";
}

const ACTION_DEFS: ActionDef[] = [
  {
    key: "sms",
    icon: MessageSquare,
    accentColor: "#3ccf73",
    accentBg: "rgba(60,207,115,0.1)",
    borderColor: "rgba(60,207,115,0.2)",
    tag: "Instant",
    size: "normal",
  },
  {
    key: "transfer",
    icon: PhoneForwarded,
    accentColor: "#b78af5",
    accentBg: "rgba(183,138,245,0.1)",
    borderColor: "rgba(183,138,245,0.2)",
    tag: "Live",
    size: "wide",
  },
  {
    key: "webhooks",
    icon: Webhook,
    accentColor: "#60a5fa",
    accentBg: "rgba(96,165,250,0.1)",
    borderColor: "rgba(96,165,250,0.2)",
    tag: "Real-time",
    size: "normal",
  },
  {
    key: "email",
    icon: Mail,
    accentColor: "#f59e0b",
    accentBg: "rgba(245,158,11,0.1)",
    borderColor: "rgba(245,158,11,0.2)",
    tag: "Auto",
    size: "normal",
  },
  {
    key: "whatsapp",
    icon: MessageCircle,
    accentColor: "#3ccf73",
    accentBg: "rgba(60,207,115,0.1)",
    borderColor: "rgba(60,207,115,0.2)",
    tag: "24/7",
    size: "normal",
  },
  {
    key: "appointments",
    icon: Calendar,
    accentColor: "#b78af5",
    accentBg: "rgba(183,138,245,0.1)",
    borderColor: "rgba(183,138,245,0.2)",
    tag: "Smart",
    size: "wide",
  },
];

/* ─── Single action card ──────────────────── */
const ActionCard = ({
  def,
  title,
  delay,
}: {
  def: ActionDef;
  title: string;
  delay: number;
}) => {
  const Icon = def.icon;
  const isWide = def.size === "wide";

  return (
    <motion.div
      initial={{ opacity: 0, y: 28, scale: 0.96 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -4, scale: 1.015 }}
      className={`relative rounded-2xl overflow-hidden cursor-default group ${isWide ? "sm:col-span-2 lg:col-span-1" : ""}`}
      style={{
        background: "linear-gradient(145deg, rgba(18,4,35,0.95) 0%, rgba(6,0,14,0.98) 100%)",
        border: `1px solid ${def.borderColor}`,
        boxShadow: `0 8px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.04)`,
        transition: "box-shadow 0.3s ease, transform 0.3s ease",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLElement).style.boxShadow = `0 16px 48px rgba(0,0,0,0.5), 0 0 0 1px ${def.borderColor}, inset 0 1px 0 rgba(255,255,255,0.06)`;
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLElement).style.boxShadow = `0 8px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.04)`;
      }}
      data-testid={`action-card-${def.key}`}
    >
      {/* Top accent line */}
      <div
        className="absolute top-0 left-6 right-6 h-px"
        style={{ background: `linear-gradient(90deg, transparent, ${def.accentColor}55, transparent)` }}
      />

      {/* Corner glow */}
      <div
        className="absolute -top-8 -right-8 w-24 h-24 rounded-full blur-2xl opacity-40 group-hover:opacity-60 transition-opacity"
        style={{ background: def.accentColor }}
      />

      <div className="relative z-10 p-6">
        {/* Top row: icon + tag */}
        <div className="flex items-start justify-between mb-5">
          {/* Icon box */}
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center"
            style={{
              background: def.accentBg,
              border: `1px solid ${def.borderColor}`,
              boxShadow: `0 0 20px ${def.accentColor}20`,
            }}
          >
            <Icon size={20} style={{ color: def.accentColor }} />
          </div>

          {/* Tag pill */}
          <span
            className="text-[10px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full"
            style={{ background: def.accentBg, color: def.accentColor, border: `1px solid ${def.borderColor}` }}
          >
            {def.tag}
          </span>
        </div>

        {/* Title */}
        <h3 className="font-bold text-white text-base leading-snug mb-3 tracking-tight">
          {title}
        </h3>

        {/* Bottom: wave + arrow */}
        <div className="flex items-center justify-between mt-4">
          <MiniWave color={def.accentColor} />
          <div
            className="w-7 h-7 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            style={{ background: def.accentBg, border: `1px solid ${def.borderColor}` }}
          >
            <ArrowRight size={12} style={{ color: def.accentColor }} />
          </div>
        </div>
      </div>
    </motion.div>
  );
};

/* ─── Central connector illustration ─────── */
const CenterConnector = ({ isInView }: { isInView: boolean }) => (
  <motion.div
    initial={{ opacity: 0, scale: 0.8 }}
    animate={isInView ? { opacity: 1, scale: 1 } : {}}
    transition={{ duration: 0.7, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
    className="relative flex items-center justify-center py-10 md:py-0"
  >
    {/* Outer orbit ring */}
    <motion.div
      animate={{ rotate: 360 }}
      transition={{ duration: 28, repeat: Infinity, ease: "linear" }}
      className="absolute w-64 h-64 rounded-full"
      style={{ border: "1px dashed rgba(60,207,115,0.12)" }}
    />
    {/* Middle orbit */}
    <motion.div
      animate={{ rotate: -360 }}
      transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
      className="absolute w-44 h-44 rounded-full"
      style={{ border: "1px solid rgba(77,28,149,0.3)" }}
    >
      {/* Orbiting dot */}
      <div
        className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full"
        style={{ background: "#3ccf73", boxShadow: "0 0 10px #3ccf73" }}
      />
    </motion.div>

    {/* Center hub */}
    <div
      className="relative w-24 h-24 rounded-2xl flex flex-col items-center justify-center z-10"
      style={{
        background: "linear-gradient(145deg, #1a0435, #0a0018)",
        border: "1px solid rgba(60,207,115,0.3)",
        boxShadow: "0 0 40px rgba(60,207,115,0.15), 0 0 80px rgba(77,28,149,0.3)",
      }}
    >
      <Activity size={22} style={{ color: "#3ccf73" }} />
      <span className="text-[10px] font-bold text-white/60 mt-1 tracking-wider">AGENT</span>
      {/* Pulse */}
      <div className="absolute -inset-2 rounded-[1.2rem] animate-ping opacity-10"
        style={{ background: "#3ccf73" }} />
    </div>

    {/* Radiating lines */}
    {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
      <div
        key={deg}
        className="absolute w-16 h-px origin-left"
        style={{
          background: "linear-gradient(90deg, rgba(60,207,115,0.15), transparent)",
          transform: `rotate(${deg}deg) translateX(48px)`,
          left: "50%",
          top: "50%",
          marginTop: -0.5,
        }}
      />
    ))}
  </motion.div>
);

/* ─────────────────────────────────────────────
   ACTION CARDS SECTION
───────────────────────────────────────────── */
export function ActionCardsSection() {
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-60px" });

  const actions = [
    { key: "sms",          title: t("landing.actionCards.cards.sms") },
    { key: "transfer",     title: t("landing.actionCards.cards.transfer") },
    { key: "webhooks",     title: t("landing.actionCards.cards.webhooks") },
    { key: "email",        title: t("landing.actionCards.cards.email") },
    { key: "whatsapp",     title: t("landing.actionCards.cards.whatsapp") },
    { key: "appointments", title: t("landing.actionCards.cards.appointments") },
  ];

  return (
    <section
      ref={ref}
      className="relative overflow-hidden py-20 md:pt-28 md:pb-10"
      style={{ background: "linear-gradient(180deg, #000000 0%, #06001a 50%, #000000 100%)" }}
      data-testid="action-cards-section"
    >
      {/* Background blobs */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] rounded-full blur-[120px]"
          style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.22) 0%, transparent 68%)" }} />
        <div className="absolute top-0 right-0 w-[300px] h-[300px] rounded-full blur-[90px]"
          style={{ background: "radial-gradient(circle, rgba(60,207,115,0.05) 0%, transparent 70%)" }} />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-5 sm:px-8 lg:px-10">
        {/* ── Header ── */}
        <motion.div
          initial={{ opacity: 0, y: 22 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          {/* Label */}
          <span
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-semibold tracking-[0.18em] uppercase mb-5"
            style={{ background: "rgba(60,207,115,0.07)", border: "1px solid rgba(60,207,115,0.2)", color: "#3ccf73" }}
          >
            <Zap size={10} /> Automations
          </span>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white mb-4 leading-tight tracking-tight">
            {t("landing.actionCards.title")}
          </h2>
          <p className="text-base text-gray-400 max-w-xl mx-auto leading-relaxed">
            {t("landing.actionCards.description")}
          </p>
        </motion.div>

        {/* ── Bento grid + center connector ── */}
        <div className="grid lg:grid-cols-[1fr_auto_1fr] gap-6 lg:gap-8 items-center">
          {/* Left 3 cards */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-1 gap-4">
            {actions.slice(0, 3).map((action, i) => {
              const def = ACTION_DEFS.find((d) => d.key === action.key)!;
              return <ActionCard key={action.key} def={def} title={action.title} delay={i * 0.08} />;
            })}
          </div>

          {/* Center connector — hidden on mobile, show md+ */}
          <div className="hidden lg:flex items-center justify-center w-72">
            <CenterConnector isInView={isInView} />
          </div>

          {/* Right 3 cards */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-1 gap-4">
            {actions.slice(3).map((action, i) => {
              const def = ACTION_DEFS.find((d) => d.key === action.key)!;
              return <ActionCard key={action.key} def={def} title={action.title} delay={0.24 + i * 0.08} />;
            })}
          </div>
        </div>

        {/* ── CTA ── */}
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, delay: 0.5 }}
          className="flex flex-col items-center gap-4 mt-14"
        >
          <Link href="/login">
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="relative inline-flex items-center gap-2.5 px-9 py-3.5 rounded-full font-bold text-sm text-black overflow-hidden"
              style={{
                background: "linear-gradient(135deg, #3ccf73 0%, #2aaa58 100%)",
                boxShadow: "0 0 40px rgba(60,207,115,0.3), 0 4px 20px rgba(0,0,0,0.5)",
              }}
              data-testid="button-actions-get-started"
            >
              {/* Shimmer */}
              <motion.span
                className="absolute inset-0 rounded-full"
                style={{
                  background: "linear-gradient(110deg, transparent 30%, rgba(255,255,255,0.22) 50%, transparent 70%)",
                  backgroundSize: "200% 100%",
                }}
                animate={{ backgroundPosition: ["200% 0", "-200% 0"] }}
                transition={{ duration: 2.8, repeat: Infinity, ease: "linear" }}
              />
              <span className="relative">{t("landing.actionCards.getStarted")}</span>
              <ArrowRight size={14} className="relative" />
            </motion.button>
          </Link>

          <div className="flex items-center gap-6 text-xs text-gray-600">
            <span className="flex items-center gap-1.5">
              <Check size={11} style={{ color: "#3ccf73" }} />
              {t("landing.actionCards.freeTrial")}
            </span>
            <span className="hidden sm:block w-px h-3 bg-white/10" />
            <span className="flex items-center gap-1.5">
              <Check size={11} style={{ color: "#3ccf73" }} />
              {t("landing.actionCards.freeCredit")}
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export default ActionCardsSection;