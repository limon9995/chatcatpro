/**
 * FeaturesShowcase — Advanced Redesign
 * Brand: #4d1c95 → #000000 | primary #3ccf73
 * Layout: section headers as floating labels, cards with dark glassmorphism,
 *         unique animated SVG visual per feature, accent color variety
 */
import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { useTranslation } from "react-i18next";
import { Globe, Zap, Brain, ArrowUpRight } from "lucide-react";

/* ─── Shared SVG constants ───────────────────── */
const G = "#3ccf73";
const P = "#4d1c95";
const GLOW = "rgba(60,207,115,0.18)";
const PGLOW = "rgba(77,28,149,0.3)";

/* ══════════════════════════════════════════
   SVG VISUALS
══════════════════════════════════════════ */

/* 1. Global Reach — animated globe + pulsing pins */
const GlobalReachVisual = () => (
  <svg viewBox="0 0 280 180" className="w-full h-full">
    <defs>
      <radialGradient id="gr-glow" cx="50%" cy="50%"><stop offset="0%" stopColor={G} stopOpacity="0.25"/><stop offset="100%" stopColor={G} stopOpacity="0"/></radialGradient>
      <radialGradient id="gr-ring" cx="50%" cy="50%"><stop offset="0%" stopColor={G} stopOpacity="0"/><stop offset="80%" stopColor={G} stopOpacity="0.15"/><stop offset="100%" stopColor={G} stopOpacity="0"/></radialGradient>
    </defs>
    {/* glow */}
    <circle cx="140" cy="88" r="65" fill="url(#gr-glow)" />
    {/* globe outline */}
    <circle cx="140" cy="88" r="48" fill="none" stroke={G} strokeWidth="1.5" strokeOpacity="0.6"/>
    {/* meridians */}
    <path d="M140 40 Q168 88 140 136" fill="none" stroke={G} strokeWidth="1" strokeOpacity="0.35"/>
    <path d="M140 40 Q112 88 140 136" fill="none" stroke={G} strokeWidth="1" strokeOpacity="0.35"/>
    {/* equator */}
    <ellipse cx="140" cy="88" rx="48" ry="20" fill="none" stroke={G} strokeWidth="1" strokeOpacity="0.35"/>
    {/* tropic */}
    <ellipse cx="140" cy="72" rx="38" ry="10" fill="none" stroke={G} strokeWidth="1" strokeOpacity="0.2"/>
    {/* pulsing pins */}
    {[[115,65],[165,72],[155,115],[125,105]].map(([cx,cy],i) => (
      <g key={i}>
        <motion.circle cx={cx} cy={cy} r="7" fill={G} fillOpacity="0" stroke={G} strokeWidth="1.2"
          animate={{ r:[7,14], opacity:[0.6,0] }} transition={{ duration:2, repeat:Infinity, delay:i*0.5, ease:"easeOut" }}/>
        <circle cx={cx} cy={cy} r="3" fill={G}/>
      </g>
    ))}
    {/* label */}
    <text x="140" y="160" textAnchor="middle" fill="white" fontSize="22" fontWeight="800">100+</text>
    <text x="140" y="173" textAnchor="middle" fill="#6b7280" fontSize="10" letterSpacing="2">COUNTRIES</text>
  </svg>
);

/* 2. Direct Connectivity — nodes + animated beam */
const DirectConnectivityVisual = () => (
  <svg viewBox="0 0 280 180" className="w-full h-full">
    <defs>
      <linearGradient id="dc-beam" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor={G} stopOpacity="0"/>
        <stop offset="50%" stopColor={G} stopOpacity="1"/>
        <stop offset="100%" stopColor={G} stopOpacity="0"/>
      </linearGradient>
      <filter id="dc-glow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    </defs>
    {/* left node */}
    <circle cx="75" cy="90" r="28" fill="#0e0220" stroke={P} strokeWidth="1.5" strokeOpacity="0.7"/>
    <text x="75" y="86" textAnchor="middle" fill="white" fontSize="11" fontWeight="700">100+</text>
    <text x="75" y="99" textAnchor="middle" fill="#9ca3af" fontSize="8">CARRIERS</text>
    {/* right node */}
    <circle cx="205" cy="90" r="28" fill="#0e0220" stroke={G} strokeWidth="1.5"/>
    <text x="205" y="95" textAnchor="middle" fill={G} fontSize="18">✓</text>
    {/* animated dashed beam */}
    <motion.line x1="103" y1="90" x2="177" y2="90" stroke="url(#dc-beam)" strokeWidth="2.5" strokeDasharray="6 4"
      animate={{ strokeDashoffset: [0, -40] }} transition={{ duration:1.2, repeat:Infinity, ease:"linear" }}/>
    {/* moving packet */}
    <motion.circle r="5" fill={G} filter="url(#dc-glow)"
      animate={{ cx:[103,177] }} transition={{ duration:1.2, repeat:Infinity, ease:"linear" }}>
      <animateMotion dur="1.2s" repeatCount="indefinite" path="M 103 90 L 177 90"/>
    </motion.circle>
    <text x="140" y="130" textAnchor="middle" fill="#6b7280" fontSize="9" letterSpacing="2">DIRECT CONNECT</text>
  </svg>
);

/* 3. Verified Numbers — phone number cards + tick badge */
const VerifiedNumbersVisual = () => (
  <svg viewBox="0 0 280 180" className="w-full h-full">
    {/* cards */}
    {[
      { y:40, num:"+1 (555) 123-4567", flag:"🇺🇸" },
      { y:76, num:"+44 20 7946 0958",  flag:"🇬🇧" },
      { y:112,num:"+91 98765 43210",   flag:"🇮🇳" },
    ].map(({ y, num, flag }, i) => (
      <motion.g key={i} initial={{ opacity:0, x:-12 }} whileInView={{ opacity:1, x:0 }} viewport={{ once:true }}
        transition={{ delay: i*0.12, duration:0.45 }}>
        <rect x="40" y={y} width="185" height="28" rx="7"
          fill={i===2 ? `${G}14` : "#0e0220"}
          stroke={i===2 ? G : "rgba(255,255,255,0.08)"} strokeWidth={i===2 ? 1.5 : 1}/>
        <text x="56" y={y+18} fill="white" fontSize="11" fontFamily="monospace">{flag} {num}</text>
        {i===2 && <circle cx="213" cy={y+14} r="7" fill={G}/>}
        {i===2 && <path d={`M${210} ${y+14} L${212} ${y+16} L${216} ${y+12}`} stroke="black" strokeWidth="1.8" fill="none" strokeLinecap="round"/>}
      </motion.g>
    ))}
    <text x="140" y="164" textAnchor="middle" fill="#6b7280" fontSize="9" letterSpacing="2">VERIFIED NUMBERS</text>
  </svg>
);

/* 4. High Quality — waveform + latency ring */
const CallQualityVisual = () => (
  <svg viewBox="0 0 280 180" className="w-full h-full">
    <defs>
      <linearGradient id="cq-wave" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor={G} stopOpacity="0.1"/>
        <stop offset="45%" stopColor={G} stopOpacity="0.9"/>
        <stop offset="55%" stopColor={G} stopOpacity="0.9"/>
        <stop offset="100%" stopColor={G} stopOpacity="0.1"/>
      </linearGradient>
    </defs>
    {/* waveform */}
    <motion.path d="M15 90 Q35 55 55 90 T95 90 T135 90 T175 90 T215 90 T255 90 T275 90"
      fill="none" stroke="url(#cq-wave)" strokeWidth="2.5"
      animate={{ d:[
        "M15 90 Q35 55 55 90 T95 90 T135 90 T175 90 T215 90 T255 90",
        "M15 90 Q35 125 55 90 T95 90 T135 90 T175 90 T215 90 T255 90",
        "M15 90 Q35 55 55 90 T95 90 T135 90 T175 90 T215 90 T255 90",
      ]}} transition={{ duration:2, repeat:Infinity, ease:"easeInOut" }}/>
    {/* latency badge center */}
    <circle cx="140" cy="90" r="34" fill="#0e0220" stroke={G} strokeWidth="1.5"/>
    <motion.circle cx="140" cy="90" r="34" fill="none" stroke={G} strokeWidth="2"
      strokeDasharray="213" animate={{ strokeDashoffset:[213,0] }}
      transition={{ duration:2, repeat:Infinity, ease:"easeInOut" }} strokeOpacity="0.4"/>
    <text x="140" y="86" textAnchor="middle" fill="white" fontSize="13" fontWeight="800">&lt;500ms</text>
    <text x="140" y="100" textAnchor="middle" fill="#6b7280" fontSize="9">LATENCY</text>
  </svg>
);

/* 5. Intelligent Routing — fan-out from hub */
const IntelligentRoutingVisual = () => (
  <svg viewBox="0 0 280 180" className="w-full h-full">
    <defs>
      <filter id="ir-glow"><feGaussianBlur stdDeviation="2.5" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    </defs>
    {/* hub */}
    <circle cx="80" cy="90" r="26" fill="#0e0220" stroke={P} strokeWidth="1.5" strokeOpacity="0.8"/>
    <text x="80" y="95" textAnchor="middle" fill="white" fontSize="11" fontWeight="700">AI</text>
    {/* routes */}
    {[[195,45,"#3ccf73"],[195,90,"#b78af5"],[195,135,"#60a5fa"]].map(([tx,ty,col],i) => (
      <g key={i}>
        <motion.line x1="106" y1="90" x2={tx} y2={ty} stroke={col as string} strokeWidth="1.8"
          strokeDasharray="5 4" animate={{ strokeDashoffset:[0,-36] }}
          transition={{ duration:1.4, repeat:Infinity, ease:"linear", delay:i*0.18 }}/>
        {/* moving packet */}
        <motion.circle r="4.5" fill={col as string} filter="url(#ir-glow)"
          animate={{ cx:[106, tx as number], cy:[90, ty as number] }}
          transition={{ duration:1.4, repeat:Infinity, ease:"linear", delay:i*0.18 }}/>
        <circle cx={tx as number} cy={ty as number} r="18" fill="#0e0220" stroke={col as string} strokeWidth="1.2"/>
        <text x={tx as number} y={(ty as number)+4} textAnchor="middle" fill={col as string} fontSize="10" fontWeight="700">
          {["CRM","SMS","CAL"][i]}
        </text>
      </g>
    ))}
    <text x="140" y="168" textAnchor="middle" fill="#6b7280" fontSize="9" letterSpacing="2">SMART ROUTING</text>
  </svg>
);

/* 6. Direct Carrier — ripple tower */
const CarrierConnectivityVisual = () => (
  <svg viewBox="0 0 280 180" className="w-full h-full">
    <defs>
      <filter id="cc-glow"><feGaussianBlur stdDeviation="3"/></filter>
    </defs>
    {/* ripple rings */}
    {[1,2,3].map(i => (
      <motion.circle key={i} cx="140" cy="95" r={28} fill="none" stroke={G} strokeWidth="1.5"
        animate={{ r:[28, 28+i*22], opacity:[0.6,0] }}
        transition={{ duration:2.2, repeat:Infinity, delay:i*0.55, ease:"easeOut" }}/>
    ))}
    {/* core */}
    <circle cx="140" cy="95" r="28" fill="#0e0220" stroke={G} strokeWidth="1.5"/>
    {/* lightning bolt */}
    <path d="M144 76 L134 95 L141 95 L136 114 L150 91 L143 91 Z" fill={G}/>
    <text x="140" y="152" textAnchor="middle" fill="#6b7280" fontSize="9" letterSpacing="2">ONE-HOP DELIVERY</text>
  </svg>
);

/* 7. Knowledge Base — doc → neural network */
const KnowledgeBaseVisual = () => (
  <svg viewBox="0 0 280 180" className="w-full h-full">
    <defs>
      <linearGradient id="kb-flow" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor={G} stopOpacity="0"/><stop offset="50%" stopColor={G}/><stop offset="100%" stopColor={G} stopOpacity="0"/>
      </linearGradient>
    </defs>
    {/* doc */}
    <rect x="28" y="52" width="56" height="76" rx="5" fill="#0e0220" stroke="rgba(255,255,255,0.1)" strokeWidth="1"/>
    {[0,1,2,3,4].map(i=>(
      <line key={i} x1="38" y1={67+i*12} x2={i%2===0?74:68} y2={67+i*12} stroke="rgba(255,255,255,0.15)" strokeWidth="1.5"/>
    ))}
    {/* beam */}
    <motion.line x1="84" y1="90" x2="126" y2="90" stroke="url(#kb-flow)" strokeWidth="2"
      animate={{ strokeDashoffset:[0,-20] }} strokeDasharray="8 4"
      transition={{ duration:1.2, repeat:Infinity, ease:"linear" }}/>
    {/* brain nodes */}
    {[[148,65],[170,75],[155,95],[175,105],[148,115],[170,128]].map(([cx,cy],i)=>(
      <motion.circle key={i} cx={cx} cy={cy} r="6" fill={G}
        animate={{ opacity:[0.5,1,0.5], r:[5,7,5] }}
        transition={{ duration:1.8, repeat:Infinity, delay:i*0.22 }}/>
    ))}
    {/* edges */}
    {[[0,1],[1,2],[2,3],[3,4],[4,5],[0,2],[1,3],[2,4],[3,5]].map(([a,b],i)=>{
      const nodes=[[148,65],[170,75],[155,95],[175,105],[148,115],[170,128]];
      return <line key={i} x1={nodes[a][0]} y1={nodes[a][1]} x2={nodes[b][0]} y2={nodes[b][1]} stroke={G} strokeWidth="1" strokeOpacity="0.3"/>;
    })}
    {/* envelope */}
    <circle cx="218" cy="90" r="34" fill="#0e0220" stroke={P} strokeWidth="1.5" strokeOpacity="0.7"/>
    <text x="218" y="87" textAnchor="middle" fill="white" fontSize="10" fontWeight="700">RAG</text>
    <text x="218" y="100" textAnchor="middle" fill="#6b7280" fontSize="8">KNOWLEDGE</text>
  </svg>
);

/* 8. Flow Builder — decision tree */
const FlowBuilderVisual = () => (
  <svg viewBox="0 0 280 180" className="w-full h-full">
    <defs>
      <linearGradient id="fb-path" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor={G}/><stop offset="100%" stopColor="#b78af5"/>
      </linearGradient>
    </defs>
    {/* start */}
    <rect x="105" y="18" width="70" height="24" rx="12" fill="#0e0220" stroke={G} strokeWidth="1.5"/>
    <text x="140" y="34" textAnchor="middle" fill={G} fontSize="10" fontWeight="700">START</text>
    {/* line down */}
    <motion.line x1="140" y1="42" x2="140" y2="62" stroke="url(#fb-path)" strokeWidth="1.8"
      animate={{ strokeDashoffset:[0,-20] }} strokeDasharray="5 4"
      transition={{ duration:1, repeat:Infinity, ease:"linear" }}/>
    {/* diamond */}
    <polygon points="140,62 162,82 140,102 118,82" fill="#0e0220" stroke={G} strokeWidth="1.5"/>
    <text x="140" y="87" textAnchor="middle" fill="white" fontSize="8.5">Intent?</text>
    {/* YES branch */}
    <motion.line x1="162" y1="82" x2="220" y2="82" stroke={G} strokeWidth="1.5"
      strokeDasharray="4 3" animate={{ strokeDashoffset:[0,-28] }}
      transition={{ duration:1, repeat:Infinity, ease:"linear", delay:0.2 }}/>
    <rect x="220" y="70" width="48" height="24" rx="6" fill="#0e0220" stroke={G} strokeWidth="1.2"/>
    <text x="244" y="86" textAnchor="middle" fill={G} fontSize="9" fontWeight="600">Action</text>
    {/* NO branch */}
    <motion.line x1="140" y1="102" x2="140" y2="122" stroke="#b78af5" strokeWidth="1.5"
      strokeDasharray="4 3" animate={{ strokeDashoffset:[0,-20] }}
      transition={{ duration:1, repeat:Infinity, ease:"linear", delay:0.4 }}/>
    <rect x="106" y="122" width="68" height="24" rx="6" fill="#0e0220" stroke="#f59e0b" strokeWidth="1.2"/>
    <text x="140" y="138" textAnchor="middle" fill="#f59e0b" fontSize="9" fontWeight="600">Fallback</text>
    {/* end */}
    <motion.line x1="140" y1="146" x2="140" y2="160" stroke="#ef4444" strokeWidth="1.5"
      strokeDasharray="4 3" animate={{ strokeDashoffset:[0,-20] }}
      transition={{ duration:1, repeat:Infinity, ease:"linear", delay:0.6 }}/>
    <rect x="113" y="160" width="54" height="17" rx="8.5" fill="#0e0220" stroke="#ef4444" strokeWidth="1.2"/>
    <text x="140" y="172" textAnchor="middle" fill="#ef4444" fontSize="9">END</text>
  </svg>
);

/* 9. Multi Language — orbiting language codes */
const MultiLanguageVisual = () => {
  const langs = [
    {code:"EN",color:"#3ccf73"}, {code:"ES",color:"#b78af5"}, {code:"FR",color:"#60a5fa"},
    {code:"DE",color:"#f59e0b"}, {code:"AR",color:"#f472b6"}, {code:"HI",color:"#34d399"},
  ];
  return (
    <svg viewBox="0 0 280 180" className="w-full h-full">
      <defs>
        <radialGradient id="ml-glow" cx="50%" cy="50%"><stop offset="0%" stopColor={G} stopOpacity="0.2"/><stop offset="100%" stopColor={G} stopOpacity="0"/></radialGradient>
      </defs>
      <circle cx="140" cy="88" r="60" fill="url(#ml-glow)"/>
      {/* orbit ring */}
      <motion.circle cx="140" cy="88" r="52" fill="none" stroke={G} strokeWidth="1" strokeOpacity="0.15"
        animate={{ rotate:360 }} transition={{ duration:20, repeat:Infinity, ease:"linear" }}
        style={{ transformOrigin:"140px 88px" }}/>
      {/* globe */}
      <circle cx="140" cy="88" r="26" fill="#0e0220" stroke={G} strokeWidth="1.5"/>
      <text x="140" y="84" textAnchor="middle" fill="white" fontSize="12" fontWeight="800">11</text>
      <text x="140" y="97" textAnchor="middle" fill="#6b7280" fontSize="8">LANGS</text>
      {/* orbiting badges */}
      {langs.map(({ code, color }, i) => {
        const angle = (i / langs.length) * 2 * Math.PI - Math.PI / 2;
        const cx = 140 + 52 * Math.cos(angle);
        const cy = 88 + 52 * Math.sin(angle);
        return (
          <motion.g key={code}
            animate={{ opacity:[0.6,1,0.6], scale:[0.9,1.05,0.9] }}
            transition={{ duration:2.4, repeat:Infinity, delay:i*0.35 }}
            style={{ transformOrigin:`${cx}px ${cy}px` }}>
            <circle cx={cx} cy={cy} r="14" fill="#0e0220" stroke={color} strokeWidth="1.5"/>
            <text x={cx} y={cy+4} textAnchor="middle" fill={color} fontSize="9.5" fontWeight="700">{code}</text>
          </motion.g>
        );
      })}
    </svg>
  );
};

/* ══════════════════════════════════════════
   CARD COMPONENT
══════════════════════════════════════════ */
interface CardDef {
  titleKey: string;
  descKey: string;
  visual: React.ReactNode;
  accent: string;
}

const FeatureCard = ({ titleKey, descKey, visual, accent, delay }: CardDef & { delay: number }) => {
  const { t } = useTranslation();
  return (
    <motion.div
      initial={{ opacity: 0, y: 24, scale: 0.97 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -5, scale: 1.018 }}
      className="relative rounded-2xl overflow-hidden group cursor-default h-full flex flex-col"
      style={{
        background: "linear-gradient(145deg, rgba(16,3,32,0.97) 0%, rgba(5,0,12,0.99) 100%)",
        border: "1px solid rgba(255,255,255,0.07)",
        boxShadow: "0 8px 32px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.04)",
        transition: "box-shadow 0.3s, transform 0.3s",
      }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = `0 16px 48px rgba(0,0,0,0.5), 0 0 0 1px ${accent}30, inset 0 1px 0 rgba(255,255,255,0.06)`; }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = "0 8px 32px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.04)"; }}
    >
      {/* top accent line */}
      <div className="absolute top-0 left-8 right-8 h-px"
        style={{ background: `linear-gradient(90deg, transparent, ${accent}55, transparent)` }} />
      {/* corner glow */}
      <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full blur-2xl opacity-25 group-hover:opacity-45 transition-opacity duration-300"
        style={{ background: accent }} />

      {/* visual */}
      <div className="relative z-10 h-44 sm:h-48 flex items-center justify-center px-4 pt-5">
        {visual}
      </div>

      {/* divider */}
      <div className="mx-5 h-px" style={{ background: "rgba(255,255,255,0.05)" }} />

      {/* text */}
      <div className="relative z-10 p-5 flex-1 flex flex-col gap-1.5">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-bold text-white text-sm leading-snug">
            {t(titleKey)}
          </h3>
          <ArrowUpRight size={14} className="flex-shrink-0 mt-0.5 text-gray-600 group-hover:text-gray-400 transition-colors" style={{ color: accent }} />
        </div>
        <p className="text-xs text-gray-500 leading-relaxed">{t(descKey)}</p>
      </div>
    </motion.div>
  );
};

/* ══════════════════════════════════════════
   SECTION GROUP
══════════════════════════════════════════ */
interface SectionGroupProps {
  labelIcon: React.ElementType;
  labelText: string;
  labelColor: string;
  titleKey: string;
  cards: (CardDef & { delay: number })[];
}

const SectionGroup = ({ labelIcon: Icon, labelText, labelColor, titleKey, cards }: SectionGroupProps) => {
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <div ref={ref} className="mb-14 md:mb-20">
      {/* group header */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={isInView ? { opacity: 1, x: 0 } : {}}
        transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
        className="flex items-center gap-3 mb-6 md:mb-8"
      >
        <span
          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold tracking-[0.16em] uppercase flex-shrink-0"
          style={{ background: `${labelColor}10`, border: `1px solid ${labelColor}30`, color: labelColor }}
        >
          <Icon size={10} />
          {labelText}
        </span>
        <div className="h-px flex-1" style={{ background: `linear-gradient(90deg, ${labelColor}25, transparent)` }} />
        <h3 className="text-lg sm:text-xl font-black text-white tracking-tight flex-shrink-0">{t(titleKey)}</h3>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
        {cards.map((card, i) => (
          <FeatureCard key={card.titleKey} {...card} />
        ))}
      </div>
    </div>
  );
};

/* ══════════════════════════════════════════
   MAIN EXPORT
══════════════════════════════════════════ */
export function FeaturesShowcase() {
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  const groups: SectionGroupProps[] = [
    {
      labelIcon: Globe,
      labelText: "Global Reach",
      labelColor: "#3ccf73",
      titleKey: "landing.featuresShowcase.globalReach",
      cards: [
        { titleKey: "landing.featuresShowcase.features.seamlessInbound.title", descKey: "landing.featuresShowcase.features.seamlessInbound.description", visual: <GlobalReachVisual />, accent: "#3ccf73", delay: 0 },
        { titleKey: "landing.featuresShowcase.features.directConnectivity.title", descKey: "landing.featuresShowcase.features.directConnectivity.description", visual: <DirectConnectivityVisual />, accent: "#b78af5", delay: 0.07 },
        { titleKey: "landing.featuresShowcase.features.verifiedNumbers.title", descKey: "landing.featuresShowcase.features.verifiedNumbers.description", visual: <VerifiedNumbersVisual />, accent: "#60a5fa", delay: 0.14 },
      ],
    },
    {
      labelIcon: Zap,
      labelText: "Reliable Calls",
      labelColor: "#b78af5",
      titleKey: "landing.featuresShowcase.reliableCalls",
      cards: [
        { titleKey: "landing.featuresShowcase.features.highQuality.title", descKey: "landing.featuresShowcase.features.highQuality.description", visual: <CallQualityVisual />, accent: "#3ccf73", delay: 0 },
        { titleKey: "landing.featuresShowcase.features.intelligentRouting.title", descKey: "landing.featuresShowcase.features.intelligentRouting.description", visual: <IntelligentRoutingVisual />, accent: "#b78af5", delay: 0.07 },
        { titleKey: "landing.featuresShowcase.features.directCarrier.title", descKey: "landing.featuresShowcase.features.directCarrier.description", visual: <CarrierConnectivityVisual />, accent: "#f59e0b", delay: 0.14 },
      ],
    },
    {
      labelIcon: Brain,
      labelText: "AI Automation",
      labelColor: "#60a5fa",
      titleKey: "landing.featuresShowcase.aiAutomation",
      cards: [
        { titleKey: "landing.featuresShowcase.features.knowledgeBase.title", descKey: "landing.featuresShowcase.features.knowledgeBase.description", visual: <KnowledgeBaseVisual />, accent: "#3ccf73", delay: 0 },
        { titleKey: "landing.featuresShowcase.features.flowBuilder.title", descKey: "landing.featuresShowcase.features.flowBuilder.description", visual: <FlowBuilderVisual />, accent: "#f59e0b", delay: 0.07 },
        { titleKey: "landing.featuresShowcase.features.multiLanguage.title", descKey: "landing.featuresShowcase.features.multiLanguage.description", visual: <MultiLanguageVisual />, accent: "#b78af5", delay: 0.14 },
      ],
    },
  ];

  return (
    <section
      ref={ref}
      className="relative overflow-hidden py-16 sm:py-20 md:py-28"
      style={{ background: "linear-gradient(180deg, #000000 0%, #05000e 55%, #000000 100%)" }}
      data-testid="features-showcase-section"
    >
      {/* BG blobs */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-[500px] h-[300px] rounded-full blur-[120px]"
          style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.18) 0%, transparent 70%)" }} />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[300px] rounded-full blur-[100px]"
          style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.15) 0%, transparent 70%)" }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full blur-[140px]"
          style={{ background: "radial-gradient(circle, rgba(60,207,115,0.03) 0%, transparent 65%)" }} />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-5 sm:px-8 lg:px-10">
        {/* ── Header ── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14 md:mb-18"
        >
          <span
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-semibold tracking-[0.18em] uppercase mb-5"
            style={{ background: "rgba(60,207,115,0.07)", border: "1px solid rgba(60,207,115,0.2)", color: "#3ccf73" }}
          >
            <Zap size={10} /> Platform
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white leading-tight tracking-tight mb-4">
            {t("landing.featuresShowcase.title")}{" "}
            <span style={{
              background: "linear-gradient(135deg, #3ccf73 0%, #b78af5 100%)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
            }}>
              {t("landing.featuresShowcase.titleHighlight")}
            </span>
          </h2>
          <p className="text-base text-gray-400 max-w-xl mx-auto leading-relaxed">
            {t("landing.featuresShowcase.description")}
          </p>
        </motion.div>

        {/* ── Groups ── */}
        {groups.map(group => (
          <SectionGroup key={group.titleKey} {...group} />
        ))}
      </div>
    </section>
  );
}

export default FeaturesShowcase;