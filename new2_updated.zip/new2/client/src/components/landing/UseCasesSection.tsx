/**
 * UseCasesSection — Advanced Audio Player + Playlist Redesign
 * Brand: #4d1c95 → #000000 | primary #3ccf73
 * Layout: Left = audio player card, Right = scrollable playlist
 */
import { motion, useInView, AnimatePresence } from "framer-motion";
import { useState, useRef, useEffect, useCallback } from "react";
import { useTranslation } from "react-i18next";
import {
  Play, Pause, SkipBack, SkipForward,
  Volume2, VolumeX, Zap,
} from "lucide-react";

/* ─── Country flag emoji helper ─────────────── */
const flagEmoji: Record<string, string> = {
  US: "🇺🇸", SG: "🇸🇬", BR: "🇧🇷", IN: "🇮🇳", UK: "🇬🇧", DE: "🇩🇪", NL: "🇳🇱",
};

/* ─── Use case data ──────────────────────────── */
interface UseCase {
  key: string;
  file: string;
  flag: string;
  avatarInitials: string;
  avatarColor: string;
}

const USE_CASES: UseCase[] = [
  { key: "saas",        file: "/voice/saas_in_us.mp3",                   flag: "US", avatarInitials: "EM", avatarColor: "#7c3aed" },
  { key: "university",  file: "/voice/university_in_singapore.wav",       flag: "SG", avatarInitials: "LI", avatarColor: "#0891b2" },
  { key: "automotive",  file: "/voice/automotive_brazil.mp3",             flag: "BR", avatarInitials: "MA", avatarColor: "#b45309" },
  { key: "support",     file: "/voice/india.mp3",                         flag: "IN", avatarInitials: "RA", avatarColor: "#be185d" },
  { key: "software",    file: "/voice/software_company_usa.mp3",          flag: "US", avatarInitials: "JA", avatarColor: "#15803d" },
  { key: "edtech",      file: "/voice/tech_company_india.wav",            flag: "IN", avatarInitials: "PR", avatarColor: "#c2410c" },
  { key: "ads",         file: "/voice/ads_agency_germany.wav",            flag: "DE", avatarInitials: "KL", avatarColor: "#6d28d9" },
  { key: "realestate",  file: "/voice/real_estate_netharland.wav",        flag: "NL", avatarInitials: "AN", avatarColor: "#0f766e" },
];

/* ─── Format seconds → mm:ss ─────────────────── */
const fmt = (s: number) => {
  if (!isFinite(s)) return "0:00";
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
};

/* ─── Mini animated waveform ─────────────────── */
const Waveform = ({ playing, color = "#3ccf73" }: { playing: boolean; color?: string }) => {
  const bars = [
    { h: 4,  d: 0.1 }, { h: 8,  d: 0.3 }, { h: 6,  d: 0.5 },
    { h: 10, d: 0.2 }, { h: 12, d: 0.4 }, { h: 9,  d: 0.6 },
    { h: 11, d: 0.3 }, { h: 7,  d: 0.5 }, { h: 10, d: 0.2 }
  ];

  return (
    <div className="flex items-end gap-[1.5px] h-3.5">
      {bars.map((bar, i) => (
        <motion.div
          key={i}
          className="w-[2px] rounded-full"
          style={{ background: color }}
          initial={{ height: bar.h * 0.4 }}
          animate={playing ? {
            height: [bar.h * 0.4, bar.h, bar.h * 0.4, bar.h * 0.8, bar.h * 0.4],
          } : {
            height: bar.h * 0.4
          }}
          transition={playing ? {
            duration: 0.9 + bar.d,
            repeat: Infinity,
            ease: "easeInOut",
          } : {
            duration: 0.3
          }}
        />
      ))}
    </div>
  );
};

/* ─── Avatar circle ───────────────────────────── */
const Avatar = ({ initials, color, size = 40 }: { initials: string; color: string; size?: number }) => (
  <div
    className="rounded-full flex items-center justify-center font-bold text-white flex-shrink-0"
    style={{
      width: size,
      height: size,
      fontSize: size * 0.32,
      background: `radial-gradient(circle at 35% 35%, ${color}cc, ${color}88)`,
      border: `2px solid ${color}55`,
      boxShadow: `0 0 12px ${color}40`,
    }}
  >
    {initials}
  </div>
);

/* ─── Progress bar ─────────────────────────────── */
const ProgressBar = ({
  current, duration, onSeek, accentColor,
}: {
  current: number; duration: number; onSeek: (pct: number) => void; accentColor: string;
}) => {
  const barRef = useRef<HTMLDivElement>(null);
  const pct = duration > 0 ? (current / duration) * 100 : 0;

  const handleClick = (e: React.MouseEvent) => {
    if (!barRef.current) return;
    const rect = barRef.current.getBoundingClientRect();
    onSeek((e.clientX - rect.left) / rect.width);
  };

  return (
    <div
      ref={barRef}
      onClick={handleClick}
      className="relative w-full h-1.5 rounded-full cursor-pointer group"
      style={{ background: "rgba(255,255,255,0.08)" }}
    >
      <div
        className="absolute top-0 left-0 h-full rounded-full transition-all"
        style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${accentColor}99, ${accentColor})` }}
      />
      {/* Thumb */}
      <div
        className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
        style={{ left: `calc(${pct}% - 6px)`, background: accentColor, boxShadow: `0 0 8px ${accentColor}` }}
      />
    </div>
  );
};

/* ─────────────────────────────────────────────
   MAIN COMPONENT
───────────────────────────────────────────── */
export function UseCasesSection() {
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playlistRef = useRef<HTMLDivElement>(null);

  const [activeIdx, setActiveIdx] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [muted, setMuted] = useState(false);
  const [loading, setLoading] = useState(false);

  const activeCase = USE_CASES[activeIdx];
  const accentColor = activeCase.avatarColor;

  /* Load audio when track changes */
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    setLoading(true);
    setCurrent(0);
    setDuration(0);
    audio.src = activeCase.file;
    audio.load();
    if (playing) audio.play().catch(() => setPlaying(false));
  }, [activeIdx]); // eslint-disable-line react-hooks/exhaustive-deps

  /* Sync events */
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const onTime = () => setCurrent(audio.currentTime);
    const onMeta = () => { setDuration(audio.duration); setLoading(false); };
    const onEnd  = () => { setPlaying(false); setCurrent(0); };
    const onWait = () => setLoading(true);
    const onPlay = () => setLoading(false);
    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("loadedmetadata", onMeta);
    audio.addEventListener("ended", onEnd);
    audio.addEventListener("waiting", onWait);
    audio.addEventListener("playing", onPlay);
    return () => {
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("loadedmetadata", onMeta);
      audio.removeEventListener("ended", onEnd);
      audio.removeEventListener("waiting", onWait);
      audio.removeEventListener("playing", onPlay);
    };
  }, []);

  /* Mute sync */
  useEffect(() => {
    if (audioRef.current) audioRef.current.muted = muted;
  }, [muted]);

  const togglePlay = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) { audio.pause(); setPlaying(false); }
    else { audio.play().then(() => setPlaying(true)).catch(() => {}); }
  }, [playing]);

  const selectTrack = useCallback((idx: number) => {
    if (idx === activeIdx) { togglePlay(); return; }
    setActiveIdx(idx);
    setPlaying(true);
    // Scroll active item into view in playlist
    setTimeout(() => {
      const el = playlistRef.current?.children[idx] as HTMLElement;
      el?.scrollIntoView({ block: "nearest", behavior: "smooth" });
    }, 100);
  }, [activeIdx, togglePlay]);

  const prev = () => selectTrack((activeIdx - 1 + USE_CASES.length) % USE_CASES.length);
  const next = () => selectTrack((activeIdx + 1) % USE_CASES.length);
  const seek = (pct: number) => {
    if (!audioRef.current || !duration) return;
    audioRef.current.currentTime = pct * duration;
    setCurrent(pct * duration);
  };

  return (
    <section
      ref={ref}
      className="relative overflow-hidden py-14 sm:py-20 md:py-28"
      style={{ background: "linear-gradient(180deg, #000000 0%, #04000f 50%, #000000 100%)" }}
      data-testid="use-cases-section"
    >
      {/* Hidden audio element */}
      <audio ref={audioRef} preload="metadata" />

      {/* BG blobs */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] rounded-full blur-[130px]"
          style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.2) 0%, transparent 68%)" }} />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-8 lg:px-10">
        {/* ── Header ── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-8 sm:mb-12 md:mb-16"
        >
          <span
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-semibold tracking-[0.18em] uppercase mb-5"
            style={{ background: "rgba(60,207,115,0.07)", border: "1px solid rgba(60,207,115,0.2)", color: "#3ccf73" }}
          >
            <Zap size={10} /> Use Cases
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black text-white mb-2 sm:mb-3 leading-tight tracking-tight">
            {t("landing.useCasesSection.title")}
          </h2>
          <p className="text-sm sm:text-base text-gray-400 max-w-xl mx-auto leading-relaxed px-2 sm:px-0">
            {t("landing.useCasesSection.description")}
          </p>
        </motion.div>

        {/* ── Main layout ── */}
        <div className="grid lg:grid-cols-[1fr_1.1fr] gap-4 sm:gap-5 lg:gap-8 items-start">

          {/* ── LEFT: Player card ── */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          >
            <div
              className="relative rounded-2xl overflow-hidden p-4 sm:p-5 md:p-7"
              style={{
                background: "linear-gradient(145deg, rgba(18,4,38,0.97) 0%, rgba(5,0,12,0.99) 100%)",
                border: "1px solid rgba(77,28,149,0.3)",
                boxShadow: "0 24px 64px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.05)",
              }}
            >
              {/* Top accent */}
              <div className="absolute top-0 left-8 right-8 h-px"
                style={{ background: `linear-gradient(90deg, transparent, ${accentColor}55, transparent)`, transition: "background 0.4s" }} />
              {/* Corner glow */}
              <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full blur-3xl opacity-25 transition-all duration-500"
                style={{ background: accentColor }} />

              {/* USE CASE label */}
              <p className="text-[10px] font-bold tracking-[0.22em] uppercase text-gray-500 mb-4 text-center">
                {t("landing.useCasesSection.useCaseLabel")}
              </p>

              {/* Avatar + title */}
              <div className="flex flex-col items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeIdx}
                    initial={{ scale: 0.75, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.75, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Avatar initials={activeCase.avatarInitials} color={activeCase.avatarColor} size={56} />
                    {/* Desktop size handled via CSS wrapper below */}
                  </motion.div>
                </AnimatePresence>
                <AnimatePresence mode="wait">
                  <motion.div
                    key={`title-${activeIdx}`}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    transition={{ duration: 0.3 }}
                    className="text-center"
                  >
                    <h3 className="text-base sm:text-lg md:text-xl font-black text-white leading-tight">
                      {t(`landing.useCasesSection.cases.${activeCase.key}.title`)}{" "}
                      <span>{flagEmoji[activeCase.flag]}</span>
                    </h3>
                    <p className="text-xs sm:text-sm text-gray-400 mt-1 sm:mt-1.5 max-w-xs mx-auto leading-relaxed">
                      {t(`landing.useCasesSection.cases.${activeCase.key}.description`)}
                    </p>
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Meta tags */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={`meta-${activeIdx}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.25 }}
                  className="grid grid-cols-3 gap-1.5 sm:gap-3 mb-4 sm:mb-6"
                >
                  {[
                    { label: t("landing.useCasesSection.industryLabel"),  val: t(`landing.useCasesSection.cases.${activeCase.key}.industry`) },
                    { label: t("landing.useCasesSection.languageLabel"),  val: t(`landing.useCasesSection.cases.${activeCase.key}.language`) },
                    { label: t("landing.useCasesSection.functionLabel"),  val: t(`landing.useCasesSection.cases.${activeCase.key}.function`) },
                  ].map(({ label, val }) => (
                    <div key={label} className="text-center px-1.5 sm:px-2 py-1.5 sm:py-2 rounded-lg sm:rounded-xl"
                      style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                      <p className="text-[8px] sm:text-[9px] text-gray-500 uppercase tracking-wider mb-0.5 sm:mb-1">{label}</p>
                      <p className="text-[10px] sm:text-xs font-bold text-white leading-tight truncate">{val}</p>
                    </div>
                  ))}
                </motion.div>
              </AnimatePresence>

              {/* Progress */}
              <div className="mb-2 sm:mb-3">
                <ProgressBar current={current} duration={duration} onSeek={seek} accentColor={accentColor} />
                <div className="flex justify-between mt-1.5">
                  <span className="text-[11px] text-gray-500">{fmt(current)}</span>
                  <span className="text-[11px] text-gray-500">{fmt(duration)}</span>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-between gap-2">
                {/* Mute */}
                <button
                  onClick={() => setMuted(!muted)}
                  className="w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center transition-colors flex-shrink-0"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}
                >
                  {muted
                    ? <VolumeX size={15} className="text-gray-500" />
                    : <Volume2 size={15} style={{ color: accentColor }} />
                  }
                </button>

                {/* Prev / Play / Next */}
                <div className="flex items-center gap-2.5 sm:gap-4">
                  <motion.button
                    whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
                    onClick={prev}
                    className="w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center"
                    style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}
                  >
                    <SkipBack size={15} className="text-gray-300" />
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.94 }}
                    onClick={togglePlay}
                    className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center overflow-hidden"
                    style={{
                      background: `linear-gradient(135deg, ${accentColor}, ${accentColor}aa)`,
                      boxShadow: `0 0 28px ${accentColor}55`,
                      transition: "background 0.4s, box-shadow 0.4s",
                    }}
                  >
                    {/* Shimmer */}
                    <motion.span className="absolute inset-0 rounded-full"
                      style={{ background: "linear-gradient(110deg, transparent 30%, rgba(255,255,255,0.18) 50%, transparent 70%)", backgroundSize: "200% 100%" }}
                      animate={{ backgroundPosition: ["200% 0", "-200% 0"] }}
                      transition={{ duration: 2.5, repeat: Infinity, ease: "linear" }} />
                    <AnimatePresence mode="wait">
                      {loading
                        ? <motion.div key="load"
                            animate={{ rotate: 360 }}
                            transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                            className="w-5 h-5 rounded-full border-2 border-white/30 border-t-white"
                          />
                        : playing
                          ? <motion.div key="pause" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>
                              <Pause size={20} fill="black" color="black" />
                            </motion.div>
                          : <motion.div key="play" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>
                              <Play size={20} fill="black" color="black" style={{ marginLeft: 2 }} />
                            </motion.div>
                      }
                    </AnimatePresence>
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
                    onClick={next}
                    className="w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center"
                    style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}
                  >
                    <SkipForward size={15} className="text-gray-300" />
                  </motion.button>
                </div>

                {/* Waveform indicator */}
                <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center overflow-hidden flex-shrink-0"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
                  <Waveform playing={playing} color={accentColor} />
                </div>
              </div>
            </div>
          </motion.div>

          {/* ── RIGHT: Playlist ── */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          >
            <div
              ref={playlistRef}
              className="space-y-1.5 sm:space-y-2 pr-1 max-h-[400px] sm:max-h-none overflow-y-auto sm:overflow-visible"
              style={{ scrollbarWidth: "thin" }}
            >
              {USE_CASES.map((uc, i) => {
                const isActive = i === activeIdx;
                const color = uc.avatarColor;
                return (
                  <motion.button
                    key={uc.key}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: 0.15 + i * 0.06 }}
                    onClick={() => selectTrack(i)}
                    whileHover={{ x: 3 }}
                    className="w-full flex items-center gap-2.5 sm:gap-3.5 px-3 sm:px-4 py-2.5 sm:py-3 rounded-xl text-left transition-all duration-300 group"
                    style={{
                      background: isActive
                        ? `linear-gradient(135deg, ${color}22, ${color}10)`
                        : "rgba(255,255,255,0.025)",
                      border: `1px solid ${isActive ? color + "40" : "rgba(255,255,255,0.06)"}`,
                      boxShadow: isActive ? `0 4px 20px ${color}20` : "none",
                    }}
                    data-testid={`use-case-track-${uc.key}`}
                  >
                    {/* Play indicator / avatar */}
                    <div className="relative flex-shrink-0">
                      <Avatar initials={uc.avatarInitials} color={color} size={34} />
                      {isActive && playing && (
                        <div className="absolute inset-0 rounded-full flex items-center justify-center overflow-hidden"
                          style={{ background: `${color}cc` }}>
                          <Waveform playing color="#fff" />
                        </div>
                      )}
                      {isActive && !playing && (
                        <div className="absolute inset-0 rounded-full flex items-center justify-center"
                          style={{ background: `${color}cc` }}>
                          <Play size={14} fill="white" color="white" style={{ marginLeft: 1 }} />
                        </div>
                      )}
                    </div>

                    {/* Text */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1 sm:gap-1.5 mb-0.5">
                        <p className={`text-xs sm:text-sm font-bold truncate leading-snug ${isActive ? "text-white" : "text-white/70 group-hover:text-white/90"}`}>
                          {t(`landing.useCasesSection.cases.${uc.key}.title`)}
                        </p>
                        <span className="text-xs sm:text-sm flex-shrink-0">{flagEmoji[uc.flag]}</span>
                        <span className="hidden sm:inline text-[9px] font-bold px-1.5 py-0.5 rounded flex-shrink-0"
                          style={{
                            background: `${color}18`,
                            color: color,
                            border: `1px solid ${color}30`,
                          }}>
                          {uc.flag}
                        </span>
                      </div>
                      <p className="text-[10px] sm:text-[11px] text-gray-500 truncate">
                        {t(`landing.useCasesSection.cases.${uc.key}.industry`)} · {t(`landing.useCasesSection.cases.${uc.key}.function`)}
                      </p>
                    </div>

                    {/* Duration / progress */}
                    <div className="flex-shrink-0 text-right">
                      {isActive ? (
                        <span className="text-xs font-bold" style={{ color }}>
                          {fmt(current)}
                        </span>
                      ) : (
                        <span className="text-[11px] text-gray-600 group-hover:text-gray-400 transition-colors">
                          {/* duration shown once loaded */}
                          —
                        </span>
                      )}
                    </div>
                  </motion.button>
                );
              })}
            </div>

            {/* Track count */}
            <p className="text-[11px] text-gray-600 text-right mt-3 pr-1">
              {activeIdx + 1} / {USE_CASES.length} tracks
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export default UseCasesSection;