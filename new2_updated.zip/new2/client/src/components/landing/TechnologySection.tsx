/**
 * TechnologySection — Advanced Redesign
 * Brand: #4d1c95 → #000000 | primary #3ccf73
 * Custom inline illustrations per card, circular tech graphic, curve divider
 */
import { motion, useInView } from "framer-motion";
import {
  Zap, Brain, Globe, Calendar,
  Check, Sparkles, Volume2, MessageSquare, ArrowRight,
} from "lucide-react";
import { Link } from "wouter";
import { useRef } from "react";
import { useTranslation } from "react-i18next";

/* ─── Curve divider ───────────────────────── */
const CurveDivider = ({ flip = false }: { flip?: boolean }) => (
  <div className="flex justify-center py-5 pointer-events-none" style={{ transform: flip ? "scaleY(-1)" : "none" }}>
    <svg
      width="60"
      height="180"
      viewBox="0 0 60 180"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M30 6 C72 35, -12 70, 30 103 C72 136, -12 148, 30 174"
        stroke="url(#curveGrad)"
        strokeWidth="1.5"
        strokeLinecap="round"
        fill="none"
      />
      <circle cx="30" cy="6" r="2.5" fill="rgba(255,255,255,0.25)" />
      <circle cx="30" cy="174" r="2.5" fill="rgba(255,255,255,0.25)" />
      <defs>
        <linearGradient id="curveGrad" x1="0" y1="0" x2="0" y2="1" gradientUnits="objectBoundingBox">
          <stop offset="0%" stopColor="rgba(255,255,255,0.0)" />
          <stop offset="30%" stopColor="rgba(255,255,255,0.3)" />
          <stop offset="70%" stopColor="rgba(255,255,255,0.3)" />
          <stop offset="100%" stopColor="rgba(255,255,255,0.0)" />
        </linearGradient>
      </defs>
    </svg>
  </div>
);

/* ─── Circular tech hero graphic ─────────── */
const TechOrb = ({ isInView }: { isInView: boolean }) => (
  <motion.div
    initial={{ opacity: 0, scale: 0.8 }}
    animate={isInView ? { opacity: 1, scale: 1 } : {}}
    transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
    className="relative flex items-center justify-center w-full max-w-[340px] mx-auto aspect-square"
  >
    {/* Outermost faint ring */}
    <motion.div
      animate={{ rotate: 360 }}
      transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
      className="absolute inset-0 rounded-full"
      style={{ border: "1px dashed rgba(77,28,149,0.25)" }}
    />
    {/* Second ring */}
    <motion.div
      animate={{ rotate: -360 }}
      transition={{ duration: 28, repeat: Infinity, ease: "linear" }}
      className="absolute rounded-full"
      style={{ inset: "10%", border: "1px solid rgba(60,207,115,0.12)" }}
    />

    {/* Orbiting nodes */}
    {[
      { angle: 30,  color: "#3ccf73", icon: "⚡", label: "Fast" },
      { angle: 150, color: "#b78af5", icon: "🧠", label: "Smart" },
      { angle: 270, color: "#60a5fa", icon: "🌐", label: "Global" },
    ].map(({ angle, color, icon, label }) => {
      const rad = (angle * Math.PI) / 180;
      const r = 42; // % from center
      const x = 50 + r * Math.cos(rad);
      const y = 50 + r * Math.sin(rad);
      return (
        <motion.div
          key={angle}
          animate={{ y: [0, -5, 0] }}
          transition={{ duration: 3 + angle / 60, repeat: Infinity, ease: "easeInOut", delay: angle / 120 }}
          className="absolute flex flex-col items-center"
          style={{ left: `${x}%`, top: `${y}%`, transform: "translate(-50%, -50%)" }}
        >
          <div
            className="w-11 h-11 rounded-xl flex items-center justify-center text-lg shadow-lg"
            style={{
              background: "linear-gradient(145deg, #1a0535, #0a0018)",
              border: `1px solid ${color}55`,
              boxShadow: `0 0 18px ${color}30`,
            }}
          >
            {icon}
          </div>
          <span className="text-[9px] font-semibold mt-1" style={{ color }}>{label}</span>
        </motion.div>
      );
    })}

    {/* Center hub */}
    <div
      className="relative z-10 w-[38%] aspect-square rounded-2xl flex flex-col items-center justify-center"
      style={{
        background: "linear-gradient(145deg, #200640, #0c0120)",
        border: "1px solid rgba(60,207,115,0.3)",
        boxShadow: "0 0 50px rgba(77,28,149,0.5), 0 0 20px rgba(60,207,115,0.15)",
      }}
    >
      {/* Animated bars inside hub */}
      <div className="flex items-end gap-[3px] h-8">
        {[6,10,14,10,8,12,7].map((h, i) => (
          <motion.div key={i} className="w-[3px] rounded-full"
            style={{ background: "linear-gradient(to top, #4d1c95, #3ccf73)" }}
            animate={{ height: [h * 0.5, h, h * 0.6, h * 0.9, h * 0.5] }}
            transition={{ duration: 1 + i * 0.1, repeat: Infinity, ease: "easeInOut", delay: i * 0.08 }}
          />
        ))}
      </div>
      <span className="text-[10px] font-bold tracking-widest mt-2" style={{ color: "#3ccf73" }}>AI CORE</span>
      {/* Pulse */}
      <div className="absolute inset-0 rounded-2xl animate-ping opacity-[0.06]"
        style={{ background: "#3ccf73" }} />
    </div>

    {/* Background glow */}
    <div className="absolute inset-0 rounded-full blur-3xl"
      style={{ background: "radial-gradient(circle, rgba(77,28,149,0.4) 0%, transparent 65%)" }} />
  </motion.div>
);

/* ─── Card illustrations ──────────────────── */

// 1. Autopilot — CSV + call leads UI
const AutopilotIllustration = () => (
  <div className="relative h-28 flex items-end justify-center gap-2 pb-1">
    {/* CSV file card */}
    <motion.div
      animate={{ y: [0, -3, 0] }}
      transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut" }}
      className="px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-2"
      style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}
    >
      <div className="w-5 h-5 rounded flex items-center justify-center text-[10px]"
        style={{ background: "rgba(60,207,115,0.15)", color: "#3ccf73" }}>📋</div>
      <span className="text-white/60">New CSV List</span>
    </motion.div>
    {/* Arrow */}
    <div className="mb-1"><ArrowRight size={12} style={{ color: "#3ccf73" }} /></div>
    {/* Call leads */}
    <motion.div
      animate={{ y: [0, -4, 0] }}
      transition={{ duration: 2.8, repeat: Infinity, ease: "easeInOut", delay: 0.4 }}
      className="px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-2"
      style={{ background: "rgba(60,207,115,0.08)", border: "1px solid rgba(60,207,115,0.25)" }}
    >
      <span style={{ color: "#3ccf73" }}>📞</span>
      <span style={{ color: "#3ccf73" }}>Call Leads</span>
    </motion.div>
    {/* Glow */}
    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-24 h-6 blur-xl rounded-full"
      style={{ background: "rgba(60,207,115,0.15)" }} />
  </div>
);

// 2. Voice Customization — waveform sliders
const VoiceIllustration = () => (
  <div className="relative h-28 flex flex-col items-center justify-center gap-2">
    {/* Waveform */}
    <div className="flex items-end gap-[2px] h-8">
      {[4, 8, 14, 10, 18, 12, 16, 9, 13, 7, 11, 15, 8, 5].map((h, i) => (
        <motion.div key={i} className="w-[3px] rounded-full"
          style={{ background: `linear-gradient(to top, #4d1c95, #3ccf73)` }}
          animate={{ height: [h * 0.5, h, h * 0.55, h * 0.85, h * 0.5] }}
          transition={{ duration: 0.9 + i * 0.07, repeat: Infinity, ease: "easeInOut", delay: i * 0.055 }}
        />
      ))}
    </div>
    {/* Sliders */}
    {[
      { label: "Speed", pct: 68, color: "#3ccf73" },
      { label: "Pitch",  pct: 45, color: "#b78af5" },
    ].map(({ label, pct, color }) => (
      <div key={label} className="flex items-center gap-2 w-36">
        <span className="text-[10px] text-gray-500 w-8">{label}</span>
        <div className="flex-1 h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.07)" }}>
          <motion.div className="h-full rounded-full"
            style={{ width: `${pct}%`, background: color }}
            initial={{ width: 0 }}
            whileInView={{ width: `${pct}%` }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
          />
        </div>
      </div>
    ))}
  </div>
);

// 3. Sentiment Analysis — emoji reaction circles
const SentimentIllustration = () => (
  <div className="relative h-28 flex items-center justify-center gap-3">
    {[
      { emoji: "😊", label: "Happy", color: "#3ccf73", delay: 0 },
      { emoji: "😐", label: "Neutral", color: "#b78af5", delay: 0.15 },
      { emoji: "😟", label: "Upset", color: "#f87171", delay: 0.3 },
    ].map(({ emoji, label, color, delay }) => (
      <motion.div key={label}
        animate={{ y: [0, -5, 0] }}
        transition={{ duration: 3 + delay, repeat: Infinity, ease: "easeInOut", delay }}
        className="flex flex-col items-center gap-1"
      >
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-xl"
          style={{
            background: `${color}12`,
            border: `1px solid ${color}35`,
            boxShadow: `0 0 14px ${color}20`,
          }}>
          {emoji}
        </div>
        <span className="text-[9px] font-medium" style={{ color }}>{label}</span>
      </motion.div>
    ))}
    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-32 h-4 blur-xl rounded-full"
      style={{ background: "rgba(60,207,115,0.1)" }} />
  </div>
);

// 4. Diarization — speaker transcript bubbles
const DiarizationIllustration = () => (
  <div className="relative h-28 flex flex-col justify-center gap-1.5 px-2">
    {[
      { speaker: "S1", text: "Hello, Guten tag", color: "#3ccf73", align: "left" },
      { speaker: "S2", text: "Hola, Bonjour",   color: "#b78af5", align: "right" },
      { speaker: "S1", text: "Hei",             color: "#3ccf73", align: "left" },
    ].map(({ speaker, text, color, align }, i) => (
      <motion.div key={i}
        initial={{ opacity: 0, x: align === "left" ? -10 : 10 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ delay: i * 0.12 }}
        className={`flex items-center gap-2 ${align === "right" ? "flex-row-reverse" : ""}`}
      >
        <div className="w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-bold flex-shrink-0"
          style={{ background: `${color}20`, border: `1px solid ${color}40`, color }}>
          {speaker}
        </div>
        <div className="px-2.5 py-1 rounded-xl text-[10px] font-medium text-white/70"
          style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.07)" }}>
          {text}
        </div>
      </motion.div>
    ))}
  </div>
);

// 5. Global Conversations — language pills on a globe arc
const GlobalIllustration = () => {
  const langs = ["Hallo", "Olá", "Bonjour", "नमस्ते", "こんにちは", "مرحبا"];
  const colors = ["#3ccf73", "#b78af5", "#60a5fa", "#f59e0b", "#3ccf73", "#b78af5"];
  return (
    <div className="relative h-28 flex flex-wrap items-center justify-center gap-1.5 content-center">
      {langs.map((lang, i) => (
        <motion.span key={lang}
          initial={{ opacity: 0, scale: 0.7 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.08, duration: 0.4 }}
          animate={{ y: [0, i % 2 === 0 ? -3 : 3, 0] }}
          className="px-2.5 py-1 rounded-full text-[10px] font-semibold"
          style={{
            background: `${colors[i]}12`,
            border: `1px solid ${colors[i]}35`,
            color: colors[i],
          }}>
          {lang}
        </motion.span>
      ))}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-28 h-5 blur-xl rounded-full"
        style={{ background: "rgba(77,28,149,0.2)" }} />
    </div>
  );
};

// 6. Real-time Bookings — calendar event cards
const BookingsIllustration = () => (
  <div className="relative h-28 flex flex-col justify-center gap-1.5 px-2">
    {[
      { date: "7th June 2024", label: "Sales Call", color: "#3ccf73" },
      { date: "28 April 2024", label: "Follow-up",  color: "#b78af5" },
    ].map(({ date, label, color }, i) => (
      <motion.div key={date}
        animate={{ x: [0, 2, 0] }}
        transition={{ duration: 3.5 + i, repeat: Infinity, ease: "easeInOut", delay: i * 0.6 }}
        className="flex items-center gap-3 px-3 py-2 rounded-xl"
        style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${color}25` }}
      >
        <div className="w-7 h-7 rounded-lg flex items-center justify-center text-xs"
          style={{ background: `${color}15`, color }}>📅</div>
        <div>
          <p className="text-[10px] text-gray-500">{date}</p>
          <p className="text-xs font-semibold text-white">{label}</p>
        </div>
        <div className="ml-auto w-2 h-2 rounded-full" style={{ background: color }} />
      </motion.div>
    ))}
  </div>
);

/* ─── Tech feature card ───────────────────── */
interface TechCardProps {
  icon: React.ElementType;
  title: string;
  description: string;
  illustration: React.ReactNode;
  accentColor: string;
  delay: number;
}

const TechCard = ({ icon: Icon, title, description, illustration, accentColor, delay }: TechCardProps) => (
  <motion.div
    initial={{ opacity: 0, y: 28, scale: 0.96 }}
    whileInView={{ opacity: 1, y: 0, scale: 1 }}
    viewport={{ once: true, margin: "-40px" }}
    transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
    whileHover={{ y: -4, scale: 1.015 }}
    className="relative rounded-2xl overflow-hidden group cursor-default"
    style={{
      background: "linear-gradient(145deg, rgba(18,4,35,0.95) 0%, rgba(6,0,14,0.98) 100%)",
      border: `1px solid rgba(255,255,255,0.07)`,
      boxShadow: "0 8px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.04)",
      transition: "box-shadow 0.3s, transform 0.3s",
    }}
    onMouseEnter={(e) => {
      (e.currentTarget as HTMLElement).style.boxShadow = `0 16px 48px rgba(0,0,0,0.5), 0 0 0 1px ${accentColor}30, inset 0 1px 0 rgba(255,255,255,0.06)`;
    }}
    onMouseLeave={(e) => {
      (e.currentTarget as HTMLElement).style.boxShadow = "0 8px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.04)";
    }}
  >
    {/* Top accent line */}
    <div className="absolute top-0 left-8 right-8 h-px"
      style={{ background: `linear-gradient(90deg, transparent, ${accentColor}50, transparent)` }} />
    {/* Corner glow */}
    <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full blur-2xl opacity-30 group-hover:opacity-50 transition-opacity"
      style={{ background: accentColor }} />

    <div className="relative z-10 p-5">
      {/* Illustration */}
      {illustration}

      {/* Divider */}
      <div className="h-px my-3" style={{ background: "rgba(255,255,255,0.05)" }} />

      {/* Info row */}
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
          style={{ background: `${accentColor}12`, border: `1px solid ${accentColor}30` }}>
          <Icon size={15} style={{ color: accentColor }} />
        </div>
        <div>
          <h3 className="font-bold text-white text-sm mb-0.5 leading-snug">{title}</h3>
          <p className="text-xs text-gray-500 leading-relaxed">{description}</p>
        </div>
      </div>
    </div>
  </motion.div>
);

/* ─────────────────────────────────────────────
   TECHNOLOGY SECTION
───────────────────────────────────────────── */
export function TechnologySection() {
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  const techFeatures: Array<{
    key: string;
    icon: React.ElementType;
    accentColor: string;
    illustration: React.ReactNode;
  }> = [
    { key: "autopilot",       icon: Zap,           accentColor: "#3ccf73", illustration: <AutopilotIllustration /> },
    { key: "voiceCustomization", icon: Volume2,    accentColor: "#b78af5", illustration: <VoiceIllustration /> },
    { key: "sentimentAnalysis",  icon: Brain,      accentColor: "#f87171", illustration: <SentimentIllustration /> },
    { key: "diarization",     icon: MessageSquare, accentColor: "#60a5fa", illustration: <DiarizationIllustration /> },
    { key: "globalConversations", icon: Globe,     accentColor: "#f59e0b", illustration: <GlobalIllustration /> },
    { key: "realTimeBookings",   icon: Calendar,   accentColor: "#3ccf73", illustration: <BookingsIllustration /> },
  ];

  const benefitKeys = ["cutCosts", "millionCalls", "reduceAttrition"] as const;

  return (
    <section
      ref={ref}
      className="relative overflow-hidden"
      data-testid="technology-section"
    >
      {/* Top curve */}
      <div style={{ background: "linear-gradient(180deg, #000000 0%, #06001a 100%)" }}>
        <CurveDivider />
      </div>

      {/* Main section */}
      <div
        className="relative"
        style={{ background: "linear-gradient(180deg, #06001a 0%, #0c0025 50%, #06001a 100%)" }}
      >
        {/* BG blobs */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[500px] h-[500px] rounded-full blur-[120px]"
            style={{ background: "radial-gradient(circle, rgba(77,28,149,0.28) 0%, transparent 68%)" }} />
          <div className="absolute top-0 right-0 w-[300px] h-[300px] rounded-full blur-[80px]"
            style={{ background: "radial-gradient(circle, rgba(60,207,115,0.05) 0%, transparent 70%)" }} />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-5 sm:px-8 lg:px-10">
          {/* ── Top: text + orb ── */}
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-16 md:mb-20">
            {/* Left text */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
            >
              {/* Badge */}
              <span
                className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-semibold tracking-[0.18em] uppercase mb-6"
                style={{ background: "rgba(60,207,115,0.07)", border: "1px solid rgba(60,207,115,0.2)", color: "#3ccf73" }}
              >
                <Sparkles size={10} />
                {t("landing.technology.badge")}
              </span>

              <h2 className="text-3xl sm:text-4xl md:text-5xl font-black leading-tight tracking-tight mb-6">
                <span className="text-white">{t("landing.technology.title").split(".")[0]}.</span>
                <br />
                <span
                  style={{
                    background: "linear-gradient(135deg, #b78af5 0%, #3ccf73 100%)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                  }}
                >
                  {t("landing.technology.title").split(".").slice(1).join(".")}
                </span>
              </h2>

              <ul className="space-y-3 mb-8">
                {benefitKeys.map((key, i) => (
                  <motion.li
                    key={key}
                    initial={{ opacity: 0, x: -12 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.4, delay: 0.3 + i * 0.1 }}
                    className="flex items-start gap-3"
                  >
                    <span className="w-5 h-5 rounded-full flex items-center justify-center mt-0.5 flex-shrink-0"
                      style={{ background: "rgba(60,207,115,0.1)", border: "1px solid rgba(60,207,115,0.25)" }}>
                      <Check size={10} style={{ color: "#3ccf73" }} />
                    </span>
                    <span className="text-gray-300 text-[15px] leading-relaxed"
                      dangerouslySetInnerHTML={{ __html: t(`landing.technology.benefits.${key}`) }} />
                  </motion.li>
                ))}
              </ul>

              {/* CTA */}
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                <Link href="/login">
                  <motion.button
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    className="relative inline-flex items-center gap-2 px-8 py-3 rounded-full font-bold text-sm text-black overflow-hidden"
                    style={{
                      background: "linear-gradient(135deg, #3ccf73 0%, #2aaa58 100%)",
                      boxShadow: "0 0 36px rgba(60,207,115,0.28), 0 4px 20px rgba(0,0,0,0.5)",
                    }}
                    data-testid="button-tech-get-started"
                  >
                    <motion.span className="absolute inset-0 rounded-full"
                      style={{ background: "linear-gradient(110deg, transparent 30%, rgba(255,255,255,0.22) 50%, transparent 70%)", backgroundSize: "200% 100%" }}
                      animate={{ backgroundPosition: ["200% 0", "-200% 0"] }}
                      transition={{ duration: 2.8, repeat: Infinity, ease: "linear" }}
                    />
                    <span className="relative">{t("landing.technology.getStarted")}</span>
                    <ArrowRight size={14} className="relative" />
                  </motion.button>
                </Link>
                <div className="flex items-center gap-4 text-xs text-gray-600">
                  <span className="flex items-center gap-1.5">
                    <Check size={11} style={{ color: "#3ccf73" }} />
                    {t("landing.technology.freeTrial")}
                  </span>
                  <span className="hidden sm:block w-px h-3 bg-white/10" />
                  <span className="flex items-center gap-1.5">
                    <Check size={11} style={{ color: "#3ccf73" }} />
                    {t("landing.technology.freeCredit")}
                  </span>
                </div>
              </div>
            </motion.div>

            {/* Right: orb */}
            <TechOrb isInView={isInView} />
          </div>

          {/* ── 6-card grid ── */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
            {techFeatures.map((feat, i) => (
              <TechCard
                key={feat.key}
                icon={feat.icon}
                title={t(`landing.technology.features.${feat.key}.title`)}
                description={t(`landing.technology.features.${feat.key}.description`)}
                illustration={feat.illustration}
                accentColor={feat.accentColor}
                delay={i * 0.07}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Bottom curve */}
      <div style={{ background: "linear-gradient(180deg, #06001a 0%, #000000 100%)" }}>
        <CurveDivider flip />
      </div>
    </section>
  );
}

export default TechnologySection;