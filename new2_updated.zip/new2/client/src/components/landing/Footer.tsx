/**
 * Footer — Advanced Redesign
 * Brand: #4d1c95 → #000000 | primary #3ccf73
 * Layout: logo + tagline + newsletter | links | contact | social
 */
import { Link } from "wouter";
import { Twitter, Linkedin, Github, Mail, MapPin, ArrowRight, Zap } from "lucide-react";
import { useBranding } from "@/components/BrandingProvider";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

/* ─── Link data ───────────────────────────────── */
const productLinks = [
  { href: "/features",     label: "Features" },
  { href: "/use-cases",    label: "Use Cases" },
  { href: "/pricing",      label: "Pricing" },
  { href: "/integrations", label: "Integrations" },
];
const resourceLinks = [
  { href: "/blog",    label: "Blog" },
  { href: "/contact", label: "Contact" },
  { href: "/privacy", label: "Privacy Policy" },
  { href: "/terms",   label: "Terms of Service" },
];

/* ─── Mini waveform ───────────────────────────── */
const MiniWave = () => (
  <div className="flex items-end gap-[2px] h-4 opacity-70">
    {[4, 7, 5, 9, 6, 8, 4].map((h, i) => (
      <motion.div key={i} className="w-[2px] rounded-full"
        style={{ background: "linear-gradient(to top, #4d1c95, #3ccf73)" }}
        animate={{ height: [h * 0.5, h, h * 0.55, h * 0.85, h * 0.5] }}
        transition={{ duration: 1 + i * 0.09, repeat: Infinity, ease: "easeInOut", delay: i * 0.07 }} />
    ))}
  </div>
);

/* ─── Footer link ─────────────────────────────── */
const FLink = ({ href, label, testId }: { href: string; label: string; testId: string }) => (
  <li>
    <Link href={href}
      className="text-sm text-gray-500 hover:text-white transition-colors duration-200 flex items-center gap-1.5 group w-fit"
      data-testid={testId}>
      <span className="w-1 h-1 rounded-full flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
        style={{ background: "#3ccf73" }} />
      {label}
    </Link>
  </li>
);

/* ─────────────────────────────────────────────
   FOOTER
───────────────────────────────────────────── */
export function Footer() {
  const { branding } = useBranding();
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);
  const { toast } = useToast();

  const socialLinks = [
    branding.social_twitter_url  ? { href: branding.social_twitter_url,  label: "Twitter",  Icon: Twitter  } : null,
    branding.social_linkedin_url ? { href: branding.social_linkedin_url, label: "LinkedIn", Icon: Linkedin } : null,
    branding.social_github_url   ? { href: branding.social_github_url,   label: "GitHub",   Icon: Github   } : null,
  ].filter(Boolean) as { href: string; label: string; Icon: typeof Twitter }[];

  const supportEmail = `support@${branding.app_name?.toLowerCase().replace(/\s+/g, "") || "example"}.com`;

  const handleNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    toast({ title: "Thanks for subscribing!", description: "You'll receive our latest updates." });
    setEmail("");
    setSubscribed(true);
    setTimeout(() => setSubscribed(false), 3000);
  };

  return (
    <footer
      className="relative overflow-hidden"
      style={{ background: "linear-gradient(180deg, #000000 0%, #03000a 100%)" }}
      data-testid="footer"
    >
      {/* Top border line */}
      <div className="absolute top-0 left-0 right-0 h-px"
        style={{ background: "linear-gradient(90deg, transparent, rgba(60,207,115,0.25), rgba(77,28,149,0.3), rgba(60,207,115,0.25), transparent)" }} />

      {/* BG glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute bottom-0 left-1/3 w-[500px] h-[300px] rounded-full blur-[120px]"
          style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.12) 0%, transparent 65%)" }} />
        <div className="absolute top-0 right-1/4 w-[300px] h-[200px] rounded-full blur-[90px]"
          style={{ background: "radial-gradient(circle, rgba(60,207,115,0.04) 0%, transparent 70%)" }} />
      </div>

      {/* Traveling scan line */}
      <motion.div
        className="absolute top-0 left-0 w-40 h-px pointer-events-none"
        style={{ background: "linear-gradient(90deg, transparent, rgba(60,207,115,0.6), transparent)" }}
        animate={{ x: ["-160px", "calc(100vw + 160px)"] }}
        transition={{ duration: 5, repeat: Infinity, ease: "linear", repeatDelay: 4 }}
      />

      <div className="relative z-10 max-w-6xl mx-auto px-5 sm:px-8 lg:px-10">
        {/* ── Main grid ── */}
        <div className="py-14 sm:py-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-[1.6fr_1fr_1fr_1fr] gap-10 lg:gap-8">

          {/* ── Col 1: Brand + newsletter + social ── */}
          <div className="space-y-6">
            {/* Logo */}
            <div className="flex items-center gap-2.5">
              {branding.logo_url_dark ? (
                <img src={branding.logo_url_dark} alt={branding.app_name || "Logo"}
                  className="h-9 w-auto max-w-[160px] object-contain"
                  data-testid="img-footer-logo" />
              ) : (
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{ background: "linear-gradient(135deg, #4d1c95, #3ccf73)" }}>
                    <Zap size={16} color="#fff" />
                  </div>
                  <span className="text-base font-black text-white">{branding.app_name}</span>
                </div>
              )}
              <MiniWave />
            </div>

            {/* Tagline */}
            <p className="text-sm text-gray-500 leading-relaxed max-w-xs">
              {branding.app_tagline || "Build, deploy, and monitor production-ready AI voice agents at scale."}
            </p>

            {/* Newsletter */}
            <div>
              <p className="text-xs font-bold tracking-widest uppercase mb-2.5" style={{ color: "#3ccf73" }}>
                Stay Updated
              </p>
              <form onSubmit={handleNewsletter} className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type="email" value={email} onChange={e => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full text-sm text-white placeholder-white/20 bg-transparent outline-none py-2.5 px-3 rounded-xl"
                    style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
                    data-testid="input-newsletter-email"
                  />
                </div>
                <motion.button type="submit"
                  whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    background: subscribed
                      ? "rgba(60,207,115,0.2)"
                      : "linear-gradient(135deg, #3ccf73, #2aaa58)",
                    boxShadow: subscribed ? "none" : "0 0 16px rgba(60,207,115,0.3)",
                  }}
                  data-testid="button-newsletter-submit">
                  <ArrowRight size={15} color={subscribed ? "#3ccf73" : "#000"} />
                </motion.button>
              </form>
            </div>

            {/* Social */}
            {socialLinks.length > 0 && (
              <div className="flex gap-2.5">
                {socialLinks.map(({ href, label, Icon }) => (
                  <a key={label} href={href} target="_blank" rel="noopener noreferrer"
                    className="w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200 group"
                    style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(60,207,115,0.3)"; (e.currentTarget as HTMLElement).style.background = "rgba(60,207,115,0.08)"; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.07)"; (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; }}
                    data-testid={`link-footer-${label.toLowerCase()}`} aria-label={label}>
                    <Icon size={15} className="text-gray-500 group-hover:text-white transition-colors" />
                  </a>
                ))}
              </div>
            )}
          </div>

          {/* ── Col 2: Product ── */}
          <div className="space-y-4">
            <h3 className="text-[10px] font-bold tracking-[0.2em] uppercase"
              style={{ color: "rgba(255,255,255,0.3)" }}>Product</h3>
            <ul className="space-y-2.5">
              {productLinks.map(l => (
                <FLink key={l.href} href={l.href} label={l.label}
                  testId={`link-footer-${l.label.toLowerCase().replace(/\s+/g, "-")}`} />
              ))}
            </ul>
          </div>

          {/* ── Col 3: Resources ── */}
          <div className="space-y-4">
            <h3 className="text-[10px] font-bold tracking-[0.2em] uppercase"
              style={{ color: "rgba(255,255,255,0.3)" }}>Resources</h3>
            <ul className="space-y-2.5">
              {resourceLinks.map(l => (
                <FLink key={l.href} href={l.href} label={l.label}
                  testId={`link-footer-${l.label.toLowerCase().replace(/\s+/g, "-")}`} />
              ))}
            </ul>
          </div>

          {/* ── Col 4: Contact ── */}
          <div className="space-y-4">
            <h3 className="text-[10px] font-bold tracking-[0.2em] uppercase"
              style={{ color: "rgba(255,255,255,0.3)" }}>Contact</h3>
            <ul className="space-y-3">
              <li>
                <a href={`mailto:${supportEmail}`}
                  className="flex items-center gap-2.5 text-sm text-gray-500 hover:text-white transition-colors group w-fit"
                  data-testid="link-footer-email">
                  <span className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors"
                    style={{ background: "rgba(60,207,115,0.08)", border: "1px solid rgba(60,207,115,0.2)" }}>
                    <Mail size={13} style={{ color: "#3ccf73" }} />
                  </span>
                  <span className="group-hover:text-white transition-colors break-all">{supportEmail}</span>
                </a>
              </li>
              <li className="flex items-start gap-2.5 text-sm text-gray-500">
                <span className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                  style={{ background: "rgba(77,28,149,0.12)", border: "1px solid rgba(77,28,149,0.3)" }}>
                  <MapPin size={13} style={{ color: "#b78af5" }} />
                </span>
                <span>San Francisco, CA</span>
              </li>
            </ul>

            {/* Live indicator */}
            <div className="flex items-center gap-2 mt-2">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse flex-shrink-0" />
              <span className="text-[11px] text-gray-600">All systems operational</span>
            </div>
          </div>
        </div>

        {/* ── Bottom bar ── */}
        <div className="py-5 flex flex-col sm:flex-row items-center justify-between gap-4"
          style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
          <p className="text-xs text-gray-600" data-testid="text-copyright">
            © {new Date().getFullYear()}{" "}
            <span className="text-gray-500">{branding.app_name}</span>.
            {" "}All rights reserved.
          </p>
          <div className="flex items-center gap-5 text-xs text-gray-600">
            {[
              { href: "/privacy", label: "Privacy" },
              { href: "/terms",   label: "Terms" },
              { href: "/cookies", label: "Cookies" },
            ].map(({ href, label }) => (
              <Link key={href} href={href}
                className="hover:text-white transition-colors duration-200">
                {label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;