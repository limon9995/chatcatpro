/**
 * TestimonialsSection — Advanced Redesign
 * Brand: #4d1c95 → #000000 | primary #3ccf73
 * Layout: 4-column infinite scroll, alternating up/down, glassmorphism cards
 */
import { Star, Quote, Zap } from "lucide-react";
import { useBranding } from "@/components/BrandingProvider";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { useTranslation } from "react-i18next";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

/* ─── Data ────────────────────────────────────── */
const testimonialKeys = [
  "jennifer","lisa","mike","robert","tom","amanda",
  "james","maria","rachel","carlos","sarah","david",
];

const testimonialImages: Record<string, string> = {
  jennifer: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
  lisa:     "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150",
  mike:     "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150",
  robert:   "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
  tom:      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150",
  amanda:   "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
  james:    "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150",
  maria:    "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150",
  rachel:   "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=150",
  carlos:   "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150",
  sarah:    "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150",
  david:    "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150",
};

/* accent color per card index — cycles through a palette */
const ACCENTS = ["#3ccf73","#b78af5","#60a5fa","#f59e0b","#f472b6","#34d399"];
const accent = (i: number) => ACCENTS[i % ACCENTS.length];

interface Testimonial {
  quote: string;
  highlight?: string;
  author: string;
  role: string;
  company: string;
  image: string;
  rating: number;
}

/* ─── Star rating ─────────────────────────────── */
const StarRating = ({ count = 5, color = "#f59e0b" }: { count?: number; color?: string }) => (
  <div className="flex gap-0.5">
    {Array.from({ length: count }).map((_, i) => (
      <Star key={i} size={12} fill={color} style={{ color }} />
    ))}
  </div>
);

/* ─── Single card ─────────────────────────────── */
const TestimonialCard = ({
  testimonial, globalIdx, atText,
}: {
  testimonial: Testimonial; globalIdx: number; atText: string;
}) => {
  const col = accent(globalIdx);
  return (
    <div
      className="relative rounded-2xl p-4 mb-3 group cursor-default"
      style={{
        background: "linear-gradient(145deg, rgba(16,3,32,0.96) 0%, rgba(5,0,12,0.98) 100%)",
        border: "1px solid rgba(255,255,255,0.07)",
        boxShadow: "0 4px 24px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.04)",
        transition: "border-color 0.25s, box-shadow 0.25s",
      }}
      onMouseEnter={e => {
        const el = e.currentTarget as HTMLElement;
        el.style.borderColor = `${col}40`;
        el.style.boxShadow = `0 8px 32px rgba(0,0,0,0.5), 0 0 0 1px ${col}25`;
      }}
      onMouseLeave={e => {
        const el = e.currentTarget as HTMLElement;
        el.style.borderColor = "rgba(255,255,255,0.07)";
        el.style.boxShadow = "0 4px 24px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.04)";
      }}
      data-testid={`testimonial-card-${globalIdx}`}
    >
      {/* Top accent line */}
      <div className="absolute top-0 left-6 right-6 h-px rounded-full"
        style={{ background: `linear-gradient(90deg, transparent, ${col}45, transparent)` }} />
      {/* Quote icon */}
      <div className="absolute top-3 right-3 opacity-10 group-hover:opacity-20 transition-opacity">
        <Quote size={20} style={{ color: col }} />
      </div>

      {/* Stars */}
      <StarRating count={testimonial.rating} color={col} />

      {/* Quote */}
      <p className="text-xs text-gray-400 leading-relaxed mt-2.5 mb-3" data-testid={`testimonial-quote-${globalIdx}`}>
        {testimonial.quote}
        {testimonial.highlight && (
          <span className="font-semibold" style={{ color: col }}> {testimonial.highlight}</span>
        )}
      </p>

      {/* Author */}
      <div className="flex items-center gap-2.5">
        <Avatar className="h-8 w-8 flex-shrink-0">
          <AvatarImage src={testimonial.image} alt={testimonial.author} className="object-cover" />
          <AvatarFallback
            className="text-[10px] font-bold"
            style={{ background: `${col}20`, color: col }}
          >
            {testimonial.author.split(" ").map(n => n[0]).join("")}
          </AvatarFallback>
        </Avatar>
        <div>
          <p className="text-xs font-bold text-white leading-tight" data-testid={`testimonial-author-${globalIdx}`}>
            {testimonial.author}
          </p>
          <p className="text-[10px] text-gray-600 leading-tight" data-testid={`testimonial-role-${globalIdx}`}>
            {testimonial.role} {atText} {testimonial.company}
          </p>
        </div>
      </div>
    </div>
  );
};

/* ─── Scroll column ───────────────────────────── */
const ScrollColumn = ({
  testimonials, direction, speed, colIdx, atText,
}: {
  testimonials: Testimonial[]; direction: "up" | "down"; speed: number; colIdx: number; atText: string;
}) => {
  const animName = direction === "up" ? `scroll-up-${colIdx}` : `scroll-down-${colIdx}`;
  return (
    <>
      <style>{`
        @keyframes ${animName} {
          from { transform: translateY(${direction === "up" ? "0" : "-50%"}); }
          to   { transform: translateY(${direction === "up" ? "-50%" : "0"}); }
        }
      `}</style>
      <div style={{ animation: `${animName} ${speed}s linear infinite` }}>
        {[...testimonials, ...testimonials].map((t, i) => (
          <TestimonialCard
            key={`${colIdx}-${i}`}
            testimonial={t}
            globalIdx={colIdx * 100 + (i % testimonials.length)}
            atText={atText}
          />
        ))}
      </div>
    </>
  );
};

/* ─────────────────────────────────────────────
   MAIN SECTION
───────────────────────────────────────────── */
export function TestimonialsSection() {
  const { branding } = useBranding();
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  const allTestimonials: Testimonial[] = testimonialKeys.map(key => ({
    quote:     t(`landing.testimonials.quotes.${key}.quote`, { appName: branding.app_name }),
    highlight: t(`landing.testimonials.quotes.${key}.highlight`),
    author:    t(`landing.testimonials.quotes.${key}.author`),
    role:      t(`landing.testimonials.quotes.${key}.role`),
    company:   t(`landing.testimonials.quotes.${key}.company`),
    image:     testimonialImages[key],
    rating:    5,
  }));

  /* 4 columns */
  const columns: Testimonial[][] = [[], [], [], []];
  allTestimonials.forEach((t, i) => columns[i % 4].push(t));

  const speeds     = [48, 40, 54, 44];
  const directions = ["up", "down", "up", "down"] as const;

  const atText = t("landing.testimonials.at");

  return (
    <section
      ref={ref}
      id="testimonials"
      className="relative overflow-hidden py-16 sm:py-20 md:py-28"
      style={{ background: "linear-gradient(180deg, #000000 0%, #04000e 55%, #000000 100%)" }}
      data-testid="testimonials-section"
    >
      {/* BG blobs */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-1/4 w-[500px] h-[300px] rounded-full blur-[120px]"
          style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.18) 0%, transparent 70%)" }} />
        <div className="absolute bottom-1/3 right-1/4 w-[400px] h-[250px] rounded-full blur-[100px]"
          style={{ background: "radial-gradient(ellipse, rgba(60,207,115,0.05) 0%, transparent 70%)" }} />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-5 sm:px-8 lg:px-10">
        {/* ── Header ── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 md:mb-16"
        >
          <span
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-semibold tracking-[0.18em] uppercase mb-5"
            style={{ background: "rgba(60,207,115,0.07)", border: "1px solid rgba(60,207,115,0.2)", color: "#3ccf73" }}
          >
            <Zap size={10} /> Testimonials
          </span>

          <h2
            className="text-3xl sm:text-4xl md:text-5xl font-black text-white leading-tight tracking-tight mb-4"
            data-testid="testimonials-headline"
          >
            {t("landing.testimonials.title")}
          </h2>
          <p className="text-base text-gray-400 max-w-xl mx-auto leading-relaxed">
            {t("landing.testimonials.subtitle", { appName: branding.app_name })}
          </p>

          {/* aggregate star row */}
          <div className="flex items-center justify-center gap-2 mt-5">
            <StarRating count={5} color="#f59e0b" />
            <span className="text-sm font-bold text-white">4.9</span>
            <span className="text-xs text-gray-500">/ 5 · 1,200+ reviews</span>
          </div>
        </motion.div>

        {/* ── Scrolling columns ── */}
        <div
          className="relative h-[460px] sm:h-[520px] md:h-[620px] lg:h-[700px] overflow-hidden"
          style={{
            maskImage: "linear-gradient(to bottom, transparent 0%, black 8%, black 92%, transparent 100%)",
            WebkitMaskImage: "linear-gradient(to bottom, transparent 0%, black 8%, black 92%, transparent 100%)",
          }}
        >
          <div
            className="grid grid-cols-2 md:grid-cols-4 gap-3"
            data-testid="testimonials-grid"
          >
            {columns.map((col, i) => (
              <div key={i} className="overflow-hidden">
                <ScrollColumn
                  testimonials={col}
                  direction={directions[i]}
                  speed={speeds[i]}
                  colIdx={i}
                  atText={atText}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export default TestimonialsSection;