/**
 * ContactSection — Advanced Redesign
 * Brand: #4d1c95 → #000000 | primary #3ccf73
 * Full form with react-hook-form + zod validation + API mutation
 */
import { motion, useReducedMotion, useInView } from "framer-motion";
import {
  Mail, Clock, Users, Send, Shield, CheckCircle,
  Loader2, MessageSquare, Headphones, Zap, ArrowRight,
} from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form, FormControl, FormField, FormItem, FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useBranding } from "@/components/BrandingProvider";
import { useTranslation } from "react-i18next";
import { useRef } from "react";

/* ─── Schema ──────────────────────────────────── */
const contactFormSchema = z.object({
  name:    z.string().min(2, "Name must be at least 2 characters"),
  email:   z.string().email("Please enter a valid email address"),
  company: z.string().optional(),
  message: z.string().min(10, "Message must be at least 10 characters"),
});
type ContactFormData = z.infer<typeof contactFormSchema>;

/* ─── Floating label input ────────────────────── */
const DarkInput = ({
  field, label, id, type = "text", placeholder, required, accent = "#3ccf73",
  error, "data-testid": testId,
}: {
  field: any; label: string; id: string; type?: string; placeholder?: string;
  required?: boolean; accent?: string; error?: string; "data-testid"?: string;
}) => {
  const hasValue = !!field.value;
  return (
    <div className="space-y-1">
      <div
        className="relative rounded-xl overflow-hidden transition-all duration-200"
        style={{
          background: "rgba(255,255,255,0.03)",
          border: `1px solid ${error ? "#f87171" : hasValue ? `${accent}40` : "rgba(255,255,255,0.08)"}`,
        }}
      >
        <label htmlFor={id}
          className="absolute left-4 text-[10px] font-bold tracking-widest uppercase transition-colors"
          style={{ top: 8, color: error ? "#f87171" : hasValue ? accent : "rgba(255,255,255,0.3)" }}
        >
          {label}{required && <span style={{ color: accent }}> *</span>}
        </label>
        <input
          id={id} type={type} placeholder={placeholder}
          data-testid={testId}
          {...field}
          className="w-full bg-transparent text-white text-sm pt-6 pb-2.5 px-4 outline-none placeholder-white/20"
          style={{ caretColor: accent }}
        />
      </div>
      {error && <p className="text-xs text-red-400 pl-1">{error}</p>}
    </div>
  );
};

/* ─── Floating label textarea ─────────────────── */
const DarkTextarea = ({
  field, label, id, placeholder, required, accent = "#3ccf73",
  error, "data-testid": testId,
}: {
  field: any; label: string; id: string; placeholder?: string;
  required?: boolean; accent?: string; error?: string; "data-testid"?: string;
}) => {
  const hasValue = !!field.value;
  return (
    <div className="space-y-1">
      <div
        className="relative rounded-xl overflow-hidden transition-all duration-200"
        style={{
          background: "rgba(255,255,255,0.03)",
          border: `1px solid ${error ? "#f87171" : hasValue ? `${accent}40` : "rgba(255,255,255,0.08)"}`,
        }}
      >
        <label htmlFor={id}
          className="absolute left-4 text-[10px] font-bold tracking-widest uppercase"
          style={{ top: 10, color: error ? "#f87171" : hasValue ? accent : "rgba(255,255,255,0.3)" }}
        >
          {label}{required && <span style={{ color: accent }}> *</span>}
        </label>
        <textarea
          id={id} placeholder={placeholder}
          data-testid={testId}
          {...field}
          rows={4}
          className="w-full bg-transparent text-white text-sm pt-7 pb-3 px-4 outline-none resize-none placeholder-white/20"
          style={{ caretColor: accent }}
        />
      </div>
      {error && <p className="text-xs text-red-400 pl-1">{error}</p>}
    </div>
  );
};

/* ─── Trust item ──────────────────────────────── */
const TrustItem = ({
  icon: Icon, text, accent, testId,
}: { icon: React.ElementType; text: string; accent: string; testId: string }) => (
  <div className="flex items-center gap-3" data-testid={testId}>
    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
      style={{ background: `${accent}10`, border: `1px solid ${accent}25` }}>
      <Icon size={15} style={{ color: accent }} />
    </div>
    <span className="text-sm text-gray-400 leading-snug">{text}</span>
  </div>
);

/* ─────────────────────────────────────────────
   MAIN
───────────────────────────────────────────── */
export function ContactSection() {
  const shouldReduceMotion = useReducedMotion();
  const { toast } = useToast();
  const { branding } = useBranding();
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  const supportEmail = `support@${branding.app_name?.toLowerCase().replace(/\s+/g, "") || "example"}.com`;

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: { name: "", email: "", company: "", message: "" },
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: (data) => {
      form.reset();
      toast({
        title: t("landing.contact.toast.successTitle"),
        description: data.message || t("landing.contact.toast.successDescription"),
      });
    },
    onError: (error: any) => {
      toast({
        title: t("landing.contact.toast.errorTitle"),
        description: error.message || t("landing.contact.toast.errorDescription"),
        variant: "destructive",
      });
    },
  });

  return (
    <section
      ref={ref}
      id="contact"
      className="relative overflow-hidden py-16 sm:py-20 md:py-28"
      style={{ background: "linear-gradient(180deg, #000000 0%, #05000f 55%, #000000 100%)" }}
      data-testid="section-contact"
    >
      {/* BG blobs */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[500px] h-[400px] rounded-full blur-[130px]"
          style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.2) 0%, transparent 65%)" }} />
        <div className="absolute bottom-0 right-1/3 w-[350px] h-[300px] rounded-full blur-[100px]"
          style={{ background: "radial-gradient(circle, rgba(60,207,115,0.05) 0%, transparent 70%)" }} />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-5 sm:px-8 lg:px-10">
        <div className="grid lg:grid-cols-[1fr_1.2fr] gap-10 lg:gap-16 items-start">

          {/* ── LEFT ── */}
          <motion.div
            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, x: -28 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
            className="space-y-8 pt-2"
          >
            {/* Badge */}
            <span
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-semibold tracking-[0.18em] uppercase"
              style={{ background: "rgba(60,207,115,0.07)", border: "1px solid rgba(60,207,115,0.2)", color: "#3ccf73" }}
            >
              <MessageSquare size={10} />
              {t("landing.contact.badge")}
            </span>

            {/* Heading */}
            <div className="space-y-3">
              <h2
                className="text-3xl sm:text-4xl md:text-5xl font-black leading-tight tracking-tight"
                data-testid="heading-contact"
              >
                <span className="text-white">{t("landing.contact.title")}</span>
              </h2>
              <p
                className="text-[15px] text-gray-400 leading-relaxed max-w-sm"
                data-testid="text-contact-description"
              >
                {t("landing.contact.description", { appName: branding.app_name })}
              </p>
            </div>

            {/* Email link */}
            <motion.a
              href={`mailto:${supportEmail}`}
              className="flex items-center gap-4 group w-fit"
              whileHover={shouldReduceMotion ? {} : { x: 4 }}
              data-testid="link-contact-email"
            >
              <div
                className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-105"
                style={{
                  background: "linear-gradient(135deg, #3ccf73, #2aaa58)",
                  boxShadow: "0 0 24px rgba(60,207,115,0.3)",
                }}
              >
                <Mail size={20} color="#000" />
              </div>
              <div>
                <p className="text-[10px] text-gray-600 uppercase tracking-widest font-semibold mb-0.5">
                  {t("landing.contact.emailLabel")}
                </p>
                <p className="text-sm font-bold text-white group-hover:underline decoration-green-400/40 underline-offset-2">
                  {supportEmail}
                </p>
              </div>
            </motion.a>

            {/* Divider */}
            <div className="h-px" style={{ background: "rgba(255,255,255,0.06)" }} />

            {/* Trust items */}
            <div className="space-y-3.5">
              <TrustItem icon={Clock}       text={t("landing.contact.trustResponseTime")}   accent="#3ccf73"  testId="trust-response-time" />
              <TrustItem icon={Users}       text={t("landing.contact.trustCustomerCount")}  accent="#b78af5"  testId="trust-customer-count" />
              <TrustItem icon={Headphones}  text={t("landing.contact.trustConsultation")}   accent="#60a5fa"  testId="trust-free-consultation" />
              <TrustItem icon={CheckCircle} text={t("landing.contact.trustNoCommitment")}   accent="#3ccf73"  testId="trust-no-commitment" />
            </div>
          </motion.div>

          {/* ── RIGHT: form card ── */}
          <motion.div
            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, x: 28 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.65, delay: 0.12, ease: [0.22, 1, 0.36, 1] }}
          >
            <div
              className="relative rounded-2xl overflow-hidden p-6 md:p-8"
              style={{
                background: "linear-gradient(145deg, rgba(18,4,38,0.97) 0%, rgba(6,0,14,0.99) 100%)",
                border: "1px solid rgba(77,28,149,0.25)",
                boxShadow: "0 24px 64px rgba(0,0,0,0.55), inset 0 1px 0 rgba(255,255,255,0.04)",
              }}
              data-testid="card-contact-form"
            >
              {/* Top accent */}
              <div className="absolute top-0 left-8 right-8 h-px"
                style={{ background: "linear-gradient(90deg, transparent, rgba(60,207,115,0.45), transparent)" }} />
              {/* Glow */}
              <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full blur-3xl opacity-15"
                style={{ background: "#3ccf73" }} />

              <div className="relative z-10">
                {/* Card header */}
                <div className="mb-6">
                  <h3 className="text-lg font-black text-white">Send us a message</h3>
                  <p className="text-xs text-gray-600 mt-0.5">We'll respond within 24 hours</p>
                </div>

                <Form {...form}>
                  <form
                    onSubmit={form.handleSubmit(d => contactMutation.mutate(d))}
                    className="space-y-4"
                    data-testid="form-contact"
                  >
                    {/* Name */}
                    <FormField control={form.control} name="name"
                      render={({ field, fieldState }) => (
                        <FormItem>
                          <FormControl>
                            <DarkInput
                              field={field} id="contact-name"
                              label={t("landing.contact.form.nameLabel")}
                              placeholder={t("landing.contact.form.namePlaceholder")}
                              required accent="#3ccf73"
                              error={fieldState.error?.message}
                              data-testid="input-name"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    {/* Email */}
                    <FormField control={form.control} name="email"
                      render={({ field, fieldState }) => (
                        <FormItem>
                          <FormControl>
                            <DarkInput
                              field={field} id="contact-email" type="email"
                              label={t("landing.contact.form.emailLabel")}
                              placeholder={t("landing.contact.form.emailPlaceholder")}
                              required accent="#3ccf73"
                              error={fieldState.error?.message}
                              data-testid="input-email"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    {/* Company */}
                    <FormField control={form.control} name="company"
                      render={({ field, fieldState }) => (
                        <FormItem>
                          <FormControl>
                            <DarkInput
                              field={field} id="contact-company"
                              label={t("landing.contact.form.companyLabel")}
                              placeholder={t("landing.contact.form.companyPlaceholder")}
                              accent="#b78af5"
                              error={fieldState.error?.message}
                              data-testid="input-company"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    {/* Message */}
                    <FormField control={form.control} name="message"
                      render={({ field, fieldState }) => (
                        <FormItem>
                          <FormControl>
                            <DarkTextarea
                              field={field} id="contact-message"
                              label={t("landing.contact.form.messageLabel")}
                              placeholder={t("landing.contact.form.messagePlaceholder")}
                              required accent="#3ccf73"
                              error={fieldState.error?.message}
                              data-testid="input-message"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    {/* Submit */}
                    <motion.button
                      type="submit"
                      disabled={contactMutation.isPending}
                      whileHover={{ scale: contactMutation.isPending ? 1 : 1.02 }}
                      whileTap={{ scale: contactMutation.isPending ? 1 : 0.97 }}
                      className="relative w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm text-black overflow-hidden mt-2"
                      style={{
                        background: "linear-gradient(135deg, #3ccf73 0%, #2aaa58 100%)",
                        boxShadow: "0 0 28px rgba(60,207,115,0.28)",
                        opacity: contactMutation.isPending ? 0.75 : 1,
                      }}
                      data-testid="button-submit-contact"
                    >
                      {/* Shimmer */}
                      {!contactMutation.isPending && (
                        <motion.span className="absolute inset-0 rounded-xl"
                          style={{ background: "linear-gradient(110deg, transparent 30%, rgba(255,255,255,0.2) 50%, transparent 70%)", backgroundSize: "200% 100%" }}
                          animate={{ backgroundPosition: ["200% 0", "-200% 0"] }}
                          transition={{ duration: 2.6, repeat: Infinity, ease: "linear" }} />
                      )}
                      {contactMutation.isPending ? (
                        <><Loader2 size={15} className="animate-spin relative" /><span className="relative">{t("landing.contact.form.sending")}</span></>
                      ) : (
                        <><Send size={14} className="relative" /><span className="relative">{t("landing.contact.form.submit")}</span><ArrowRight size={13} className="relative" /></>
                      )}
                    </motion.button>

                    {/* Privacy */}
                    <p
                      className="text-[10px] text-gray-600 text-center flex items-center justify-center gap-1.5 mt-1"
                      data-testid="text-privacy-notice"
                    >
                      <Shield size={11} style={{ color: "#3ccf73" }} />
                      {t("landing.contact.form.privacyNotice")}
                    </p>
                  </form>
                </Form>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export default ContactSection;