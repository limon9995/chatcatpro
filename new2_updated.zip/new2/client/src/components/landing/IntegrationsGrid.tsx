/**
 * IntegrationsGrid — Advanced Redesign
 * Brand: #4d1c95 → #000000 | primary #3ccf73
 * Layout: floating integration bubbles + central hub + animated beam paths
 */
import { motion, useInView } from "framer-motion";
import { Mic2, Calendar, Webhook, Zap } from "lucide-react";
import {
  SiTwilio, SiStripe, SiZapier, SiOpenai,
  SiSlack, SiNotion, SiHubspot, SiSalesforce,
} from "react-icons/si";
import { useBranding } from "@/components/BrandingProvider";
import { ComponentType, useRef } from "react";
import { useTranslation } from "react-i18next";

/* ─── Types ───────────────────────────────────── */
interface Integration {
  name: string;
  icon: ComponentType<{ className?: string; style?: React.CSSProperties }>;
  color: string;
  position: { x: number; y: number };
  size: "sm" | "md" | "lg";
  delay: number;
}

/* ─── Integration data ────────────────────────── */
const integrations: Integration[] = [
  { name: "Salesforce", icon: SiSalesforce, color: "#00A1E0", position: { x: 6,  y: 72 }, size: "md", delay: 0    },
  { name: "Slack",      icon: SiSlack,      color: "#4A154B", position: { x: 14, y: 48 }, size: "sm", delay: 0.1  },
  { name: "Twilio",     icon: SiTwilio,     color: "#F22F46", position: { x: 22, y: 68 }, size: "md", delay: 0.2  },
  { name: "Zapier",     icon: SiZapier,     color: "#FF4A00", position: { x: 30, y: 44 }, size: "sm", delay: 0.3  },
  { name: "ElevenLabs", icon: Mic2,         color: "#3ccf73", position: { x: 40, y: 62 }, size: "md", delay: 0.4  },
  { name: "Notion",     icon: SiNotion,     color: "#ffffff", position: { x: 50, y: 38 }, size: "md", delay: 0.5  },
  { name: "OpenAI",     icon: SiOpenai,     color: "#10A37F", position: { x: 60, y: 58 }, size: "md", delay: 0.6  },
  { name: "Cal.com",    icon: Calendar,     color: "#b78af5", position: { x: 76, y: 30 }, size: "sm", delay: 0.8  },
  { name: "Stripe",     icon: SiStripe,     color: "#635BFF", position: { x: 84, y: 55 }, size: "md", delay: 0.9  },
  { name: "HubSpot",    icon: SiHubspot,    color: "#FF7A59", position: { x: 93, y: 38 }, size: "sm", delay: 1.0  },
];

/* Responsive sizes — smaller on mobile */
const sizeMap      = { sm: 32, md: 40, lg: 56 };
const sizeMdMap    = { sm: 44, md: 52, lg: 68 };
const iconSizeMap  = { sm: 14, md: 17, lg: 24 };
const iconSizeMdMap = { sm: 18, md: 22, lg: 30 };

/* ─── Integration bubble ──────────────────────── */
const IntegrationBubble = ({ integration }: { integration: Integration }) => {
  const Icon = integration.icon;

  return (
    <motion.div
      className="absolute"
      style={{ left: `${integration.position.x}%`, top: `${integration.position.y}%`, transform: "translate(-50%,-50%)" }}
      initial={{ opacity: 0, scale: 0 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: integration.delay, type: "spring", stiffness: 200 }}
      data-testid={`integration-bubble-${integration.name.toLowerCase().replace(/\./g,"-")}`}
    >
      <motion.div
        animate={{ y: [0, -6, 0] }}
        transition={{ duration: 3.5 + integration.delay * 0.5, repeat: Infinity, ease: "easeInOut" }}
        whileHover={{ scale: 1.2 }}
        className="relative group cursor-pointer"
      >
        {/* Use CSS classes for responsive sizing */}
        <div className="w-8 h-8 sm:w-11 sm:h-11 md:w-[52px] md:h-[52px] relative">
          {/* Glow ring */}
          <div className="absolute inset-0 rounded-full"
            style={{ background: `radial-gradient(circle, ${integration.color}25 0%, transparent 70%)`, filter: "blur(5px)" }} />
          {/* Main circle */}
          <div className="absolute inset-0 rounded-full flex items-center justify-center"
            style={{
              background: "linear-gradient(145deg, rgba(20,4,40,0.95), rgba(8,0,18,0.98))",
              border: `1.5px solid ${integration.color}40`,
              boxShadow: `0 0 14px ${integration.color}20, inset 0 1px 0 rgba(255,255,255,0.06)`,
            }}>
            <Icon style={{ width: '45%', height: '45%', color: integration.color }} />
          </div>
        </div>
        {/* Hover label — hidden on mobile */}
        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 whitespace-nowrap text-[9px] sm:text-[10px] font-semibold opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none hidden sm:block"
          style={{ color: integration.color }}>
          {integration.name}
        </div>
      </motion.div>
    </motion.div>
  );
};

/* ─── Central hub ─────────────────────────────── */
const CentralHub = () => {
  const { branding } = useBranding();
  return (
    <motion.div
      className="absolute"
      style={{ left: "68%", top: "52%", transform: "translate(-50%,-50%)" }}
      initial={{ opacity: 0, scale: 0 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.7, delay: 0.7, type: "spring", stiffness: 120 }}
      data-testid="integration-central-hub"
    >
      {/* Outer pulse rings */}
      {[1, 2, 3].map(i => (
        <motion.div key={i} className="absolute inset-0 rounded-full"
          style={{ border: `1px solid rgba(60,207,115,0.3)` }}
          animate={{ scale: [1, 1 + i * 0.22], opacity: [0.5, 0] }}
          transition={{ duration: 2.5, repeat: Infinity, delay: i * 0.55, ease: "easeOut" }}
        />
      ))}
      {/* Hub body */}
      <motion.div
        className="relative w-16 h-16 sm:w-24 sm:h-24 md:w-32 md:h-32 rounded-full flex items-center justify-center"
        style={{
          background: "linear-gradient(135deg, #1a0535, #0a0018)",
          border: "2px solid rgba(60,207,115,0.45)",
          boxShadow: "0 0 50px rgba(60,207,115,0.2), 0 0 100px rgba(77,28,149,0.35)",
        }}
        animate={{ scale: [1, 1.04, 1], boxShadow: [
          "0 0 50px rgba(60,207,115,0.2), 0 0 100px rgba(77,28,149,0.35)",
          "0 0 70px rgba(60,207,115,0.3), 0 0 130px rgba(77,28,149,0.45)",
          "0 0 50px rgba(60,207,115,0.2), 0 0 100px rgba(77,28,149,0.35)",
        ]}}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      >
        {/* Inner white ring */}
        <div className="w-10 h-10 sm:w-16 sm:h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center"
          style={{
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(255,255,255,0.1)",
          }}>
          {branding.favicon_url ? (
            <img src={branding.favicon_url} alt={branding.app_name}
              className="w-5 h-5 sm:w-8 sm:h-8 md:w-10 md:h-10 object-contain" />
          ) : (
            <Webhook className="w-4 h-4 sm:w-6 sm:h-6 md:w-7 md:h-7" style={{ color: "#3ccf73" }} />
          )}
        </div>
      </motion.div>
    </motion.div>
  );
};

/* ─── Animated connection paths ───────────────── */
const ConnectionPaths = () => (
  <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 1000 400" preserveAspectRatio="none"
    data-testid="integration-connection-path">
    <defs>
      <linearGradient id="pg1" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="rgba(60,207,115,0)"/>
        <stop offset="40%" stopColor="rgba(60,207,115,0.35)"/>
        <stop offset="60%" stopColor="rgba(60,207,115,0.35)"/>
        <stop offset="100%" stopColor="rgba(60,207,115,0)"/>
      </linearGradient>
      <linearGradient id="pg2" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="rgba(77,28,149,0)"/>
        <stop offset="45%" stopColor="rgba(183,138,245,0.3)"/>
        <stop offset="55%" stopColor="rgba(183,138,245,0.3)"/>
        <stop offset="100%" stopColor="rgba(77,28,149,0)"/>
      </linearGradient>
      <filter id="path-glow"><feGaussianBlur stdDeviation="2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    </defs>

    {/* Path 1 — green */}
    <motion.path
      d="M 0,290 Q 150,270 250,210 T 460,175 T 660,200 T 860,135 T 1000,165"
      fill="none" stroke="url(#pg1)" strokeWidth="1.8"
      initial={{ pathLength: 0, opacity: 0 }}
      whileInView={{ pathLength: 1, opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 2.2, ease: "easeInOut" }}
    />
    {/* Path 2 — purple */}
    <motion.path
      d="M 0,320 Q 200,300 360,248 T 560,218 T 710,242 T 910,175 T 1000,195"
      fill="none" stroke="url(#pg2)" strokeWidth="1.4"
      initial={{ pathLength: 0, opacity: 0 }}
      whileInView={{ pathLength: 1, opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 2.5, delay: 0.3, ease: "easeInOut" }}
    />

    {/* Traveling packets */}
    <motion.circle r="4.5" fill="#3ccf73" filter="url(#path-glow)">
      <animateMotion dur="5s" repeatCount="indefinite"
        path="M 0,290 Q 150,270 250,210 T 460,175 T 660,200 T 860,135 T 1000,165"/>
    </motion.circle>
    <motion.circle r="3.5" fill="#b78af5" filter="url(#path-glow)">
      <animateMotion dur="7s" repeatCount="indefinite" begin="2s"
        path="M 0,320 Q 200,300 360,248 T 560,218 T 710,242 T 910,175 T 1000,195"/>
    </motion.circle>
    <motion.circle r="3" fill="#3ccf73" filter="url(#path-glow)" fillOpacity="0.7">
      <animateMotion dur="6s" repeatCount="indefinite" begin="3.5s"
        path="M 0,290 Q 150,270 250,210 T 460,175 T 660,200 T 860,135 T 1000,165"/>
    </motion.circle>
  </svg>
);

/* ─── Floating particles ──────────────────────── */
const FloatingParticles = () => (
  <>
    {Array.from({ length: 8 }).map((_, i) => (
      <motion.div key={i}
        className="absolute rounded-full pointer-events-none"
        style={{
          width: 3 + (i % 3),
          height: 3 + (i % 3),
          left: `${10 + i * 11}%`,
          top: `${20 + (i % 4) * 18}%`,
          background: i % 2 === 0 ? "rgba(60,207,115,0.35)" : "rgba(77,28,149,0.45)",
        }}
        animate={{ y: [0, -(14 + i * 3), 0], opacity: [0.2, 0.6, 0.2] }}
        transition={{ duration: 4 + i * 0.6, repeat: Infinity, delay: i * 0.35, ease: "easeInOut" }}
      />
    ))}
  </>
);

/* ─────────────────────────────────────────────
   MAIN EXPORT
───────────────────────────────────────────── */
export function IntegrationsGrid() {
  const { branding } = useBranding();
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section
      ref={ref}
      className="relative overflow-hidden py-12 sm:py-16 md:py-28"
      style={{ background: "linear-gradient(180deg, #000000 0%, #07001a 50%, #000000 100%)" }}
      data-testid="integrations-section"
    >
      {/* BG blobs */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] rounded-full blur-[130px]"
          style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.22) 0%, transparent 65%)" }} />
        <div className="absolute top-0 right-0 w-[300px] h-[300px] rounded-full blur-[90px]"
          style={{ background: "radial-gradient(circle, rgba(60,207,115,0.05) 0%, transparent 70%)" }} />
      </div>

      <FloatingParticles />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-8 lg:px-10">
        {/* ── Header ── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-8 sm:mb-10 md:mb-14"
        >
          <span
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-semibold tracking-[0.18em] uppercase mb-5"
            style={{ background: "rgba(60,207,115,0.07)", border: "1px solid rgba(60,207,115,0.2)", color: "#3ccf73" }}
          >
            <Zap size={10} /> Integrations
          </span>
          <h2
            className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black text-white leading-tight tracking-tight mb-3 sm:mb-4"
            data-testid="integrations-headline"
          >
            {t("landing.integrations.title")}
          </h2>
          <p className="text-sm sm:text-base text-gray-400 max-w-xl mx-auto leading-relaxed px-2 sm:px-0">
            {t("landing.integrations.description", { appName: branding.app_name })}
          </p>
        </motion.div>

        {/* ── Visual area ── */}
        <div
          className="relative h-[200px] sm:h-[280px] md:h-[350px] lg:h-[400px]"
          data-testid="integrations-grid"
        >
          <ConnectionPaths />
          {integrations.map(i => <IntegrationBubble key={i.name} integration={i} />)}
          <CentralHub />
        </div>

        {/* ── Logo strip ── */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 1.2 }}
          className="mt-6 sm:mt-10 md:mt-14 flex flex-wrap items-center justify-center gap-3 sm:gap-5 md:gap-8"
        >
          {integrations.map(({ name, icon: Icon, color }) => (
            <div key={name}
              className="flex items-center gap-2 group cursor-default"
              title={name}
            >
              <Icon style={{ width: 14, height: 14, color, opacity: 0.5 }} />
              <span className="hidden sm:inline text-xs font-medium text-white/25 group-hover:text-white/55 transition-colors">
                {name}
              </span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-20 pointer-events-none"
        style={{ background: "linear-gradient(to top, rgba(0,0,0,0.6), transparent)" }} />
    </section>
  );
}

export default IntegrationsGrid;