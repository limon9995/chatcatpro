/**
 * HeroSection — Clean Advanced Redesign v2
 * Brand: gradient #4d1c95 → #000000 | primary #3ccf73
 */
import { motion, useInView } from "framer-motion";
import { Check, ChevronDown, Phone, Zap, ArrowRight } from "lucide-react";
import { useRef, useState, useEffect } from "react";
import { Link } from "wouter";
import { AuthStorage } from "@/lib/auth-storage";
import { useTranslation } from "react-i18next";

/* ─── Typing word ─────────────────────────── */
const TypingWord = ({ words }: { words: string[] }) => {
  const [idx, setIdx] = useState(0);
  const [text, setText] = useState("");
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const word = words[idx];
    if (!deleting && text === word) {
      const t = setTimeout(() => setDeleting(true), 2200);
      return () => clearTimeout(t);
    }
    if (deleting && text === "") {
      setDeleting(false);
      setIdx((p) => (p + 1) % words.length);
      return;
    }
    const t = setTimeout(
      () => setText(deleting ? word.slice(0, text.length - 1) : word.slice(0, text.length + 1)),
      deleting ? 45 : 90
    );
    return () => clearTimeout(t);
  }, [text, deleting, idx, words]);

  return (
    <span className="inline-block min-w-[180px] sm:min-w-[220px] text-left">
      <span
        style={{
          background: "linear-gradient(135deg, #3ccf73 0%, #8eedb4 55%, #3ccf73 100%)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
        }}
      >
        {text}
      </span>
      <motion.span
        animate={{ opacity: [1, 0] }}
        transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
        className="inline-block w-[3px] h-[0.8em] ml-[2px] align-middle rounded-sm"
        style={{ background: "#3ccf73" }}
      />
    </span>
  );
};

/* ─── Sound wave ──────────────────────────── */
const SoundWave = () => (
  <div className="flex items-center justify-center gap-[3px] h-10">
    {Array.from({ length: 22 }).map((_, i) => {
      const mid = 11;
      const dist = Math.abs(i - mid);
      const peak = Math.max(6, 30 - dist * 2.4);
      return (
        <motion.div
          key={i}
          className="w-[2.5px] rounded-full"
          style={{
            background:
              i < 11
                ? "linear-gradient(to top, #4d1c95, #3ccf73)"
                : "linear-gradient(to top, #2a7a45, #3ccf73)",
          }}
          animate={{ height: [peak * 0.35, peak, peak * 0.45, peak * 0.85, peak * 0.35] }}
          transition={{
            duration: 1.0 + (i % 6) * 0.1,
            repeat: Infinity,
            ease: "easeInOut",
            delay: i * 0.042,
          }}
        />
      );
    })}
  </div>
);

/* ─── Phone mockup (side) ─────────────────── */
const SidePhone = ({ side }: { side: "left" | "right" }) => {
  const rotY = side === "left" ? -22 : 22;
  const rotZ = side === "left" ? -5 : 5;

  return (
    <motion.div
      className="absolute top-1/2 hidden lg:block"
      style={{
        [side === "left" ? "left" : "right"]: "2%",
        translateY: "-50%",
        zIndex: 6,
        transformStyle: "preserve-3d",
      }}
      initial={{ opacity: 0, x: side === "left" ? -50 : 50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 1.2, delay: 0.7, ease: [0.22, 1, 0.36, 1] }}
    >
      <motion.div
        animate={{ y: [0, -12, 0] }}
        transition={{ duration: 5.5, repeat: Infinity, ease: "easeInOut", delay: side === "right" ? 0.9 : 0 }}
        style={{ transform: `perspective(1000px) rotateY(${rotY}deg) rotateZ(${rotZ}deg)` }}
      >
        <div
          className="relative rounded-[2.6rem] overflow-hidden"
          style={{
            width: 190,
            height: 400,
            background: "linear-gradient(160deg, #1c1c30 0%, #09090f 100%)",
            border: "1.5px solid rgba(255,255,255,0.1)",
            boxShadow: "0 32px 80px rgba(0,0,0,0.75), inset 0 1px 0 rgba(255,255,255,0.07)",
            opacity: 0.65,
          }}
        >
          <div className="absolute top-4 left-1/2 -translate-x-1/2 w-20 h-5 bg-black rounded-full z-10" />
          <div className="absolute inset-[3px] rounded-[2.3rem] bg-[#07070e] overflow-hidden">
            <div className="p-4 pt-11 space-y-3">
              <div className="flex items-center justify-between mb-3">
                <div className="w-14 h-2 rounded-full bg-white/10" />
                <div className="w-7 h-7 rounded-full" style={{ background: "rgba(60,207,115,0.2)", border: "1px solid rgba(60,207,115,0.3)" }} />
              </div>
              <div className="flex items-center justify-center gap-[2px] h-9 my-2">
                {Array.from({ length: 14 }).map((_, i) => (
                  <motion.div key={i} className="w-[2px] rounded-full" style={{ background: "#3ccf73" }}
                    animate={{ height: [3, 10 + (i % 5) * 4, 3] }}
                    transition={{ duration: 0.75 + i * 0.055, repeat: Infinity, ease: "easeInOut", delay: i * 0.05 }} />
                ))}
              </div>
              {[78, 62, 50, 68, 44].map((w, i) => (
                <div key={i} className="h-[6px] rounded-full"
                  style={{ width: `${w}%`, background: i === 0 ? "rgba(60,207,115,0.35)" : "rgba(255,255,255,0.06)" }} />
              ))}
              <div className="mt-5 flex justify-center">
                <div className="w-12 h-12 rounded-full flex items-center justify-center"
                  style={{ background: "linear-gradient(135deg, #3ccf73, #2aaa58)", boxShadow: "0 0 20px rgba(60,207,115,0.45)" }}>
                  <Phone size={18} color="#000" />
                </div>
              </div>
            </div>
          </div>
          <div className={`absolute top-20 ${side === "left" ? "-right-[3px]" : "-left-[3px]"} w-[3px] h-12 rounded-full`}
            style={{ background: "rgba(255,255,255,0.12)" }} />
        </div>
        <div className="absolute -bottom-5 left-1/2 -translate-x-1/2 w-28 h-6 rounded-full blur-xl"
          style={{ background: "rgba(60,207,115,0.2)" }} />
      </motion.div>
    </motion.div>
  );
};

/* ─── Center ghost phone (PNG image, truly centered) ── */
const CenterPhone = () => (
  <motion.div
    className="absolute inset-0 hidden xl:flex items-start justify-center pointer-events-none"
    style={{ zIndex: 4 }}
    initial={{ opacity: 0, y: 30 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
  >
    <motion.div
      animate={{ y: [0, -10, 0] }}
      transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
      style={{ marginTop: "5%" }}
    >
      <img
        src="/images/home/mobile.png"
        alt=""
        aria-hidden="true"
        style={{
          width: 255,
          height: "auto",
          opacity: 0.2,
          filter: "drop-shadow(0 0 50px rgba(77,28,149,0.8)) brightness(1.1)",
          mixBlendMode: "screen",
          display: "block",
        }}
      />
    </motion.div>
  </motion.div>
);

/* ─── Background FX ───────────────────────── */
const BackgroundFX = () => (
  <div className="absolute inset-0 pointer-events-none overflow-hidden">
    <div className="absolute -top-32 -left-40 rounded-full blur-[130px]"
      style={{ width: 750, height: 750, background: "radial-gradient(circle, rgba(77,28,149,0.55) 0%, transparent 65%)" }} />
    <div className="absolute -bottom-24 right-0 rounded-full blur-[100px]"
      style={{ width: 500, height: 500, background: "radial-gradient(circle, rgba(20,5,45,0.5) 0%, transparent 70%)" }} />
    <div className="absolute top-0 right-0 rounded-full blur-[90px]"
      style={{ width: 320, height: 320, background: "radial-gradient(circle, rgba(60,207,115,0.07) 0%, transparent 70%)" }} />
    {[380, 560, 740].map((d, i) => (
      <motion.div key={d} className="absolute top-1/2 left-1/2 rounded-full"
        style={{ width: d, height: d, marginTop: -d / 2, marginLeft: -d / 2, border: `1px solid rgba(255,255,255,${0.04 - i * 0.01})` }}
        animate={{ rotate: i % 2 === 0 ? 360 : -360 }}
        transition={{ duration: 35 + i * 15, repeat: Infinity, ease: "linear" }} />
    ))}
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl"
      style={{ width: 500, height: 500, background: "radial-gradient(circle, rgba(77,28,149,0.3) 0%, transparent 65%)" }} />
    <div className="absolute top-1/2 left-0 w-full h-px"
      style={{ background: "linear-gradient(90deg, transparent 0%, rgba(60,207,115,0.07) 30%, rgba(60,207,115,0.07) 70%, transparent 100%)" }} />
  </div>
);

/* ─── Stat pill ───────────────────────────── */
const StatPill = ({ value, label }: { value: string; label: string }) => (
  <motion.div whileHover={{ scale: 1.04 }} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full select-none cursor-default"
    style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.09)", backdropFilter: "blur(10px)" }}>
    <span className="text-xl font-black" style={{ color: "#3ccf73" }}>{value}</span>
    <span className="text-[11px] font-semibold tracking-[0.18em] text-gray-500 uppercase">{label}</span>
  </motion.div>
);

/* ─── Trust item ──────────────────────────── */
const TrustItem = ({ text }: { text: string }) => (
  <div className="flex items-center gap-2 text-sm text-gray-500">
    <span className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0"
      style={{ background: "rgba(60,207,115,0.1)", border: "1px solid rgba(60,207,115,0.3)" }}>
      <Check size={9} style={{ color: "#3ccf73" }} />
    </span>
    {text}
  </div>
);

/* ─── Logos ───────────────────────────────── */
const logos = [
  { name: "RE MAX",       cls: "text-sm font-black tracking-tight" },
  { name: "Claro",        cls: "text-base font-semibold" },
  { name: "TOMORROWLAND", cls: "text-[10px] font-light tracking-[0.22em]" },
  { name: "LIMITLESS",    cls: "text-xs font-medium tracking-widest" },
  { name: "segware",      cls: "text-sm font-semibold" },
  { name: "wakefit",      cls: "text-sm font-medium italic" },
  { name: "AVENTIS",      cls: "text-xs font-bold tracking-wide" },
];

const containerV = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.09, delayChildren: 0.1 } },
};
const itemV = {
  hidden: { opacity: 0, y: 22 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.65, ease: [0.22, 1, 0.36, 1] } },
};

/* ─────────────────────────────────────────────
   EXPORT
───────────────────────────────────────────── */
export function HeroSection() {
  const { t } = useTranslation();
  const isAuthenticated = AuthStorage.isAuthenticated();
  const isAdmin = AuthStorage.isAdmin();
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true });

  const rotatingWords = [
    t("landing.hero.rotatingWords.sales"),
    t("landing.hero.rotatingWords.support"),
    t("landing.hero.rotatingWords.outreach"),
    t("landing.hero.rotatingWords.appointments"),
  ];

  const dashboardLink = isAuthenticated ? (isAdmin ? "/admin" : "/app") : "/login";

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen flex flex-col justify-center overflow-hidden"
      style={{ background: "linear-gradient(155deg, #180428 0%, #0c0118 40%, #000000 100%)" }}
      data-testid="hero-section"
    >
      {/* Grain */}
      <div className="absolute inset-0 pointer-events-none z-20 opacity-[0.022]"
        style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")` }} />

      <BackgroundFX />
      {/* <CenterPhone /> */}
      <SidePhone side="left" />
      <SidePhone side="right" />

      {/* Content */}
      <div className="relative z-30 w-full max-w-3xl mx-auto px-5 sm:px-8 pt-28 pb-20 text-center">
        <motion.div variants={containerV} initial="hidden" animate={isInView ? "visible" : "hidden"}
          className="flex flex-col items-center gap-6">

          {/* Wave */}
          <motion.div variants={itemV}><SoundWave /></motion.div>

          {/* Badge */}
          <motion.div variants={itemV}>
            <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-semibold tracking-[0.18em] uppercase"
              style={{ background: "rgba(60,207,115,0.07)", border: "1px solid rgba(60,207,115,0.22)", color: "#3ccf73" }}>
              <Zap size={10} />
              {t("landing.hero.badge")}
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h1 variants={itemV}
            className="text-3xl sm:text-4xl md:text-5xl lg:text-[54px] font-black leading-[1.1] tracking-[-0.03em]"
            data-testid="hero-headline">
            <div style={{ background: "linear-gradient(180deg, #ffffff 0%, rgba(255,255,255,0.72) 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>
              Automate Phone Calls
            </div>
            <div className="flex items-center justify-center gap-3">
              <span style={{ background: "linear-gradient(180deg, #ffffff 0%, rgba(255,255,255,0.72) 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>
                With{" "}
              </span>
              <TypingWord words={rotatingWords} />
            </div>
          </motion.h1>

          {/* Sub */}
          <motion.p variants={itemV} className="text-[15px] md:text-base text-gray-400 max-w-lg leading-relaxed"
            data-testid="hero-subheadline">
            Create <span className="font-semibold text-white/90">Human-like</span> AI voice agents to handle
            outbound and inbound calls, book meetings, and take actions{" "}
            <span className="font-semibold" style={{ color: "#3ccf73" }}>24/7.</span>
          </motion.p>

          {/* Stats */}
          <motion.div variants={itemV} className="flex flex-wrap justify-center gap-2.5">
            <StatPill value="5X" label={t("landing.hero.statsProductivity")} />
            <StatPill value="100X" label={t("landing.hero.statsScalability")} />
          </motion.div>

          {/* CTAs */}
          <motion.div variants={itemV} className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-1">
            <Link href={dashboardLink}>
              <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                data-testid="button-hero-get-started"
                className="relative inline-flex items-center gap-2 px-8 rounded-full font-bold text-[15px] text-black overflow-hidden"
                style={{ height: 52, background: "linear-gradient(135deg, #3ccf73 0%, #2aaa58 100%)", boxShadow: "0 0 40px rgba(60,207,115,0.3), 0 4px 24px rgba(0,0,0,0.5)" }}>
                <motion.span className="absolute inset-0 rounded-full"
                  style={{ background: "linear-gradient(110deg, transparent 30%, rgba(255,255,255,0.22) 50%, transparent 70%)", backgroundSize: "200% 100%" }}
                  animate={{ backgroundPosition: ["200% 0", "-200% 0"] }}
                  transition={{ duration: 2.8, repeat: Infinity, ease: "linear" }} />
                <span className="relative">{t("landing.hero.getStarted")}</span>
                <ArrowRight size={15} className="relative" />
              </motion.button>
            </Link>

            <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
              data-testid="button-hero-demo-call"
              onClick={() => window.dispatchEvent(new CustomEvent("trigger-demo-call"))}
              className="inline-flex items-center gap-2.5 font-semibold text-[15px] text-white/80"
              style={{ height: 52, padding: "0 28px", borderRadius: 9999, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.12)", backdropFilter: "blur(10px)" }}>
              <span className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background: "rgba(60,207,115,0.12)" }}>
                <Phone size={13} style={{ color: "#3ccf73" }} />
              </span>
              Try Demo Call
            </motion.button>
          </motion.div>

          {/* Trust */}
          <motion.div variants={itemV} className="flex flex-col sm:flex-row items-center gap-3 sm:gap-6"
            data-testid="hero-trust-badges">
            <TrustItem text={t("landing.hero.freeTrial")} />
            <span className="hidden sm:block w-px h-3.5 bg-white/10" />
            <TrustItem text={t("landing.hero.freeCredit")} />
          </motion.div>
        </motion.div>

        {/* Scroll caret */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2.2, duration: 0.8 }}
          className="absolute bottom-7 left-1/2 -translate-x-1/2">
          <motion.button animate={{ y: [0, 5, 0] }} transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
            onClick={() => window.scrollTo({ top: window.innerHeight - 80, behavior: "smooth" })}
            className="focus:outline-none" aria-label="Scroll down" data-testid="button-scroll-indicator">
            <ChevronDown size={22} className="text-white/20 hover:text-white/50 transition-colors" />
          </motion.button>
        </motion.div>
      </div>

      {/* ── Logos Strip (Professional Infinite Marquee) ── */}
      <div className="relative z-30 mt-auto border-t border-white/[0.03] bg-black/40 backdrop-blur-2xl">
        <div className="max-w-7xl mx-auto py-7 overflow-hidden">
          {/* Label */}
          <p className="text-center text-[10px] font-bold tracking-[0.25em] uppercase text-white/20 mb-6 px-4">
            Trusted by global innovators
          </p>

          <div
            className="relative flex items-center"
            style={{
              maskImage: "linear-gradient(to right, transparent, black 15%, black 85%, transparent)",
              WebkitMaskImage: "linear-gradient(to right, transparent, black 15%, black 85%, transparent)",
            }}
          >
            <motion.div
              className="flex items-center gap-12 md:gap-20 flex-nowrap"
              animate={{ x: ["0%", "-50%"] }}
              transition={{ duration: 35, repeat: Infinity, ease: "linear" }}
              style={{ width: "fit-content" }}
            >
              {/* Duplicating logos for infinite effect */}
              {[...logos, ...logos].map((logo, i) => (
                <span
                  key={`${logo.name}-${i}`}
                  className={`text-white/50 hover:text-white/95 transition-colors duration-500 select-none cursor-default whitespace-nowrap ${logo.cls}`}
                  style={{ filter: "grayscale(1) brightness(1.2)" }}
                >
                  {logo.name}
                </span>
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default HeroSection;