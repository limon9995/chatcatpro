/**
 * PricingSection — Advanced Redesign
 * Brand: #4d1c95 → #000000 | primary #3ccf73
 * Placeholder cards shown when API unavailable
 */
import { useState, useRef } from "react";
import { motion, useReducedMotion, useInView } from "framer-motion";
import {
  Check, Star, Zap, ArrowRight, Shield, Loader2,
  Bot, Phone, Webhook, Globe, Brain, Users,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useTranslation } from "react-i18next";

/* ─── Types ───────────────────────────────────── */
interface Plan {
  id: string; name: string; displayName: string; description: string;
  monthlyPrice: string; yearlyPrice: string | null;
  razorpayMonthlyPrice: string | null; razorpayYearlyPrice: string | null;
  paypalMonthlyPrice: string | null; paypalYearlyPrice: string | null;
  paystackMonthlyPrice: string | null; paystackYearlyPrice: string | null;
  mercadopagoMonthlyPrice: string | null; mercadopagoYearlyPrice: string | null;
  maxAgents: number; maxCampaigns: number; maxContactsPerCampaign: number;
  maxWebhooks: number; maxKnowledgeBases: number; maxFlows: number;
  maxPhoneNumbers: number; includedCredits: number;
  canChooseLlm: boolean; canPurchaseNumbers: boolean;
  features: any; sipEnabled?: boolean; restApiEnabled?: boolean;
}
interface PluginCapabilities { success: boolean; data: { capabilities: Record<string, boolean>; sipEngine: boolean; restApi: boolean; }; }
interface PaymentGatewayConfig {
  stripeEnabled: boolean; razorpayEnabled: boolean; paypalEnabled: boolean;
  paystackEnabled: boolean; mercadopagoEnabled: boolean;
  stripeCurrency?: string; stripeCurrencySymbol?: string;
  paypalCurrency?: string; paypalCurrencySymbol?: string;
  paystackCurrency?: string; paystackCurrencySymbol?: string;
  paystackDefaultCurrency?: string;
  mercadopagoCurrency?: string; mercadopagoCurrencySymbol?: string;
}
interface CurrencyOption { code: string; symbol: string; gateway: string; }

const currencySymbols: Record<string, string> = {
  USD:"$", EUR:"€", GBP:"£", CAD:"C$", AUD:"A$", JPY:"¥", INR:"₹",
  BRL:"R$", MXN:"$", CHF:"CHF", NGN:"₦", GHS:"₵", ZAR:"R", KES:"KSh",
};

/* ─── Placeholder plans shown when DB is down ─── */
interface PlaceholderPlan {
  id: string; name: string; displayName: string; description: string;
  monthlyPrice: string; yearlyPrice: string;
  isPopular: boolean;
  features: { text: string; star?: boolean }[];
  icon: React.ElementType;
  accentColor: string;
}

const PLACEHOLDER_PLANS: PlaceholderPlan[] = [
  {
    id: "free",
    name: "free",
    displayName: "Starter",
    description: "Perfect for individuals and small teams getting started.",
    monthlyPrice: "0",
    yearlyPrice: "0",
    isPopular: false,
    icon: Bot,
    accentColor: "#b78af5",
    features: [
      { text: "1 AI Agent" },
      { text: "3 Campaigns" },
      { text: "500 contacts per campaign" },
      { text: "System-assigned number" },
      { text: "1 Knowledge Base" },
      { text: "Basic webhooks" },
      { text: "10 Included Credits", star: true },
    ],
  },
  {
    id: "pro",
    name: "pro",
    displayName: "Pro",
    description: "For growing teams that need more power and flexibility.",
    monthlyPrice: "49",
    yearlyPrice: "39",
    isPopular: true,
    icon: Phone,
    accentColor: "#3ccf73",
    features: [
      { text: "5 AI Agents" },
      { text: "Unlimited Campaigns" },
      { text: "10,000 contacts per campaign" },
      { text: "Own phone numbers" },
      { text: "Choose your LLM" },
      { text: "5 Flow Automations" },
      { text: "5 Knowledge Bases" },
      { text: "Priority support" },
      { text: "100 Included Credits", star: true },
    ],
  },
  {
    id: "enterprise",
    name: "enterprise",
    displayName: "Enterprise",
    description: "Full-scale automation for large teams and enterprises.",
    monthlyPrice: "149",
    yearlyPrice: "119",
    isPopular: false,
    icon: Globe,
    accentColor: "#60a5fa",
    features: [
      { text: "Unlimited AI Agents" },
      { text: "Unlimited Campaigns" },
      { text: "Unlimited Contacts" },
      { text: "Unlimited Phone Numbers" },
      { text: "Choose your LLM" },
      { text: "Unlimited Flow Automations" },
      { text: "Unlimited Knowledge Bases" },
      { text: "SIP Trunk Access" },
      { text: "REST API Access" },
      { text: "500 Included Credits", star: true },
    ],
  },
];

/* ─── Shared feature row ──────────────────────── */
const FRow = ({ text, star, accent }: { text: string; star?: boolean; accent: string }) => (
  <div className="flex items-start gap-2.5">
    {star ? (
      <Star size={13} className="flex-shrink-0 mt-0.5" style={{ color: "#f59e0b", fill: "#f59e0b" }} />
    ) : (
      <span className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
        style={{ background: `${accent}15`, border: `1px solid ${accent}35` }}>
        <Check size={9} style={{ color: accent }} />
      </span>
    )}
    <span className={`text-sm leading-relaxed ${star ? "font-semibold text-white" : "text-gray-400"}`}>{text}</span>
  </div>
);

/* ─── Placeholder card ────────────────────────── */
const PlaceholderCard = ({
  plan, isYearly, delay, onNavigate,
}: { plan: PlaceholderPlan; isYearly: boolean; delay: number; onNavigate: () => void }) => {
  const Icon = plan.icon;
  const price = isYearly ? plan.yearlyPrice : plan.monthlyPrice;
  const isFree = plan.name === "free";

  return (
    <motion.div
      initial={{ opacity: 0, y: 28, scale: 0.97 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      className="relative h-full"
    >
      {plan.isPopular && (
        <div className="absolute -top-3.5 left-0 right-0 flex justify-center z-20">
          <span
            className="inline-flex items-center gap-1.5 px-4 py-1 rounded-full text-xs font-bold"
            style={{
              background: "linear-gradient(135deg, #3ccf73, #2aaa58)",
              color: "#000",
              boxShadow: "0 0 20px rgba(60,207,115,0.4)",
            }}
          >
            <Star size={10} fill="black" /> Most Popular
          </span>
        </div>
      )}

      <div
        className="relative rounded-2xl overflow-hidden h-full flex flex-col"
        style={{
          background: plan.isPopular
            ? "linear-gradient(145deg, rgba(22,6,42,0.99) 0%, rgba(8,0,20,1) 100%)"
            : "linear-gradient(145deg, rgba(14,3,28,0.97) 0%, rgba(5,0,12,0.99) 100%)",
          border: `1px solid ${plan.isPopular ? "rgba(60,207,115,0.3)" : "rgba(255,255,255,0.07)"}`,
          boxShadow: plan.isPopular
            ? "0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(60,207,115,0.1), inset 0 1px 0 rgba(255,255,255,0.06)"
            : "0 8px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.04)",
        }}
      >
        {/* Top accent */}
        <div className="absolute top-0 left-0 right-0 h-px"
          style={{ background: `linear-gradient(90deg, transparent, ${plan.accentColor}55, transparent)` }} />
        {/* Glow corner */}
        {plan.isPopular && (
          <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-48 h-48 rounded-full blur-3xl"
            style={{ background: "rgba(60,207,115,0.08)" }} />
        )}

        <div className="relative z-10 p-6 md:p-7 flex flex-col h-full gap-5">
          {/* Header */}
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="text-xl font-black text-white tracking-tight">{plan.displayName}</h3>
              <p className="text-sm text-gray-500 mt-1 leading-relaxed">{plan.description}</p>
            </div>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: `${plan.accentColor}12`, border: `1px solid ${plan.accentColor}30` }}>
              <Icon size={18} style={{ color: plan.accentColor }} />
            </div>
          </div>

          {/* Price */}
          <div>
            {isFree ? (
              <>
                <span className="text-5xl font-black text-white">Free</span>
                <p className="text-xs text-gray-600 mt-1">No credit card required</p>
              </>
            ) : (
              <>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold text-gray-400">$</span>
                  <span className="text-5xl font-black text-white">{price}</span>
                  <span className="text-sm text-gray-500 ml-1">/ {isYearly ? "yr" : "mo"}</span>
                </div>
                {isYearly && (
                  <span className="inline-flex items-center gap-1 mt-1.5 text-[10px] font-bold px-2 py-0.5 rounded-full"
                    style={{ background: "rgba(60,207,115,0.1)", color: "#3ccf73", border: "1px solid rgba(60,207,115,0.25)" }}>
                    Save 20% · billed annually
                  </span>
                )}
              </>
            )}
          </div>

          {/* Divider */}
          <div className="h-px" style={{ background: "rgba(255,255,255,0.06)" }} />

          {/* Features */}
          <div className="flex-1 space-y-2.5">
            {plan.features.map((f, i) => (
              <FRow key={i} text={f.text} star={f.star} accent={plan.accentColor} />
            ))}
          </div>

          {/* CTA */}
          <motion.button
            whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }}
            onClick={onNavigate}
            className="relative w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm overflow-hidden mt-2"
            style={plan.isPopular ? {
              background: "linear-gradient(135deg, #3ccf73 0%, #2aaa58 100%)",
              color: "#000",
              boxShadow: "0 0 28px rgba(60,207,115,0.3)",
            } : {
              background: "rgba(255,255,255,0.04)",
              color: "rgba(255,255,255,0.65)",
              border: `1px solid ${plan.accentColor}30`,
            }}
          >
            {plan.isPopular && (
              <motion.span className="absolute inset-0 rounded-xl"
                style={{ background: "linear-gradient(110deg, transparent 30%, rgba(255,255,255,0.2) 50%, transparent 70%)", backgroundSize: "200% 100%" }}
                animate={{ backgroundPosition: ["200% 0", "-200% 0"] }}
                transition={{ duration: 2.6, repeat: Infinity, ease: "linear" }} />
            )}
            <span className="relative">{isFree ? "Get Started Free" : "Start Free Trial"}</span>
            <ArrowRight size={13} className="relative" />
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
};

/* ─── Live plan card (from API) ───────────────── */
const LiveCard = ({
  plan, index, isHighlighted, isFree, price, currencySymbol,
  isYearly, sipPluginEnabled, restApiPluginEnabled, onNavigate,
}: {
  plan: Plan; index: number; isHighlighted: boolean; isFree: boolean;
  price: string; currencySymbol: string; isYearly: boolean;
  sipPluginEnabled: boolean; restApiPluginEnabled: boolean; onNavigate: () => void;
}) => {
  const { t } = useTranslation();
  const accent = isHighlighted ? "#3ccf73" : "#b78af5";
  const maxWidgets = (plan as any).maxWidgets ?? 1;

  const features: { text: string; star?: boolean }[] = [];
  if (plan.maxAgents >= 999 || plan.maxAgents === -1) features.push({ text: "Unlimited AI Agents" });
  else features.push({ text: `${plan.maxAgents} AI Agent${plan.maxAgents > 1 ? "s" : ""}` });
  if (plan.maxCampaigns >= 999 || plan.maxCampaigns === -1) features.push({ text: "Unlimited Campaigns" });
  else features.push({ text: `${plan.maxCampaigns} Campaign${plan.maxCampaigns > 1 ? "s" : ""}` });
  if (plan.maxContactsPerCampaign >= 9999 || plan.maxContactsPerCampaign === -1) features.push({ text: "Unlimited Contacts" });
  else features.push({ text: `Max ${plan.maxContactsPerCampaign} contacts/campaign` });
  features.push({ text: plan.canPurchaseNumbers ? "Own phone numbers" : "System-assigned number" });
  if (plan.canChooseLlm) features.push({ text: "Choose your LLM" });
  if (plan.maxFlows > 0) features.push({ text: plan.maxFlows >= 999 ? "Unlimited Flow Automations" : `${plan.maxFlows} Flow Automation${plan.maxFlows !== 1 ? "s" : ""}` });
  if (plan.maxKnowledgeBases > 0) features.push({ text: plan.maxKnowledgeBases >= 999 ? "Unlimited Knowledge Bases" : `${plan.maxKnowledgeBases} Knowledge Base${plan.maxKnowledgeBases !== 1 ? "s" : ""}` });
  if (plan.maxWebhooks > 0) features.push({ text: plan.maxWebhooks >= 999 ? "Unlimited Webhooks" : `${plan.maxWebhooks} Webhook${plan.maxWebhooks !== 1 ? "s" : ""}` });
  if (plan.maxPhoneNumbers > 0) features.push({ text: plan.maxPhoneNumbers >= 999 ? "Unlimited Phone Numbers" : `${plan.maxPhoneNumbers} Phone Number${plan.maxPhoneNumbers !== 1 ? "s" : ""}` });
  if (maxWidgets > 0) features.push({ text: maxWidgets >= 999 ? "Unlimited Website Widgets" : `${maxWidgets} Website Widget${maxWidgets !== 1 ? "s" : ""}` });
  if (plan.includedCredits > 0) features.push({ text: `${plan.includedCredits} Included Credits`, star: true });
  if (!isFree) features.push({ text: "Priority support" });
  if (sipPluginEnabled && plan.sipEnabled && !isFree) features.push({ text: "SIP Trunk Access" });
  if (restApiPluginEnabled && plan.restApiEnabled && !isFree) features.push({ text: "REST API Access" });

  return (
    <motion.div
      initial={{ opacity: 0, y: 28, scale: 0.97 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.55, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
      className="relative h-full"
      data-testid={`pricing-card-${index}`}
    >
      {isHighlighted && (
        <div className="absolute -top-3.5 left-0 right-0 flex justify-center z-20">
          <span className="inline-flex items-center gap-1.5 px-4 py-1 rounded-full text-xs font-bold"
            style={{ background: "linear-gradient(135deg, #3ccf73, #2aaa58)", color: "#000", boxShadow: "0 0 20px rgba(60,207,115,0.4)" }}
            data-testid="popular-badge">
            <Star size={10} fill="black" /> {t("landing.pricing.popular")}
          </span>
        </div>
      )}
      <div className="relative rounded-2xl overflow-hidden h-full flex flex-col"
        style={{
          background: isHighlighted
            ? "linear-gradient(145deg, rgba(22,6,42,0.99) 0%, rgba(8,0,20,1) 100%)"
            : "linear-gradient(145deg, rgba(14,3,28,0.97) 0%, rgba(5,0,12,0.99) 100%)",
          border: `1px solid ${isHighlighted ? "rgba(60,207,115,0.3)" : "rgba(255,255,255,0.07)"}`,
          boxShadow: isHighlighted
            ? "0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(60,207,115,0.1), inset 0 1px 0 rgba(255,255,255,0.06)"
            : "0 8px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.04)",
        }}>
        <div className="absolute top-0 left-0 right-0 h-px"
          style={{ background: `linear-gradient(90deg, transparent, ${accent}55, transparent)` }} />
        {isHighlighted && (
          <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-48 h-48 rounded-full blur-3xl"
            style={{ background: "rgba(60,207,115,0.08)" }} />
        )}
        <div className="relative z-10 p-6 md:p-7 flex flex-col h-full gap-5">
          <div>
            <h3 className="text-xl font-black text-white tracking-tight" data-testid={`plan-name-${index}`}>{plan.displayName}</h3>
            <p className="text-sm text-gray-500 mt-1 leading-relaxed" data-testid={`plan-description-${index}`}>{plan.description}</p>
          </div>
          <div data-testid={`plan-price-${index}`}>
            {parseFloat(price) === 0 ? (
              <>
                <span className="text-5xl font-black text-white">{t("landing.pricing.free")}</span>
                <p className="text-xs text-gray-600 mt-1">No credit card required</p>
              </>
            ) : (
              <>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold text-gray-400">{currencySymbol}</span>
                  <span className="text-5xl font-black text-white">{price}</span>
                  <span className="text-sm text-gray-500 ml-1">/ {isYearly ? "yr" : "mo"}</span>
                </div>
                {isYearly && (
                  <span className="inline-flex items-center gap-1 mt-1.5 text-[10px] font-bold px-2 py-0.5 rounded-full"
                    style={{ background: "rgba(60,207,115,0.1)", color: "#3ccf73", border: "1px solid rgba(60,207,115,0.25)" }}>
                    {t("landing.pricing.save20")}
                  </span>
                )}
              </>
            )}
          </div>
          <div className="h-px" style={{ background: "rgba(255,255,255,0.06)" }} />
          <div className="flex-1 space-y-2.5" data-testid={`plan-features-${index}`}>
            {features.map((f, i) => <FRow key={i} text={f.text} star={f.star} accent={accent} />)}
          </div>
          <motion.button
            whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }}
            onClick={onNavigate}
            className="relative w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm overflow-hidden mt-2"
            style={isHighlighted ? {
              background: "linear-gradient(135deg, #3ccf73 0%, #2aaa58 100%)", color: "#000",
              boxShadow: "0 0 28px rgba(60,207,115,0.3)",
            } : {
              background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.65)",
              border: `1px solid ${accent}30`,
            }}
            data-testid={`button-plan-${index}`}
          >
            {isHighlighted && (
              <motion.span className="absolute inset-0 rounded-xl"
                style={{ background: "linear-gradient(110deg, transparent 30%, rgba(255,255,255,0.2) 50%, transparent 70%)", backgroundSize: "200% 100%" }}
                animate={{ backgroundPosition: ["200% 0", "-200% 0"] }}
                transition={{ duration: 2.6, repeat: Infinity, ease: "linear" }} />
            )}
            <span className="relative">{isHighlighted ? t("landing.pricing.startFreeTrial") : t("landing.pricing.getStarted")}</span>
            <ArrowRight size={13} className="relative" />
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
};

/* ─── Skeleton loader ─────────────────────────── */
const SkeletonCard = ({ delay }: { delay: number }) => (
  <motion.div
    initial={{ opacity: 0 }} animate={{ opacity: 1 }}
    transition={{ delay, duration: 0.4 }}
    className="rounded-2xl overflow-hidden"
    style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.06)", minHeight: 480 }}
  >
    <div className="p-6 md:p-7 space-y-5 animate-pulse">
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <div className="h-5 w-24 rounded-lg" style={{ background: "rgba(255,255,255,0.08)" }} />
          <div className="h-3 w-40 rounded" style={{ background: "rgba(255,255,255,0.05)" }} />
        </div>
        <div className="w-10 h-10 rounded-xl" style={{ background: "rgba(255,255,255,0.06)" }} />
      </div>
      <div className="h-14 w-32 rounded-xl" style={{ background: "rgba(255,255,255,0.07)" }} />
      <div className="h-px w-full" style={{ background: "rgba(255,255,255,0.05)" }} />
      {[90, 70, 80, 65, 75, 60, 85].map((w, i) => (
        <div key={i} className="flex items-center gap-3">
          <div className="w-4 h-4 rounded-full flex-shrink-0" style={{ background: "rgba(255,255,255,0.07)" }} />
          <div className="h-3 rounded" style={{ width: `${w}%`, background: "rgba(255,255,255,0.05)" }} />
        </div>
      ))}
      <div className="h-12 w-full rounded-xl mt-4" style={{ background: "rgba(255,255,255,0.06)" }} />
    </div>
  </motion.div>
);

/* ─────────────────────────────────────────────
   MAIN
───────────────────────────────────────────── */
export function PricingSection() {
  const [, setLocation] = useLocation();
  const [isYearly, setIsYearly] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState<string>("USD");
  const shouldReduceMotion = useReducedMotion();
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  const { data: plans, isLoading, isError } = useQuery<Plan[]>({
    queryKey: ["/api/plans"],
    retry: 1,
    retryDelay: 1000,
  });
  const { data: gatewayConfig } = useQuery<PaymentGatewayConfig>({ queryKey: ["/api/settings/payment-gateway"] });
  const { data: pluginCapabilities } = useQuery<PluginCapabilities>({ queryKey: ["/api/plugins/capabilities"] });

  const sipPluginEnabled = pluginCapabilities?.data?.capabilities?.["sip-engine"] ?? false;
  const restApiPluginEnabled = pluginCapabilities?.data?.capabilities?.["rest-api"] ?? false;

  const sortedPlans = [...(plans || [])].sort((a, b) => {
    if (a.name === "free") return -1;
    if (b.name === "free") return 1;
    return parseFloat(a.monthlyPrice || "0") - parseFloat(b.monthlyPrice || "0");
  });

  const hasRazorpayPricing = sortedPlans.some(p => p.razorpayMonthlyPrice || p.razorpayYearlyPrice);
  const hasPaypalPricing   = sortedPlans.some(p => p.paypalMonthlyPrice   || p.paypalYearlyPrice);
  const hasPaystackPricing = sortedPlans.some(p => p.paystackMonthlyPrice || p.paystackYearlyPrice);
  const hasMercadopagoPricing = sortedPlans.some(p => p.mercadopagoMonthlyPrice || p.mercadopagoYearlyPrice);

  const currencyOptions: CurrencyOption[] = [];
  if (gatewayConfig?.stripeEnabled && gatewayConfig.stripeCurrency) {
    currencyOptions.push({ code: gatewayConfig.stripeCurrency.toUpperCase(), symbol: gatewayConfig.stripeCurrencySymbol || currencySymbols[gatewayConfig.stripeCurrency.toUpperCase()] || "$", gateway: "stripe" });
  }
  if (gatewayConfig?.razorpayEnabled && hasRazorpayPricing && !currencyOptions.find(c => c.code === "INR"))
    currencyOptions.push({ code: "INR", symbol: "₹", gateway: "razorpay" });
  if (gatewayConfig?.paypalEnabled && gatewayConfig.paypalCurrency && hasPaypalPricing && !currencyOptions.find(c => c.code === gatewayConfig.paypalCurrency?.toUpperCase()))
    currencyOptions.push({ code: gatewayConfig.paypalCurrency.toUpperCase(), symbol: gatewayConfig.paypalCurrencySymbol || "$", gateway: "paypal" });
  if (gatewayConfig?.paystackEnabled && hasPaystackPricing) {
    const pc = gatewayConfig.paystackCurrency?.toUpperCase() || "NGN";
    if (!currencyOptions.find(c => c.code === pc))
      currencyOptions.push({ code: pc, symbol: currencySymbols[pc] || "₦", gateway: "paystack" });
  }
  if (gatewayConfig?.mercadopagoEnabled && gatewayConfig.mercadopagoCurrency && hasMercadopagoPricing) {
    const mc = gatewayConfig.mercadopagoCurrency.toUpperCase();
    if (!currencyOptions.find(c => c.code === mc))
      currencyOptions.push({ code: mc, symbol: gatewayConfig.mercadopagoCurrencySymbol || "R$", gateway: "mercadopago" });
  }

  const validCurrency   = currencyOptions.find(c => c.code === selectedCurrency);
  const effectiveCurrency = validCurrency ? selectedCurrency : (currencyOptions[0]?.code || "USD");
  const currencySymbol  = validCurrency?.symbol || currencyOptions.find(c => c.code === effectiveCurrency)?.symbol || "$";
  const showCurrencySelector = currencyOptions.length > 1;

  const getPrice = (plan: Plan): string => {
    const gateway = currencyOptions.find(c => c.code === effectiveCurrency)?.gateway || "stripe";
    let price: string | null = null;
    switch (gateway) {
      case "razorpay":    price = isYearly ? plan.razorpayYearlyPrice  : plan.razorpayMonthlyPrice;    break;
      case "paypal":      price = isYearly ? plan.paypalYearlyPrice    : plan.paypalMonthlyPrice;      break;
      case "paystack":    price = isYearly ? plan.paystackYearlyPrice  : plan.paystackMonthlyPrice;    break;
      case "mercadopago": price = isYearly ? plan.mercadopagoYearlyPrice : plan.mercadopagoMonthlyPrice; break;
      default:            price = isYearly ? plan.yearlyPrice          : plan.monthlyPrice;            break;
    }
    if (!price) price = isYearly ? plan.yearlyPrice : plan.monthlyPrice;
    return price ? parseFloat(price).toLocaleString() : "0";
  };

  /* decide what to render */
  const showPlaceholder = isError || (!isLoading && sortedPlans.length === 0);
  const colClass = showPlaceholder
    ? "md:grid-cols-2 lg:grid-cols-3"
    : sortedPlans.length === 2
    ? "md:grid-cols-2"
    : sortedPlans.length >= 3
    ? "md:grid-cols-2 lg:grid-cols-3"
    : "md:grid-cols-1";

  return (
    <section
      ref={ref}
      id="pricing"
      className="relative overflow-hidden py-16 sm:py-20 md:py-28"
      style={{ background: "linear-gradient(180deg, #000000 0%, #06001a 55%, #000000 100%)" }}
      data-testid="pricing-section"
    >
      {/* BG */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[700px] h-[350px] rounded-full blur-[130px]"
          style={{ background: "radial-gradient(ellipse, rgba(77,28,149,0.22) 0%, transparent 65%)" }} />
        <div className="absolute bottom-0 left-1/4 w-[400px] h-[300px] rounded-full blur-[100px]"
          style={{ background: "radial-gradient(circle, rgba(60,207,115,0.04) 0%, transparent 70%)" }} />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-5 sm:px-8 lg:px-10">
        {/* Header */}
        <motion.div
          initial={shouldReduceMotion ? { opacity:1 } : { opacity:0, y:20 }}
          animate={isInView ? { opacity:1, y:0 } : {}}
          transition={{ duration:0.6 }}
          className="text-center mb-10 md:mb-14"
        >
          <span
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-semibold tracking-[0.18em] uppercase mb-5"
            style={{ background:"rgba(60,207,115,0.07)", border:"1px solid rgba(60,207,115,0.2)", color:"#3ccf73" }}
          >
            <Zap size={10} /> Pricing
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white leading-tight tracking-tight mb-4"
            data-testid="pricing-headline">
            {t("landing.pricing.title")}{" "}
            <span style={{ background:"linear-gradient(135deg,#3ccf73 0%,#b78af5 100%)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundClip:"text" }}>
              {t("landing.pricing.titleHighlight")}
            </span>{" "}
            {t("landing.pricing.titleEnd")}
          </h2>
          <p className="text-base text-gray-400 max-w-xl mx-auto leading-relaxed" data-testid="pricing-subheadline">
            {t("landing.pricing.description")}
          </p>
        </motion.div>

        {/* Controls */}
        <motion.div
          initial={{ opacity:0, y:12 }} animate={isInView ? { opacity:1, y:0 } : {}}
          transition={{ duration:0.5, delay:0.15 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12"
        >
          <div className="flex items-center gap-3 px-5 py-2.5 rounded-full"
            style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)" }}>
            <span className={`text-sm font-medium transition-colors ${!isYearly ? "text-white" : "text-gray-500"}`}>{t("landing.pricing.monthly")}</span>
            <Switch checked={isYearly} onCheckedChange={setIsYearly} data-testid="switch-billing-period" />
            <span className={`text-sm font-medium transition-colors ${isYearly ? "text-white" : "text-gray-500"}`}>{t("landing.pricing.yearly")}</span>
            {isYearly && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                style={{ background:"rgba(60,207,115,0.12)", color:"#3ccf73", border:"1px solid rgba(60,207,115,0.25)" }}>
                {t("landing.pricing.save20")}
              </span>
            )}
          </div>
          {showCurrencySelector && (
            <div className="flex items-center gap-1.5 px-4 py-2.5 rounded-full flex-wrap justify-center"
              style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)" }}>
              {currencyOptions.map(opt => (
                <button key={opt.code} onClick={() => setSelectedCurrency(opt.code)}
                  className="px-3 py-1 rounded-full text-xs font-bold transition-all"
                  style={effectiveCurrency === opt.code ? { background:"linear-gradient(135deg,#3ccf73,#2aaa58)", color:"#000" } : { color:"rgba(255,255,255,0.4)" }}
                  data-testid={`button-currency-${opt.code.toLowerCase()}`}>
                  {opt.symbol} {opt.code}
                </button>
              ))}
            </div>
          )}
        </motion.div>

        {/* Placeholder notice when DB is down */}
        {showPlaceholder && (
          <motion.div
            initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ duration:0.4 }}
            className="flex items-center justify-center gap-2 mb-8"
          >
            <span className="text-[11px] font-semibold px-3 py-1.5 rounded-full flex items-center gap-2"
              style={{ background:"rgba(245,158,11,0.08)", border:"1px solid rgba(245,158,11,0.2)", color:"rgba(245,158,11,0.7)" }}>
              <span className="w-1.5 h-1.5 rounded-full bg-yellow-500/60 animate-pulse" />
              Preview pricing — live plans load when connected
            </span>
          </motion.div>
        )}

        {/* Cards grid */}
        {isLoading ? (
          <div className={`grid grid-cols-1 ${colClass} gap-5 md:gap-6 max-w-5xl mx-auto`}>
            {[0,1,2].map(i => <SkeletonCard key={i} delay={i * 0.07} />)}
          </div>
        ) : showPlaceholder ? (
          <div className={`grid grid-cols-1 ${colClass} gap-5 md:gap-6 max-w-5xl mx-auto pt-2`} data-testid="pricing-grid">
            {PLACEHOLDER_PLANS.map((plan, i) => (
              <PlaceholderCard key={plan.id} plan={plan} isYearly={isYearly} delay={i * 0.1} onNavigate={() => setLocation("/login")} />
            ))}
          </div>
        ) : (
          <div className={`grid grid-cols-1 ${colClass} gap-5 md:gap-6 max-w-5xl mx-auto pt-2`} data-testid="pricing-grid">
            {sortedPlans.map((plan, index) => {
              const isFree = plan.name === "free";
              const isHighlighted = !isFree && (sortedPlans[0]?.name === "free" ? index === 1 : index === 0);
              return (
                <LiveCard
                  key={plan.id} plan={plan} index={index}
                  isHighlighted={isHighlighted} isFree={isFree}
                  price={getPrice(plan)} currencySymbol={currencySymbol}
                  isYearly={isYearly}
                  sipPluginEnabled={sipPluginEnabled}
                  restApiPluginEnabled={restApiPluginEnabled}
                  onNavigate={() => setLocation("/login")}
                />
              );
            })}
          </div>
        )}

        {/* Guarantee */}
        <motion.div
          initial={{ opacity:0 }} animate={isInView ? { opacity:1 } : {}}
          transition={{ delay:0.6 }}
          className="flex items-center justify-center gap-2 mt-10 text-sm text-gray-600"
        >
          <Shield size={14} style={{ color:"#3ccf73" }} />
          <span>{t("landing.pricing.guarantee")}</span>
        </motion.div>
      </div>
    </section>
  );
}

export default PricingSection;